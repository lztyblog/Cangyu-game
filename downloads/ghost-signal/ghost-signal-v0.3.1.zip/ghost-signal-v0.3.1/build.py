from pathlib import Path
root=Path(__file__).resolve().parent
page=(root/'src/template.html').read_text()
for marker,name in [('LEVELS','levels'),('COMBAT','combat'),('ENGINE','engine'),('RENDERER','renderer'),('AUDIO','audio'),('CAMPAIGN','campaign'),('UI','ui')]:
    source=(root/f'src/{name}.js').read_text()
    assert '</script' not in source.lower()
    page=page.replace(f'/* {marker} */',source)
(root/'index.html').write_text(page)
print('Built standalone index.html:',len(page.encode()),'bytes')
