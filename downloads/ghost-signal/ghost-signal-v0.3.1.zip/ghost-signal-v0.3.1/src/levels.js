(function(root){'use strict';
const THEMES={
 mech:{name:'机甲遗站',sky:['#06121f','#163647'],ground:'#182d3b',edge:'#86a8ae',glow:'#7cece3',accent:'#ffc16f',exit:'UFO',resource:'能源芯',music:0},
 haunt:{name:'雾灯旧院',sky:['#100e20','#2c243d'],ground:'#302a36',edge:'#aa98a6',glow:'#a6e0cb',accent:'#e8b782',exit:'院门',resource:'铜钥',music:1},
 alchemy:{name:'悬山丹境',sky:['#10252c','#34544f'],ground:'#334c49',edge:'#c2c5a0',glow:'#b7edb3',accent:'#ffce83',exit:'渡舟',resource:'灵火',music:2},
 frost:{name:'霜月渡口',sky:['#0b1e32','#345774'],ground:'#29465f',edge:'#c4e5ec',glow:'#a0eaff',accent:'#f7b9a0',exit:'雪橇',resource:'热核',music:3}
};
// Each authored sequence changes routes and hazard order, rather than recolouring one map.
const SPECS=[
 ['坠落后的第一盏灯','mech',['spike','steps','press'],1,'先熟悉跳跃。冲压机可以断电，蓝灯是检查点。'],
 ['院里有人来过','haunt',['pit','dart','steps','crumble'],1,'看红灯，也看脚下。死亡残影会记住出事的位置。'],
 ['风从山下起','alchemy',['wind','steps','pit','laser'],2,'青色气流会托住跳跃；灵火都在高处。'],
 ['刹不住的月光','frost',['spike','icepit','steps','crumble'],2,'冰上有惯性。松开方向后会滑一段，提前减速。'],
 ['再走一次的影子','mech',['water','steps','relay','press'],2,'Q 留下最近三秒的影子，E 回放。影子经过共鸣踏板，也能开门。'],
 ['纸灯照不到的路','haunt',['dart','pit','press','steps','laser'],2,'机关开始交替出现。回看鬼魂，可以先观察再行动。'],
 ['借风越断桥','alchemy',['steps','wind','longpit','laser','crumble'],2,'风口之后是断桥。起跳前先看清落脚的位置。'],
 ['薄冰下的回声','frost',['icepit','steps','laser','spike','crumble'],2,'冰面和机关组合出现。检查点仍然保留已经拿到的热核。'],
 ['停在门前的我','mech',['press','steps','water','relayHard','dart'],3,'共鸣门需要一个留在踏板上的影子。也可以从高处绕过。'],
 ['旧院无声处','haunt',['pit','dart','steps','press','laser','relay'],3,'不要只盯着前方；高处和身后也可能有路。'],
 ['一炉三味火','alchemy',['wind','steps','laser','longpit','press','steps'],3,'较长的探索段。带齐三枚灵火，便能在尽头乘舟离开。'],
 ['把最后的路留给你','frost',['icepit','laser','steps','crumble','relayHard','dart','steps'],3,'把惯性、机关和留影放在一起用。最后一次，也可以慢慢来。']
];
function buildBase(index){const [name,theme,sequence,count,hint]=SPECS[index],tier=Math.floor(index/4),L={id:index,name,theme,palette:THEMES[theme],tier,hint,width:0,height:1040,platforms:[],hazards:[],switches:[],cells:[],records:[],checkpoints:[],relays:[],gates:[],winds:[],route:[],start:{x:150,y:778},exit:null};
 let x=360;const gapRanges=[];let n=0;
 function p(x,y,w,h=26){L.platforms.push({x,y,w,h});}
 function cp(x,y=820){L.checkpoints.push({id:L.checkpoints.length,x,y,name:'信标 '+(L.checkpoints.length+1)});}
 function sw(id,x,target,label){L.switches.push({id,x,y:820,target,label,done:'机关已停用 / 捷径已开启'});}
 function move(x,jump=false){L.route.push({x,jump});}
 cp(180);move(300);
 for(const type of sequence){const start=x,id='h'+n++,w=type==='water'?690:type.startsWith('relay')?660:440;
  cp(start+12);
  if(type==='spike'){const hx=start+210;L.hazards.push({id,type:'spike',x:hx,y:805,w:60+tier*9,h:15});move(hx-67);move(hx+100,true);move(start+w-20);}
  if(type==='pit'||type==='longpit'||type==='icepit'){
   const hx=start+200,gw=type==='longpit'?138:type==='icepit'?118:104+tier*10;gapRanges.push([hx,hx+gw]);L.hazards.push({id,type:'pit',x:hx,y:940,w:gw,h:90});
   // Optional upper shelf is reachable from the launch ledge and contains a flight record.
   p(start+34,730,100);L.records.push({id:L.records.length,x:start+80,y:695});
   if(tier===0&&type==='pit'){const sid='bridge'+id;sw(sid,start+140,id,'展开桥板');L.bridges??=[];L.bridges.push({id:sid,x:hx,y:820,w:gw,h:26});}
   move(hx-48);move(hx+gw+24,true);move(start+w-20);
  }
  if(type==='steps'){
   p(start+90,750,110);p(start+210,680,110);p(start+330,610,110);
   move(start+35);move(start+145,true);move(start+265,true);move(start+380,true);
   L.cellSites??=[];L.cellSites.push({x:start+390,y:576,routeIndex:L.route.length});cp(start+375,610);L.route.push({collectSite:L.cellSites.length-1});move(start+w+40);
  }
  if(type==='press'){
   const hx=start+230;L.hazards.push({id,type:'press',x:hx,y:480,w:72,h:340,phase:tier*.65});
   if(tier===0){sw('off'+id,start+110,id,'切断冲压电源');move(start+100);L.route.push({use:'off'+id});}
   move(hx-65);L.route.push({waitFor:id});move(hx+110);move(start+w-20);
  }
  if(type==='laser'){
   const hx=start+220;L.hazards.push({id,type:'laser',x:hx,y:735,w:10,h:85,phase:tier*.55});
   if(tier===0){sw('off'+id,start+95,id,'关闭光栅');move(start+90);L.route.push({use:'off'+id});}
   move(hx-65);L.route.push({waitFor:id});move(hx+90);move(start+w-20);
  }
  if(type==='dart'){
   L.hazards.push({id,type:'dart',x:start+100,y:820,w:240,h:20});move(start+140);move(start+365,true);move(start+w-20);
  }
  if(type==='crumble'){
   const hx=start+185;L.hazards.push({id,type:'crumble',x:hx,y:820,w:120,h:25});move(hx-65);move(hx+145,true);move(start+w-20);
  }
  if(type==='water'){
   const hx=start+215;L.hazards.push({id,type:'water',x:hx,y:802,w:330,h:18});
   p(start+70,750,110);p(start+210,710,130);p(start+410,710,140);
   if(tier<2){sw('off'+id,start+35,id,'关闭漏电');move(start+30);L.route.push({use:'off'+id});move(start+w-20);}
   else{move(start+20);move(start+115,true);move(start+265,true);move(start+465,true);move(start+w-20);}
  }
  if(type==='wind'){
   L.winds.push({x:start+70,y:570,w:260,h:250,lift:620});p(start+190,660,170);L.records.push({id:L.records.length,x:start+280,y:625});
   move(start+60);move(start+270,true);move(start+w-20);
  }
  if(type==='relay'||type==='relayHard'){
   const plateX=start+135,gateX=start+340;L.relays.push({id,x:plateX,y:820,w:75});L.gates.push({id,x:gateX,y:620,w:26,h:200});
   // Both routes are real: a replay holds the lower gate, or four jumps cross the upper stair.
   p(start+15,750,95);p(start+125,675,95);p(start+235,600,95);p(start+345,525,120);
   L.records.push({id:L.records.length,x:start+400,y:490});
   move(plateX);L.route.push({recordPlate:id});move(gateX+90);move(start+w-20);
  }
  x+=w;
 }
 L.width=x+450;L.exit={x:x+230,y:820,label:THEMES[theme].exit};move(x+220);L.route.push({exit:true});
 // Cells are placed on distinct elevated branches; later stages add guarded floor caches.
 const sites=L.cellSites||[];for(let i=0;i<count;i++){
  let site=sites[i];if(!site){const chunkStart=360+sequence.slice(0,Math.min(sequence.length-1,2+i)).reduce((sum,t)=>sum+(t==='water'?690:t.startsWith('relay')?660:440),0);
   site={x:chunkStart+55,y:786,routeIndex:L.route.findIndex(a=>a.x>chunkStart+55)};
  }L.cells.push({id:i,x:site.x,y:site.y,name:THEMES[theme].resource+' '+(i+1),site:i<sites.length?i:null});
 }
 // Insert pickups at physically visited floor positions; upper cache pickups use authored stops.
 const enriched=[];for(const a of L.route){if(a.collectSite!==undefined){const cell=L.cells.find(c=>c.site===a.collectSite);if(cell)enriched.push({cell:cell.id});continue;}
  if(a.x!==undefined){for(const c of L.cells.filter(c=>c.site===null&&!c.inserted)){const prev=[...enriched].reverse().find(q=>q.x!==undefined);if(prev&&prev.x<=c.x&&a.x>=c.x){enriched.push({x:c.x-10});enriched.push({cell:c.id});c.inserted=true;}}}enriched.push(a);}
 L.route=enriched;for(const c of L.cells)delete c.inserted;
 let from=0;for(const [a,b]of gapRanges.sort((a,b)=>a[0]-b[0])){p(from,820,a-from,220);from=b;}p(from,820,L.width-from,220);
 return L;
}
function expand(index){
 const L=buildBase(index),tier=L.tier,origin=L.width-300;
 L.originalWidth=L.width;L.enemies=[];L.blocks=[];L.supplies=[];L.targets=[];L.areas=[];
 L.role={mech:'维修机兵',haunt:'提灯幽灵',alchemy:'御剑行者',frost:'雪球旅人'}[L.theme];
 L.hint='J / 鼠标左键攻击，K 使用角色技能。Q 留影、E 回放，影子能重放普通攻击。先找齐物件，再击败出口守卫。';
 if(L.theme==='frost')L.hint+='冰面有更快的滑行，提前减速。';
 // Retain the original obstacle route, then open substantial rooms with return paths.
 L.route=L.route.filter(a=>!a.exit&&!(a.x>=origin));
 L.platforms=L.platforms.filter(q=>q.y!==820||q.h<100).concat(L.platforms.filter(q=>q.y===820&&q.h>=100).map(q=>q.x+q.w>=L.width?{...q,w:origin-q.x}:q));
 function p(x,y,w,h=26){L.platforms.push({x,y,w,h});}
 function cp(x,y,name){L.checkpoints.push({id:L.checkpoints.length,x,y,name});}
 function move(x,jump=false){L.route.push({x,jump});}
 function enemy(id,x,y,kind,extra={}){L.enemies.push({id,x,y,w:kind==='guardian'?50:30,h:kind==='guardian'?64:42,kind,hp:kind==='guardian'?200+tier*100:kind==='shield'?100+tier*20:65+tier*18,range:kind==='ranged'?480:kind==='guardian'?620:55,patrol:60,...extra});}
 let x=origin;
 const roomCount=3+tier;
 for(let i=0;i<roomCount;i++){
  const start=x,cache=i===0||i===roomCount-1,mirror=(index+i)%2===0,span=cache?1260:1060;
  L.areas.push({x:start+35,y:560,name:cache?'回廊 '+(i+1)+' / '+L.palette.resource+'储藏室':'警戒区 '+(i+1)+' / 战斗与补给',hint:cache?'高处有物件，沿阶梯探索。':'J 攻击 / K 技能；也可以借鬼魂吸引守卫。'});
  p(start,820,span,220);cp(start+75,820,'回廊 '+(i+1));L.supplies.push({id:'aid-'+i,x:start+110,y:798,amount:40});
  if(cache){
   let chest,wall;
   if(mirror){
    p(start+150,600,460);p(start+610,675,120);p(start+750,750,130);
    chest={x:start+230,y:566};wall={id:'cache-'+i,x:start+330,y:530,w:28,h:70,hp:44+tier*16};L.blocks.push(wall);
    enemy('upper-'+i,start+250,558,'ranged',{patrol:0});
    move(start+680);move(start+805,true);move(start+670,true);move(start+550,true);move(start+380);L.route.push({break:wall.id});move(chest.x-8);
   }else{
    p(start+100,750,120);p(start+240,675,120);p(start+380,600,620);
    chest={x:start+900,y:566};wall={id:'cache-'+i,x:start+750,y:530,w:28,h:70,hp:44+tier*16};L.blocks.push(wall);
    enemy('upper-'+i,start+925,558,'ranged',{patrol:0});
    move(start+40);move(start+155,true);move(start+295,true);move(start+440,true);move(start+690);L.route.push({break:wall.id});move(chest.x-8);
   }
   const id=L.cells.length;L.cells.push({id,x:chest.x,y:chest.y,name:L.palette.resource+' '+(id+1),site:null});L.route.push({cell:id});cp(chest.x,600,'上层储藏室 '+(i+1));
   enemy('patrol-'+i,start+460,778,tier>0?'shield':'walker');
   move(start+1130);L.records.push({id:L.records.length,x:start+1095,y:706});p(start+1020,740,140);L.supplies.push({id:'upper-aid-'+i,x:chest.x+42,y:578,amount:30});
  }else{
   enemy('guard-'+i,start+400,778,'shield');enemy('sentry-'+i,start+790,778,'ranged',{patrol:0});
   const block={id:'rubble-'+i,x:start+590,y:754,w:38,h:66,hp:50+tier*18};L.blocks.push(block);
   // A low obstacle can be destroyed or crossed from a higher supply ledge.
   p(start+175,740,130);p(start+320,660,220);L.records.push({id:L.records.length,x:start+455,y:625});
   move(start+360);L.route.push({fight:'guard-'+i});move(start+535);L.route.push({break:block.id});move(start+730);L.route.push({fight:'sentry-'+i});move(start+990);
  }
  move(start+span-35);x+=span;
 }
 const finish=x;L.areas.push({x:finish+35,y:545,name:'最后的守门者',hint:'击败守卫后，带齐物件离开。重放攻击的影子也能帮你。'});
 p(finish,820,1000,220);cp(finish+75,820,'出口前哨');L.supplies.push({id:'final-aid',x:finish+110,y:798,amount:55});
 const guardian={id:'guardian',x:finish+510,y:756,kind:'guardian',patrol:40};enemy('guardian',guardian.x,guardian.y,'guardian');
 move(finish+395);L.route.push({fight:'guardian'});L.width=finish+1000;L.exit={x:finish+840,y:820,label:L.palette.exit};move(finish+830);L.route.push({exit:true});
 // Distinct entry silhouettes and role labels make returning to a chapter unambiguous.
 L.areas.unshift({x:95,y:665,name:String(index+1).padStart(2,'0')+' / '+L.name,hint:L.role+' · 本关检查点独立保存'});
 return L;
}
const LEVELS=SPECS.map((_,i)=>expand(i));
const api={THEMES,LEVELS};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.GhostLevels=api;
})(typeof globalThis!=='undefined'?globalThis:this);
