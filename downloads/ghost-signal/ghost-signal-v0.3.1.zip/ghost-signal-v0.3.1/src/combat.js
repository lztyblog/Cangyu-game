(function(root){'use strict';
const ROLES={mech:{name:'维修机兵',speed:270,attack:'脉冲弹',skill:'震荡脉冲',damage:23,cooldown:.24,reach:650,skillCD:4.4},haunt:{name:'提灯幽灵',speed:285,attack:'魂焰',skill:'幽行',damage:25,cooldown:.29,reach:580,skillCD:4},alchemy:{name:'御剑行者',speed:290,attack:'剑斩',skill:'飞剑',damage:32,cooldown:.3,reach:106,skillCD:3.8},frost:{name:'雪球旅人',speed:320,attack:'雪球',skill:'冰震',damage:20,cooldown:.25,reach:650,skillCD:4.8}};
function init(s,L){Object.assign(s.player,{hp:100,maxHp:100,invuln:0,phase:0,attackFlash:0,skillFlash:0});s.enemies=L.enemies.map(e=>({...e,maxHp:e.hp,anchor:e.x,face:-1,windup:0,cooldown:.7,stun:0,slow:0,flash:0}));s.blocks=L.blocks.map(b=>({...b,maxHp:b.hp}));s.projectiles=[];s.attackCD=0;s.skillCD=0;s.kills=0;s.usedSupplies=[];s.shotSinceRecord=false;s.echoTarget=null;s.swings=[];}
function aimBox(p,range,face){return{x:face>0?p.x+p.w/2:p.x+p.w/2-range,y:p.y-10,w:range,h:p.h+20};}
function hitEnemy(s,e,damage,A,from,stun=0,bypass=false){if(e.hp<=0)return;const front=from===undefined?false:(from-e.x)*e.face>0;const shield=e.kind==='shield'&&front&&e.stun<=0&&!bypass;e.hp=Math.max(0,e.hp-damage*(shield?.45:1));e.flash=.13;e.stun=Math.max(e.stun,stun);if(stun)e.windup=0;A.emit(s,'impact',{x:e.x+e.w/2,y:e.y+15,amount:Math.round(damage*(shield?.45:1)),shield});if(e.hp<=0){s.kills++;A.emit(s,'enemy-down',{x:e.x,y:e.y,kind:e.kind});A.emit(s,'save');}}
function hitBlock(s,b,damage,A){if(b.hp<=0)return;b.hp=Math.max(0,b.hp-damage);A.emit(s,'impact',{x:b.x+b.w/2,y:b.y+20,amount:Math.round(damage)});if(b.hp<=0){A.emit(s,'break',{x:b.x,y:b.y});A.notice(s,'障碍已破坏 · 这条路保持畅通。');A.emit(s,'save');}}
function spawn(s,p,face,theme,echo=false,power=1,skill=false){const R=ROLES[theme];s.projectiles.push({x:p.x+p.w/2+face*21,y:p.y+p.h*.48,w:theme==='frost'?12:20,h:theme==='haunt'?14:8,vx:face*(theme==='haunt'?450:theme==='frost'?540:700),vy:0,life:skill?1.15:1,owner:echo?'echo':'player',theme,damage:(skill?48:R.damage)*power,slow:theme==='frost'?2.2:0,pierce:skill?2:0,skill});}
function attack(s,A,echo=null){const theme=A.level(s).theme,R=ROLES[theme],p=echo?{...echo,w:26,h:42}:s.player,face=p.face||1;if(!echo&&s.attackCD>0)return;
 if(!echo){s.attackCD=R.cooldown;s.player.attackFlash=.14;s.shotSinceRecord=true;A.emit(s,'attack',{theme});}
 if(theme==='alchemy'){const box=aimBox(p,R.reach,face);for(const e of s.enemies)if(e.hp>0&&A.overlap(box,e))hitEnemy(s,e,R.damage*(echo?.55:1),A,p.x,0);for(const b of s.blocks)if(b.hp>0&&A.overlap(box,b))hitBlock(s,b,R.damage*(echo?.55:1),A);s.swings.push({x:p.x+13,y:p.y+21,face,theme,echo:!!echo,life:.15});}
 else spawn(s,p,face,theme,!!echo,echo?.55:1);
}
function skill(s,A){if(s.skillCD>0)return;const theme=A.level(s).theme,R=ROLES[theme],p=s.player;s.skillCD=R.skillCD;p.skillFlash=.35;A.emit(s,'skill',{theme});
 if(theme==='haunt'){p.phase=1.1;p.invuln=Math.max(p.invuln,1.1);for(const e of s.enemies)if(e.hp>0&&Math.hypot(e.x-p.x,e.y-p.y)<150)hitEnemy(s,e,35,A,p.x,1.4,true);A.notice(s,'幽行 · 短暂免疫敌人与机关伤害，坠落仍会死亡。');}
 else if(theme==='alchemy')spawn(s,p,p.face,theme,false,1,true);
 else{const radius=theme==='frost'?185:155;for(const e of s.enemies)if(e.hp>0&&Math.hypot(e.x-p.x,e.y-p.y)<radius)hitEnemy(s,e,theme==='frost'?38:44,A,p.x,theme==='frost'?2.5:1.8,true);for(const b of s.blocks)if(b.hp>0&&Math.hypot(b.x-p.x,b.y-p.y)<radius)hitBlock(s,b,48,A);}
}
function damage(s,amount,A,from,cause='守卫攻击'){const p=s.player;if(s.mode!=='playing'||p.invuln>0||p.phase>0||s.grace>0)return;p.hp=Math.max(0,p.hp-amount);p.invuln=.85;p.vx+=(p.x<from?-1:1)*140;A.emit(s,'hurt',{x:p.x,y:p.y,amount});if(p.hp<=0)A.die(s,cause);}
function update(s,input,dt,A){const L=A.level(s),p=s.player;s.attackCD=Math.max(0,s.attackCD-dt);s.skillCD=Math.max(0,s.skillCD-dt);for(const k of ['invuln','phase','attackFlash','skillFlash'])p[k]=Math.max(0,p[k]-dt);
 if(input.attack)attack(s,A);if(input.skill)skill(s,A);
 for(const e of s.enemies){if(e.hp<=0)continue;e.flash=Math.max(0,e.flash-dt);e.stun=Math.max(0,e.stun-dt);e.slow=Math.max(0,e.slow-dt);e.cooldown=Math.max(0,e.cooldown-dt);if(e.stun>0)continue;
  const echo=s.echoTarget;let target=p,decoy=false;if(echo&&Math.abs(echo.y-e.y)<120&&Math.abs(echo.x-e.x)<Math.abs(p.x-e.x)+110){target=echo;decoy=true;}
  const dx=target.x-e.x,dy=Math.abs(target.y-e.y),dist=Math.abs(dx);if(!e.windup)e.face=dx>0?1:-1;
  if(e.windup>0){e.windup-=dt;if(e.windup<=0){if(e.kind==='ranged'||(e.kind==='guardian'&&e.attackMode==='bolt')){const t=e.lockedTarget||p,ox=e.x+e.w/2,oy=e.y+e.h*.45,tx=t.x+13,ty=t.y+20,len=Math.hypot(tx-ox,ty-oy)||1;s.projectiles.push({x:ox,y:oy,w:12,h:8,vx:(tx-ox)/len*(285+L.tier*25),vy:(ty-oy)/len*(285+L.tier*25),life:2.3,owner:'enemy',theme:L.theme,damage:e.kind==='guardian'?23+L.tier*3:18+L.tier*3});}
    else if(e.kind==='guardian'){A.emit(s,'stomp',{x:e.x+e.w/2,y:820});if(!e.lockedDecoy&&Math.abs(p.x-e.x)<160&&p.grounded&&Math.abs(p.y-e.y)<100)damage(s,25+L.tier*4,A,e.x,'守门者震击');}
    else if(!e.lockedDecoy&&Math.abs(p.x-e.x)<85&&Math.abs(p.y-e.y)<65)damage(s,16+L.tier*3,A,e.x,'守卫近身攻击');
    e.cooldown=e.kind==='guardian'?1.3:e.kind==='ranged'?1.65:1.1;e.lockedTarget=null;}
   continue;}
  if(dy<120&&dist<e.range&&e.cooldown<=0){e.windup=e.kind==='guardian'?.85:e.kind==='ranged'?.7:.58;e.lockedTarget={x:target.x,y:target.y};e.lockedDecoy=decoy;e.attackMode=e.kind==='guardian'&&dist>145?'bolt':'stomp';continue;}
  if(e.kind!=='ranged'&&e.kind!=='guardian'){const speed=(e.slow>0?30:65+L.tier*10);if(dy<80&&dist<370&&dist>46)e.x+=Math.sign(dx)*speed*dt;else if(dist>370&&e.patrol>0)e.x+=e.face*speed*.35*dt;e.x=A.clamp(e.x,e.anchor-e.patrol,e.anchor+e.patrol);}
 }
 const solid=A.solids(s);
 for(const q of s.projectiles){q.x+=q.vx*dt;q.y+=q.vy*dt;q.life-=dt;if(q.life<=0)continue;
  if(q.owner==='enemy'){
   if(s.echoTarget&&A.overlap(q,{x:s.echoTarget.x,y:s.echoTarget.y,w:26,h:42})){q.life=0;A.emit(s,'ghost-block',{x:q.x,y:q.y});continue;}
   if(A.overlap(q,p)){damage(s,q.damage,A,q.x,'远程守卫攻击');q.life=0;}
  }else{
   for(const b of s.blocks)if(b.hp>0&&A.overlap(q,b)){hitBlock(s,b,q.damage,A);q.life=0;break;}
   if(q.life>0)for(const e of s.enemies)if(e.hp>0&&A.overlap(q,e)&&q.lastHit!==e.id){hitEnemy(s,e,q.damage,A,q.x-Math.sign(q.vx)*40,0);if(q.slow)e.slow=q.slow;q.lastHit=e.id;if(q.pierce>0)q.pierce--;else q.life=0;break;}
  }
  if(q.life>0)for(const b of solid)if(A.overlap(q,b)){q.life=0;break;}
 }
 s.projectiles=s.projectiles.filter(q=>q.life>0);for(const swing of s.swings)swing.life-=dt;s.swings=s.swings.filter(q=>q.life>0);
 for(const h of L.supplies)if(!s.usedSupplies.includes(h.id)&&p.hp<p.maxHp&&Math.hypot(p.x+13-h.x,p.y+20-h.y)<36){p.hp=Math.min(p.maxHp,p.hp+h.amount);s.usedSupplies.push(h.id);A.notice(s,'恢复 '+h.amount+' 点生命');A.emit(s,'heal');A.emit(s,'save');}
}
const api={ROLES,init,attack,skill,update,damage};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.GhostCombat=api;
})(typeof globalThis!=='undefined'?globalThis:this);
