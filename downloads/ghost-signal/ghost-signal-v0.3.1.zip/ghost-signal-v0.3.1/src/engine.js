(function(root){'use strict';
const DATA=typeof module!=='undefined'&&module.exports?require('./levels.js'):root.GhostLevels;
const Combat=typeof module!=='undefined'&&module.exports?require('./combat.js'):root.GhostCombat;
const {LEVELS,THEMES}=DATA,GRAVITY=1740,SPEED=285,JUMP=650;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const level=s=>LEVELS[s.levelIndex]||LEVELS[0];
function fresh(index=0){const L=LEVELS[index]||LEVELS[0];const s={version:3,levelIndex:L.id,time:0,elapsed:0,mode:'title',player:{x:L.start.x,y:L.start.y,w:26,h:42,vx:0,vy:0,grounded:false,face:1,coyote:0,jumpBuffer:0},flags:{},cells:[],memories:[],ghosts:[],checkpoint:0,checkpointLevel:L.id,deaths:0,path:[],recordTick:0,deadFor:0,grace:0,events:[],notice:'',noticeFor:0,replay:null,relayCharge:{},trapTimes:{},cracks:{},broken:{},recordCooldown:0};Combat.init(s,L);return s;}
function emit(s,type,data={}){s.events.push({type,...data});}
function notice(s,t){s.notice=t;s.noticeFor=4;emit(s,'notice',{text:t});}
function disabled(s,h){return level(s).switches.some(o=>o.target===h.id&&s.flags[o.id]);}
function hazardState(s,h){const phase=(s.time+(h.phase||0))%4.8;
 if(h.type==='press'){const ext=phase<2.65?0:phase<3.15?(phase-2.65)/.5:phase<3.85?1:1-(phase-3.85)/.95;return{bottom:disabled(s,h)?620:620+clamp(ext,0,1)*196,warning:phase>2.05&&phase<2.65,safe:disabled(s,h)||phase<2.05};}
 if(h.type==='laser'){const t=(s.time+(h.phase||0))%4.5;return{on:!disabled(s,h)&&t>1.8,warning:!disabled(s,h)&&t>1.25&&t<=1.8,safe:disabled(s,h)||t<.5};}
 return{on:!disabled(s,h)};
}
function solids(s){const L=level(s),a=L.platforms.slice();for(const b of s.blocks||[])if(b.hp>0)a.push(b);for(const b of L.bridges||[])if(s.flags[b.id])a.push(b);for(const gate of L.gates)if(!(s.relayCharge[gate.id]>0)&&!overlap(s.player,gate))a.push(gate);return a;}
function interactions(s){const p=s.player,L=level(s),cx=p.x+13,cy=p.y+21,near=(x,y,d=78)=>Math.hypot(cx-x,cy-(y-22))<d,out=[];
 for(const c of L.cells)if(!s.cells.includes(c.id)&&near(c.x,c.y+20,70))out.push({kind:'cell',id:c.id,label:'取走'+c.name,x:c.x,y:c.y-26});
 for(const o of L.switches)if(!s.flags[o.id]&&near(o.x,o.y))out.push({kind:'switch',id:o.id,label:o.label,x:o.x,y:o.y-70});
 const gs=s.ghosts.filter(g=>Math.hypot(g.x-cx,g.y-cy)<100).sort((a,b)=>Math.hypot(a.x-cx,a.y-cy)-Math.hypot(b.x-cx,b.y-cy));if(gs[0])out.push({kind:'ghost',id:gs[0].id,label:'回放残影 · '+gs[0].cause,x:gs[0].x,y:gs[0].y-60});
 if(near(L.exit.x,L.exit.y,110))out.unshift({kind:'exit',label:s.cells.length===L.cells.length?'启动'+L.exit.label+' · 离开这里':'还缺 '+(L.cells.length-s.cells.length)+' 枚'+L.palette.resource,x:L.exit.x,y:L.exit.y-90});
 return out;
}
function record(s){if(s.recordCooldown>0){notice(s,'等影子稳定一下。');return;}if(s.path.length<8){notice(s,'先走动或停留片刻，留下最近三秒的轨迹。');return;}
 const p=s.player,id='manual-'+Math.round(s.time*1000);s.ghosts.push({id,x:p.x+13,y:p.y+20,cause:'主动留影',manual:true,path:s.path.map(v=>({...v})),time:s.time});if(s.ghosts.length>32)s.ghosts.shift();s.recordCooldown=1;notice(s,'影子已留下 · 靠近按 E 回放。共鸣踏板可以被回放中的影子触发。');emit(s,'ghost');emit(s,'save');}
function interact(s){const o=interactions(s)[0],L=level(s);if(!o)return;
 if(o.kind==='cell'){s.cells.push(o.id);emit(s,'cell');notice(s,L.palette.resource+' '+s.cells.length+'/'+L.cells.length+' · 已保存，死亡不会丢失。');emit(s,'save');}
 if(o.kind==='switch'){s.flags[o.id]=true;emit(s,'switch');notice(s,L.switches.find(q=>q.id===o.id).done);emit(s,'save');}
 if(o.kind==='ghost'){const g=s.ghosts.find(g=>g.id===o.id);s.replay={ghost:g,t:0};notice(s,g.manual?'残影正在回放 · 你可以同时自由行动。':'死亡回放：'+g.cause+'。再试一次，或者换条路。');emit(s,'ghost');}
 if(o.kind==='exit'){if(s.enemies.some(e=>e.id==='guardian'&&e.hp>0)){notice(s,'出口守卫仍在警戒。J 攻击、K 技能，回放中的影子也能帮忙。');return;}if(s.cells.length<L.cells.length)notice(s,'还没有找齐'+L.palette.resource+'。可以回头找找高处和岔路。');else{s.mode='won';emit(s,'win');emit(s,'save');}}
}
function die(s,cause){if(s.mode!=='playing'||s.grace>0||(s.player.phase>0&&cause!=='坠入深处'))return false;const p=s.player,L=level(s);s.deaths++;s.ghosts.push({id:'death-'+s.deaths,x:clamp(p.x+13,30,L.width-30),y:clamp(p.y+20,150,895),cause,path:s.path.map(v=>({...v})),time:s.time});if(s.ghosts.length>32)s.ghosts.shift();s.mode='dead';s.deadFor=.6;s.replay=null;emit(s,'death',{x:p.x,y:p.y,cause});emit(s,'save');return true;}
function respawn(s){const L=level(s);if(s.checkpointLevel!==L.id||!L.checkpoints[s.checkpoint])s.checkpoint=0;s.checkpointLevel=L.id;const cp=L.checkpoints[s.checkpoint];Object.assign(s.player,{x:cp.x,y:cp.y-42,vx:0,vy:0,grounded:false,coyote:0,jumpBuffer:0,hp:100,invuln:0,phase:0});s.path=[];s.grace=.9;s.mode='playing';s.trapTimes={};s.cracks={};s.projectiles=[];s.replay=null;s.echoTarget=null;for(const e of s.enemies){e.windup=0;e.cooldown=.8;}emit(s,'respawn',{levelIndex:L.id,checkpoint:s.checkpoint});}
function returnCheckpoint(s){const index=s.levelIndex;respawn(s);if(s.levelIndex!==index)throw Error('Checkpoint changed level');notice(s,'已返回第 '+(index+1)+' 关 · '+level(s).checkpoints[s.checkpoint].name+'，物件和战斗进度保留。');emit(s,'save');}
function start(s){if(s.mode==='title'||s.mode==='paused')s.mode='playing';}
function step(s,input={},dt=1/120){dt=Math.min(dt,1/30);if(s.mode==='dead'){s.deadFor-=dt;if(s.deadFor<=0)respawn(s);return;}if(s.mode!=='playing')return;
 const L=level(s),p=s.player;s.time+=dt;s.elapsed+=dt;s.grace=Math.max(0,s.grace-dt);s.recordCooldown=Math.max(0,s.recordCooldown-dt);s.noticeFor=Math.max(0,s.noticeFor-dt);
 s.recordTick+=dt;if(s.recordTick>.045){s.recordTick=0;s.path.push({x:p.x,y:p.y,face:p.face,attack:s.shotSinceRecord});s.shotSinceRecord=false;if(s.path.length>68)s.path.shift();}
 if(input.record)record(s);if(input.interact)interact(s);if(s.mode!=='playing')return;if(input.restart){returnCheckpoint(s);return;}
 for(const r of L.relays)s.relayCharge[r.id]=Math.max(0,(s.relayCharge[r.id]||0)-dt);
 s.echoTarget=null;if(s.replay){s.replay.t+=dt;const path=s.replay.ghost.path,idx=Math.floor(s.replay.t/.045),echo=path[Math.min(path.length-1,idx)];
  if(echo){s.echoTarget={x:echo.x,y:echo.y,face:echo.face};if(idx!==s.replay.lastIndex&&echo.attack)Combat.attack(s,combatAPI,echo);s.replay.lastIndex=idx;}
  if(echo)for(const r of L.relays)if(Math.abs(echo.x+13-r.x)<r.w/2+15&&Math.abs(echo.y+42-r.y)<22)s.relayCharge[r.id]=2.2;
  if(s.replay.t>path.length*.045+.1)s.replay=null;
 }
 for(const r of L.relays)if(Math.abs(p.x+13-r.x)<r.w/2+10&&Math.abs(p.y+42-r.y)<20)s.relayCharge[r.id]=.35;
 p.jumpBuffer=input.jump?.14:Math.max(0,p.jumpBuffer-dt);p.coyote=p.grounded?.12:Math.max(0,p.coyote-dt);
 const axis=(input.right?1:0)-(input.left?1:0),ice=L.theme==='frost',target=axis*Combat.ROLES[L.theme].speed,accel=p.grounded?(ice?(axis?1100:520):2400):1600;
 p.vx+=clamp(target-p.vx,-accel*dt,accel*dt);if(axis)p.face=axis;
 if(p.jumpBuffer>0&&p.coyote>0){p.vy=-JUMP;p.grounded=false;p.coyote=0;p.jumpBuffer=0;emit(s,'jump');}
 if(input.jumpReleased&&p.vy< -230)p.vy=-230;
 let lift=0;for(const wind of L.winds)if(overlap(p,wind)&&!p.grounded)lift=wind.lift;
 p.vy=Math.min(1000,p.vy+(GRAVITY-lift)*dt);const oldX=p.x,oldY=p.y,wasGround=p.grounded,ss=solids(s);
 p.x=clamp(p.x+p.vx*dt,20,L.width-p.w-20);for(const q of ss)if(overlap(p,q)){if(p.vx>0)p.x=q.x-p.w;else if(p.vx<0)p.x=q.x+q.w;p.vx=0;}
 p.y+=p.vy*dt;p.grounded=false;for(const q of ss)if(overlap(p,q)){if(p.vy>0&&oldY+p.h<=q.y+3){p.y=q.y-p.h;p.vy=0;p.grounded=true;}else if(p.vy<0&&oldY>=q.y+q.h-3){p.y=q.y+q.h;p.vy=0;}}
 if(!wasGround&&p.grounded)emit(s,'land');
 Combat.update(s,input,dt,combatAPI);if(s.mode!=='playing')return;
 const hurt={x:p.x+4,y:p.y+4,w:p.w-8,h:p.h-5};if(p.y>975){die(s,'坠入深处');return;}
 for(const h of L.hazards){if(disabled(s,h))continue;const hs=hazardState(s,h);
  if(h.type==='spike'&&overlap(hurt,h)){die(s,L.theme==='frost'?'冰棱尖刺':'地面尖刺');return;}
  if(h.type==='press'&&overlap(hurt,{x:h.x,y:h.y,w:h.w,h:hs.bottom-h.y})){die(s,L.theme==='haunt'?'落梁机关':L.theme==='alchemy'?'落石机关':'冲压机关');return;}
  if(h.type==='water'&&overlap(hurt,h)){die(s,L.theme==='haunt'?'幽井寒气':'能量池泄漏');return;}
  if(h.type==='laser'&&hs.on&&overlap(hurt,h)){die(s,L.theme==='alchemy'?'灵焰屏障':L.theme==='haunt'?'鬼火光栅':'激光屏障');return;}
  if(h.type==='dart'){
   if(p.x>h.x&&p.x<h.x+h.w&&p.y+p.h>760&&s.trapTimes[h.id]===undefined)s.trapTimes[h.id]=0;
   if(s.trapTimes[h.id]!==undefined){s.trapTimes[h.id]+=dt;const ph=s.trapTimes[h.id]%3.6;if(ph>.65&&ph<1.35&&overlap(hurt,{x:h.x+h.w-(ph-.65)*540,y:791,w:23,h:8})){die(s,'感应弩箭');return;}if(p.x<h.x-65||p.x>h.x+h.w+80)delete s.trapTimes[h.id];}
  }
  if(h.type==='crumble'){if(p.grounded&&p.x+p.w>h.x&&p.x<h.x+h.w&&p.y+p.h>815)s.cracks[h.id]=(s.cracks[h.id]||0)+dt;else s.cracks[h.id]=0;if(s.cracks[h.id]>.62){die(s,L.theme==='frost'?'薄冰破裂':'地板塌陷');return;}}
 }
 for(const cp of L.checkpoints)if(cp.id!==s.checkpoint&&Math.abs(p.x-cp.x)<32&&Math.abs(p.y+p.h-cp.y)<45){s.checkpoint=cp.id;s.checkpointLevel=L.id;p.hp=100;notice(s,'第 '+(L.id+1)+' 关 · '+cp.name+' 已保存，生命恢复');emit(s,'checkpoint');emit(s,'save');}
 for(const m of L.records)if(!s.memories.includes(m.id)&&Math.hypot(p.x+13-m.x,p.y+20-m.y)<35){s.memories.push(m.id);notice(s,'找到可选记录 '+s.memories.length+'/'+L.records.length);emit(s,'memory');emit(s,'save');}
 if(!Number.isFinite(p.x+p.y+p.vx+p.vy)){Object.assign(p,{x:oldX,y:oldY,vx:0,vy:0});respawn(s);}
}
function serialize(s){return{version:3,levelIndex:s.levelIndex,checkpointLevel:s.checkpointLevel,flags:s.flags,cells:s.cells,memories:s.memories,checkpoint:s.checkpoint,deaths:s.deaths,elapsed:s.elapsed,time:s.time,ghosts:s.ghosts,won:s.mode==='won'||s.previouslyWon===true,combat:{enemies:s.enemies.map(e=>({id:e.id,hp:e.hp})),blocks:s.blocks.map(b=>({id:b.id,hp:b.hp})),usedSupplies:s.usedSupplies,kills:s.kills}};}
function restore(d){if(!d||![2,3].includes(d.version)||!Number.isInteger(d.levelIndex)||!LEVELS[d.levelIndex])return fresh();const s=fresh(d.levelIndex),L=level(s);
 for(const o of L.switches)if(d.flags&&d.flags[o.id]===true)s.flags[o.id]=true;
 s.cells=Array.isArray(d.cells)?[...new Set(d.cells.filter(id=>L.cells.some(c=>c.id===id)))]:[];s.memories=Array.isArray(d.memories)?[...new Set(d.memories.filter(id=>L.records.some(c=>c.id===id)))]:[];
 s.checkpoint=Number.isInteger(d.checkpoint)&&L.checkpoints[d.checkpoint]&&(d.version===2||d.checkpointLevel===L.id)?d.checkpoint:0;s.checkpointLevel=L.id;for(const key of ['deaths','elapsed','time'])s[key]=Number.isFinite(d[key])?Math.max(0,d[key]):0;
 s.ghosts=Array.isArray(d.ghosts)?d.ghosts.filter(g=>Number.isFinite(g.x)&&Number.isFinite(g.y)&&g.x>=0&&g.x<L.width&&typeof g.cause==='string').slice(-32).map(g=>({...g,path:Array.isArray(g.path)?g.path.filter(v=>Number.isFinite(v.x)&&Number.isFinite(v.y)).slice(-68):[]})):[];
 if(d.combat&&d.version===3){for(const [key,items]of [['enemies',s.enemies],['blocks',s.blocks]])if(Array.isArray(d.combat[key]))for(const item of items){const old=d.combat[key].find(o=>o.id===item.id);if(old&&Number.isFinite(old.hp))item.hp=clamp(old.hp,0,item.maxHp);}s.usedSupplies=Array.isArray(d.combat.usedSupplies)?d.combat.usedSupplies.filter(id=>L.supplies.some(h=>h.id===id)):[];s.kills=s.enemies.filter(e=>e.hp<=0).length;}
 respawn(s);s.events=[];s.mode='title';s.previouslyWon=d.version===3&&!!d.won;return s;
}
const combatAPI={level,overlap,clamp,solids,emit,notice,die};
const api={LEVELS,THEMES,GRAVITY,SPEED,JUMP,clamp,overlap,level,fresh,start,step,die,respawn,solids,hazardState,interactions,interact,serialize,restore,record,disabled,returnCheckpoint,ROLES:Combat.ROLES};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.GhostEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this);
