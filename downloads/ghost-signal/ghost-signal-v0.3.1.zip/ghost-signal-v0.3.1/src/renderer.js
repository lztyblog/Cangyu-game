(function(root){'use strict';
const E=root.GhostEngine,WIDTH=1280,HEIGHT=720;
const C={ink:'#08131e',panel:'#112b3a',edge:'#346072',cyan:'#78f4ed',white:'#e2eeec',amber:'#ffbe6a',red:'#ff7379',muted:'#78959f'};
function createRenderer(canvas){
 const g=canvas.getContext('2d');let cam={x:0,y:220},shake=0,particles=[],tick=0,reduced=false;
 function rect(x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);}
 function line(x,y,x2,y2,c,w=1){g.strokeStyle=c;g.lineWidth=w;g.beginPath();g.moveTo(x,y);g.lineTo(x2,y2);g.stroke();}
 function text(t,x,y,size=14,c=C.white,align='left'){g.font=`${size}px "Microsoft YaHei", "PingFang SC", sans-serif`;g.fillStyle=c;g.textAlign=align;g.fillText(t,x,y);}
 function glow(x,y,r,c){const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,c);gr.addColorStop(1,'transparent');g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2);}
 function poly(points,c){g.fillStyle=c;g.beginPath();points.forEach((p,i)=>i?g.lineTo(...p):g.moveTo(...p));g.closePath();g.fill();}
 function actor(x,y,face,walk,ghost=false,alpha=1,role='mech',state={}){g.save();g.translate(x+13,y+21);g.globalAlpha=alpha;const stride=Math.sin(walk)*3;
  if(ghost){glow(0,0,45,'#65e9dc25');g.fillStyle=C.cyan;g.beginPath();g.arc(0,-8,13,Math.PI,0);g.lineTo(13,19);g.lineTo(6,13);g.lineTo(0,19);g.lineTo(-6,13);g.lineTo(-13,19);g.closePath();g.fill();rect(-7,-10,4,4,C.ink);rect(3,-10,4,4,C.ink);}
  else if(role==='mech'){rect(-12,-17,24,18,'#a9c3c8');rect(-10,-13,20,9,'#132e41');rect(-7,-11,14,4,'#7cfff3');rect(-13,2,26,13,'#658c99');rect(-8,5,16,5,C.amber);rect(-11,14,8,8+stride,'#b3cbcf');rect(3,14,8,8-stride,'#b3cbcf');rect(face>0?10:-23,1,13,7,'#b7d3d5');rect(face>0?22:-26,2,4,5,C.amber);line(-5,-18,-5,-25,'#71949e',2);rect(-7,-27,4,4,'#f49f7d');if(state.attackFlash>0)glow(face*27,5,23,'#ffc76d70');}
  else if(role==='alchemy'){poly([[-8,-3],[8,-3],[13,20],[0,16],[-13,21]],'#b7d2c2');poly([[-5,-2],[3,-2],[6,19],[-8,20]],'#427b79');rect(-7,-18,14,16,'#e2c7ae');rect(-9,-21,18,7,'#162831');rect(-5,-27,9,7,'#182c32');line(0,-26,9,-26,'#d0d8ad',2);rect(face>0?4:-8,-14,3,3,'#263f3f');line(face*9,4,face*31,-13,'#d6e3d9',3);line(face*9,4,face*16,10,'#b7a66f',2);line(-face*4,-3,-face*(21+stride),6,'#6daca2',3);rect(-8,18,6,5+stride,'#203b43');rect(3,18,6,5-stride,'#203b43');if(state.attackFlash>0)line(face*13,-3,face*42,-22,'#e2f6cc',3);}
  else if(role==='haunt'){glow(0,1,42,state.phase>0?'#c0a6ff40':'#a0bfff15');poly([[-12,-9],[-7,-21],[7,-21],[12,-9],[13,18],[5,13],[0,22],[-7,16],[-13,22]],'#b6a2d9');rect(-7,-12,4,4,'#f4edcf');rect(3,-12,4,4,'#f4edcf');line(-8,0,8,0,'#6b4b87',4);line(face*12,0,face*22,8,'#ceb5e0',2);rect(face*22-5,8,10,13,'#dfbf84');glow(face*22,14,28,'#f7d79130');rect(face*22-3,11,6,6,'#fff0bb');if(state.attackFlash>0)glow(face*25,-1,25,'#c0a8ff60');}
  else{g.fillStyle='#dcecf0';g.beginPath();g.arc(0,11,14,0,Math.PI*2);g.fill();g.beginPath();g.arc(0,-4,11,0,Math.PI*2);g.fill();g.beginPath();g.arc(0,-19,9,0,Math.PI*2);g.fill();rect(-8,-31,16,6,'#294252');rect(-11,-26,22,3,'#294252');rect(-10,-10,20,5,'#e29a84');rect(-9,-5,5,12,'#d58b7b');rect(-5,-21,3,3,'#1d3b52');rect(3,-21,3,3,'#1d3b52');poly([[face*6,-18],[face*17,-15],[face*6,-14]],'#ecba73');line(-10,0,-24,-7+stride,'#a5a3a0',2);line(10,0,24,-5-stride,'#a5a3a0',2);rect(-2,1,4,4,'#6b94a7');rect(-2,10,4,4,'#6b94a7');}
  g.restore();
 }
 function foe(e,s){if(e.hp<=0)return;const T=E.level(s).palette,theme=E.level(s).theme,scale=e.kind==='guardian'?1.6:1;g.save();g.translate(e.x+e.w/2,e.y+e.h);g.scale(scale,scale);const body=e.flash>0?'#fff0ca':e.stun>0?'#8bbbd5':theme==='mech'?'#a37674':theme==='haunt'?'#c4b8ab':theme==='alchemy'?'#798b75':'#77a4bd';
  if(theme==='haunt'){poly([[-14,-36],[0,-48],[14,-36],[12,-2],[0,-9],[-13,-1]],body);rect(-7,-31,4,6,'#603b55');rect(4,-31,4,6,'#603b55');rect(-8,-18,16,5,'#aa6d75');}
  else if(theme==='alchemy'){poly([[-15,-30],[-8,-43],[7,-43],[15,-30],[13,-3],[-13,-3]],body);poly([[-9,-37],[-18,-47],[-14,-29]],'#a8ac8e');poly([[8,-37],[17,-47],[13,-29]],'#a8ac8e');rect(-9,-27,6,4,'#e3c585');rect(3,-27,6,4,'#e3c585');rect(-6,-13,12,3,'#364b48');}
  else if(theme==='frost'){poly([[-17,-26],[-10,-44],[1,-37],[11,-44],[17,-22],[13,-3],[-12,-3]],body);rect(-9,-27,6,4,'#dff5fa');rect(3,-27,6,4,'#dff5fa');poly([[-6,-14],[6,-14],[0,-4]],'#d3e6e9');}
  else{rect(-14,-35,28,29,body);rect(-11,-31,22,9,'#142936');rect(-7,-28,14,3,'#ff9c8b');rect(-13,-5,8,5,'#8ba1a6');rect(5,-5,8,5,'#8ba1a6');rect(e.face>0?13:-23,-22,10,7,'#ba9d8c');}
  if(e.kind==='shield'&&e.stun<=0){g.strokeStyle='#ddc18d';g.lineWidth=4;g.beginPath();g.moveTo(e.face*20,-38);g.lineTo(e.face*24,-20);g.lineTo(e.face*20,-4);g.stroke();}
  if(e.stun>0){text('✦',0,-53,17,'#beefff','center');}else if(e.windup>0){poly([[-7,-60],[7,-60],[0,-48]],'#ff8d79');glow(0,-30,35,'#ff6c732b');}
  g.restore();const w=e.kind==='guardian'?80:40;rect(e.x+e.w/2-w/2,e.y-12,w,4,'#14222f');rect(e.x+e.w/2-w/2,e.y-12,w*Math.max(0,e.hp/e.maxHp),4,e.kind==='guardian'?C.amber:'#dc9d94');
 }
 function ufo(x,y,ready,time){glow(x,y-35,170,ready?'#73f3df25':'#ffbe6a15');
  g.fillStyle='#173746';g.beginPath();g.ellipse(x,y-46,47,29,0,Math.PI,0);g.fill();g.strokeStyle=ready?C.cyan:C.edge;g.lineWidth=2;g.stroke();
  g.fillStyle='#334d58';g.beginPath();g.ellipse(x,y-28,96,20,0,0,Math.PI*2);g.fill();line(x-72,y-25,x+72,y-25,C.muted,2);
  for(let i=0;i<5;i++)rect(x-55+i*25,y-30,9,4,ready?C.cyan:(i===2?C.amber:'#56676c'));
  line(x-48,y-12,x-58,y, C.muted,4);line(x+48,y-12,x+58,y,C.muted,4);
  if(ready)for(let i=0;i<3;i++)glow(x-35+i*35,y-7,25,'#69ffe740');
  text('CY–07',x,y-77,12,C.muted,'center');
 }
 function platform(q,s){const big=q.h>100,T=E.level(s).palette,kind=E.level(s).theme;
  if(kind==='haunt'){rect(q.x,q.y,q.w,q.h,T.ground);rect(q.x,q.y,q.w,5,'#a09080');for(let x=q.x+12;x<q.x+q.w;x+=42){line(x,q.y+5,x,q.y+q.h,'#51434a');line(x+5,q.y+12,x+28,q.y+12,'#66505a');}if(!big){rect(q.x+8,q.y+q.h,8,22,'#493945');rect(q.x+q.w-16,q.y+q.h,8,22,'#493945');}return;}
  if(kind==='alchemy'){if(big){rect(q.x,q.y,q.w,q.h,'#243c38');rect(q.x,q.y,q.w,7,'#6f8e6c');for(let x=q.x+25;x<q.x+q.w;x+=70)poly([[x,q.y+12],[x+35,q.y+35],[x+12,q.y+65]],'#314f44');}else{poly([[q.x,q.y],[q.x+q.w,q.y],[q.x+q.w-22,q.y+q.h+17],[q.x+20,q.y+q.h+12]],'#4b6457');rect(q.x,q.y,q.w,6,'#95ad87');for(let x=q.x+30;x<q.x+q.w-10;x+=55)line(x,q.y+q.h,x-4,q.y+q.h+24,'#6f8f6b',2);}return;}
  if(kind==='frost'){rect(q.x,q.y,q.w,q.h,T.ground);rect(q.x,q.y,q.w,7,'#b5d9e4');rect(q.x,q.y+7,q.w,3,'#6b9fb9');for(let x=q.x+15;x<q.x+q.w;x+=53){if(big)line(x,q.y+15,x+15,q.y+42,'#50788e');else poly([[x,q.y+q.h],[x+14,q.y+q.h],[x+7,q.y+q.h+17]],'#8ab9cd');}return;}
rect(q.x,q.y,q.w,q.h,E.level(s).palette.ground);rect(q.x,q.y,q.w,4,E.level(s).palette.edge);rect(q.x,q.y+4,q.w,4,'#334d53');
  if(big){for(let x=Math.ceil(q.x/96)*96;x<q.x+q.w;x+=96){line(x,q.y+12,x,q.y+q.h,'#213341');rect(x+8,q.y+24,55,4,'#172a37');}rect(q.x,q.y+75,q.w,2,'#263b45');}
  else{rect(q.x,q.y+q.h-5,q.w,5,'#0a1922');for(let x=q.x+12;x<q.x+q.w-10;x+=30)line(x,q.y+9,x+8,q.y+18,'#557078',3);}
  if(q.w>90)for(let x=q.x+20;x<q.x+q.w-15;x+=170)rect(x,q.y+2,17,2,C.cyan);
 }
 function drawBackground(s){const gr=g.createLinearGradient(0,0,0,HEIGHT);gr.addColorStop(0,E.level(s).palette.sky[0]);gr.addColorStop(.6,E.level(s).palette.sky[1]);gr.addColorStop(1,E.level(s).palette.sky[1]);g.fillStyle=gr;g.fillRect(0,0,WIDTH,HEIGHT);
  for(let i=0;i<85;i++){const x=((i*173.3-cam.x*.075)%1450+1450)%1450,y=((i*63.73)%390)-cam.y*.08;rect(x,y,i%7===0?2:1,i%7===0?2:1,i%7===0?'#5d9aab':'#355b73');}
  glow(1040-cam.x*.07,90,190,'#528e9d14');g.fillStyle='#9cbdb833';g.beginPath();g.arc(1080-cam.x*.07,90,42,0,Math.PI*2);g.fill();
  if(E.level(s).theme==='mech'){
  for(let i=-1;i<17;i++){const x=i*165-(cam.x*.18)%165,y=220+Math.sin(i*7)*60-cam.y*.15;rect(x,y,95,510,'#0b1c2b');rect(x+12,y-10,70,10,'#112738');line(x+20,y,x+20,y-65,'#203a49');for(let k=0;k<5;k++)rect(x+18+(k%2)*36,y+35+Math.floor(k/2)*38,9,5,'#274956');}
  for(let i=-1;i<9;i++){const x=i*290-(cam.x*.4)%290;rect(x,180-cam.y*.35,16,650,'#172c38');line(x+8,180-cam.y*.35,x+298,480-cam.y*.35,'#17323d',6);line(x+8,480-cam.y*.35,x+298,180-cam.y*.35,'#17323d',6);}
  }else{
   const kind=E.level(s).theme;
   for(let i=-1;i<10;i++){const x=i*230-(cam.x*.18)%230,base=680-cam.y*.14,peak=170+Math.sin(i*2.3)*60;
    poly([[x-100,base],[x+65,peak],[x+240,base]],kind==='frost'?'#426178':kind==='haunt'?'#221e32':'#28443f');
    if(kind==='frost')poly([[x+15,peak+80],[x+65,peak],[x+115,peak+80],[x+68,peak+65]],'#a7c1cb55');
   }
   if(kind==='haunt')for(let i=-1;i<10;i++){const x=i*180-(cam.x*.4)%180;rect(x,340-cam.y*.25,70,480,'#211b2d');poly([[x-25,340-cam.y*.25],[x+35,290-cam.y*.25],[x+95,340-cam.y*.25]],'#3a2d40');}
   if(kind==='alchemy')for(let i=0;i<5;i++){const x=((i*330-cam.x*.11)%1500+1500)%1500;g.fillStyle='#cde1c60b';g.beginPath();g.ellipse(x,200+i*44,130,16,0,0,Math.PI*2);g.fill();}
   if(kind==='frost')for(let i=0;i<55;i++){const x=((i*91-s.time*24-cam.x*.3)%1400+1400)%1400,y=((i*63+s.time*14)%700);rect(x,y,2,2,'#c3e8ed77');}
  }
  rect(0,660-cam.y*.2,WIDTH,100,'#0e2730');
 }
 function drawWorld(s){const L=E.level(s),t=s.time,T=L.palette;
  if(L.theme==='mech')for(let x=500;x<L.width;x+=550){rect(x,480,10,340,'#193c48');rect(x-55,474,120,10,'#395764');rect(x-35,484,80,3,T.glow);}
  if(L.theme==='haunt')for(let x=420;x<L.width;x+=370){rect(x,470,12,350,'#403841');line(x-50,470,x+65,470,'#68525c',6);line(x+5,470,x+5,510,'#a09083');glow(x+5,526,90,'#dfbe7d20');rect(x-6,510,23,32,'#b59b71');rect(x-3,515,17,21,'#efd9a3');}
  if(L.theme==='alchemy')for(let x=500;x<L.width;x+=440){line(x,750,x,660,'#527665',4);glow(x,641,65,'#c3ed9620');poly([[x-14,654],[x,624],[x+14,654]],'#bde5a4');}
  if(L.theme==='frost')for(let x=430;x<L.width;x+=390){poly([[x,820],[x+30,690],[x+60,820]],'#426984');poly([[x+14,820],[x+40,745],[x+75,820]],'#6e9aad');}
  for(const q of E.solids(s))if(q.maxHp===undefined&&q.x+q.w>cam.x-30&&q.x<cam.x+WIDTH+30)platform(q,s);
  // Closed gates belong to the collision geometry; open gates are visibly raised.
  for(const gate of L.gates){const on=s.relayCharge[gate.id]>0;rect(gate.x-8,gate.y-12,gate.w+16,12,'#67838d');if(on){rect(gate.x,gate.y,gate.w,25,T.glow);glow(gate.x,gate.y+20,55,'#b6cfff20');}else{for(let y=gate.y+10;y<gate.y+gate.h;y+=23)rect(gate.x+4,y,gate.w-8,3,'#b7b1e0');}text(on?'共鸣门开启':'影子 · 共鸣门',gate.x,gate.y-25,11,on?T.glow:'#c6b3e0','center');}
  for(const h of L.hazards){const hs=E.hazardState(s,h),off=E.disabled(s,h);
   if(h.type==='spike'){for(let x=h.x;x<h.x+h.w;x+=13)poly([[x,820],[x+6,805],[x+12,820]],L.theme==='frost'?'#c1e7ed':'#c7b6a0');}
   if(h.type==='pit'){rect(h.x,930,h.w,110,'#020711');for(let x=h.x;x<h.x+h.w;x+=30)line(x,935,x+12,946,'#836e66',4);}
   if(h.type==='press'){rect(h.x-5,463,h.w+10,22,'#68717c');rect(h.x+24,485,24,hs.bottom-485,'#4c606a');rect(h.x,hs.bottom-23,h.w,23,off?'#3f6c61':L.theme==='haunt'?'#68505c':'#876d63');for(let x=h.x+5;x<h.x+h.w-10;x+=20)line(x,hs.bottom-22,x+15,hs.bottom-5,off?T.glow:T.accent,5);rect(h.x+8,472,12,6,off?T.glow:hs.warning?C.red:T.accent);if(hs.warning&&!off)glow(h.x+36,480,75,'#ff75894a');}
   if(h.type==='laser'){rect(h.x-10,725,30,10,'#57717c');rect(h.x-10,813,30,7,'#57717c');if(hs.on){rect(h.x,735,h.w,78,C.red);rect(h.x+4,735,2,78,'#ffe3d2');glow(h.x,773,65,'#ff7b6925');}else{rect(h.x-3,729,15,3,off?T.glow:hs.warning?T.accent:'#596b74');if(hs.warning)line(h.x+5,735,h.x+5,812,'#9e7265');}}
   if(h.type==='water'){rect(h.x,h.y+10,h.w,8,off?'#3d655f':'#477d8b');if(!off)for(let x=h.x;x<h.x+h.w;x+=25)line(x,h.y+6+Math.sin(t*13+x)*3,x+14,h.y+Math.cos(t*10+x)*4,T.glow,2);}
   if(h.type==='dart'){rect(h.x,816,45,4,'#958575');rect(h.x+h.w,782,25,38,'#445764');rect(h.x+h.w-3,791,9,8,'#030a11');const ph=(s.trapTimes[h.id]||0)%3.6;if(s.trapTimes[h.id]!==undefined){if(ph<.65){rect(h.x+8,812,24,3,C.red);glow(h.x+h.w,791,50,'#fa885f25');}else if(ph<1.35){const dx=h.x+h.w-(ph-.65)*540;line(dx,795,dx+23,795,T.accent,3);}}}
   if(h.type==='crumble'){rect(h.x,820,h.w,5,L.theme==='frost'?'#addcea':'#afa28c');for(let x=h.x+10;x<h.x+h.w;x+=22)line(x,821,x+9,830,'#142330',2);if(s.cracks[h.id]>0){glow(h.x+h.w/2,820,80,'#ffb47a25');text('咔…',h.x+h.w/2,790,13,T.accent,'center');}}
  }
  for(const w of L.winds){for(let i=0;i<17;i++){const wx=w.x+(i*37)%w.w,wy=w.y+w.h-((t*100+i*51)%w.h);line(wx,wy,wx,wy-12,'#a2d9aa55',1);}text('上升气流',w.x+w.w/2,w.y+10,11,T.glow,'center');}
  for(const area of L.areas||[]){if(area.x+650<cam.x||area.x>cam.x+WIDTH)continue;text(area.name,area.x,area.y,21,T.edge);text(area.hint,area.x,area.y+27,12,C.muted);line(area.x,area.y+42,area.x+300,area.y+42,T.ground,2);}
  for(const b of s.blocks||[])if(b.hp>0){rect(b.x,b.y,b.w,b.h,'#74685e');rect(b.x+3,b.y+3,b.w-6,b.h-6,'#514b49');line(b.x+4,b.y+7,b.x+b.w-4,b.y+b.h-7,T.accent,3);line(b.x+b.w-4,b.y+7,b.x+4,b.y+b.h-7,T.accent,3);text('J 破坏',b.x+b.w/2,b.y-13,11,T.accent,'center');if(b.hp<b.maxHp)rect(b.x,b.y-5,b.w*b.hp/b.maxHp,3,T.glow);}
  for(const h of L.supplies||[])if(!s.usedSupplies.includes(h.id)){rect(h.x-11,h.y-9,22,18,'#b4d1bb');rect(h.x-7,h.y-2,14,4,'#3c7969');rect(h.x-2,h.y-6,4,12,'#3c7969');}
  for(const e of s.enemies||[])if(e.x>cam.x-100&&e.x<cam.x+WIDTH+100)foe(e,s);
  for(const q of s.projectiles||[]){g.save();g.translate(q.x+q.w/2,q.y+q.h/2);g.rotate(Math.atan2(q.vy,q.vx));g.globalAlpha=q.owner==='echo'?.5:1;if(q.owner==='enemy'){glow(0,0,23,'#ff7e7940');rect(-8,-3,16,6,'#ff9684');}else if(q.theme==='frost'){g.fillStyle='#d5f4f7';g.beginPath();g.arc(0,0,7,0,Math.PI*2);g.fill();}else if(q.theme==='alchemy'){line(-16,0,20,0,'#e5f5d5',4);line(-10,-7,-10,7,T.accent,2);}else{glow(0,0,25,q.theme==='haunt'?'#d5b5fc35':'#8ceefc35');rect(-9,-3,18,6,q.theme==='haunt'?'#d9b7ef':T.glow);}g.restore();}
  for(const sw of s.swings||[]){g.save();g.globalAlpha=sw.echo?.4:.8;g.strokeStyle=T.glow;g.lineWidth=4;g.beginPath();g.arc(sw.x,sw.y,72,sw.face>0?-1.1:2.04,sw.face>0?1.1:4.24);g.stroke();g.restore();}
  for(const cp of L.checkpoints){const active=cp.id===s.checkpoint;rect(cp.x-9,cp.y-56,18,56,L.theme==='haunt'?'#594853':'#34515b');rect(cp.x-5,cp.y-51,10,28,active?T.glow:'#62898d');glow(cp.x,cp.y-37,active?85:35,active?'#a2ffe01b':'#72a6b010');}
  for(const o of L.switches){const done=s.flags[o.id];rect(o.x-15,o.y-48,30,48,'#3d4e57');rect(o.x-10,o.y-43,20,14,done?T.glow:T.accent);line(o.x,o.y-13,o.x+(done?8:-8),o.y-26,done?T.glow:T.accent,3);text(done?'已启用':'E',o.x,o.y-59,11,done?C.muted:T.accent,'center');}
  for(const r of L.relays){const on=s.relayCharge[r.id]>0;rect(r.x-r.w/2,816,r.w,4,on?T.glow:'#b49bc9');glow(r.x,812,80,on?'#b0f3e620':'#b6a2dd0e');text('共鸣踏板 · Q 留影 / E 回放',r.x,790,11,'#c9b6df','center');}
  for(const c of L.cells){rect(c.x-23,c.y+32,46,5,'#57717a');if(s.cells.includes(c.id)){text('已取走',c.x,c.y+12,11,C.muted,'center');continue;}glow(c.x,c.y,80,'#ffc66d25');g.save();g.translate(c.x,c.y+Math.sin(t*3+c.id)*4);if(L.theme==='haunt'){rect(-9,-16,18,27,T.accent);rect(-5,-12,10,10,'#594248');rect(3,11,11,5,T.accent);}else if(L.theme==='alchemy')poly([[-11,12],[-7,-4],[0,-23],[3,-5],[10,-11],[13,13]],T.accent);else poly([[0,-19],[12,-7],[12,11],[0,20],[-12,11],[-12,-7]],T.accent);g.restore();text(c.name,c.x,c.y-32,12,T.accent,'center');}
  for(const m of L.records)if(!s.memories.includes(m.id)){glow(m.x,m.y,36,'#bdc9ff1a');rect(m.x-9,m.y-6,18,12,'#bbced3');rect(m.x-5,m.y-3,10,4,'#314757');text('记录',m.x,m.y-18,10,'#a8bac6','center');}
  for(const ghost of s.ghosts){const near=Math.hypot(ghost.x-s.player.x,ghost.y-s.player.y)<150;actor(ghost.x-13,ghost.y-21+Math.sin(t*2+ghost.time)*3,1,0,true,near?.65:.24);if(near)text(ghost.cause,ghost.x,ghost.y-40,11,T.glow,'center');}
  if(s.replay){const path=s.replay.ghost.path,idx=Math.min(path.length-1,Math.floor(s.replay.t/.045));g.save();g.globalAlpha=.26;g.setLineDash([4,6]);g.beginPath();path.forEach((p,i)=>i?g.lineTo(p.x+13,p.y+20):g.moveTo(p.x+13,p.y+20));g.strokeStyle=T.glow;g.lineWidth=2;g.stroke();g.restore();if(path[idx])actor(path[idx].x,path[idx].y,path[idx].face,0,true,.9);}
  const ex=L.exit.x,ey=L.exit.y,ready=s.cells.length===L.cells.length;
  if(L.theme==='mech')ufo(ex,ey,ready,t);
  else if(L.theme==='haunt'){rect(ex-52,ey-145,16,145,'#65505b');rect(ex+36,ey-145,16,145,'#65505b');rect(ex-67,ey-153,134,13,'#9b7d77');rect(ex-36,ey-136,72,136,ready?'#1b403d':'#3b293b');line(ex,ey-136,ex,ey,'#9d7f79',2);glow(ex,ey-65,100,ready?'#a8f8c928':'#c7917112');}
  else if(L.theme==='alchemy'){poly([[ex-80,ey-22],[ex-53,ey-4],[ex+54,ey-4],[ex+84,ey-28]],'#8b7e67');line(ex,ey-25,ex,ey-120,'#c4c3a4',3);poly([[ex+3,ey-118],[ex+3,ey-42],[ex+60,ey-51]],ready?'#d9deab':'#698c86');glow(ex,ey-45,100,ready?'#cef4b125':'#a6e6be0b');}
  else{line(ex-70,ey-4,ex+72,ey-4,'#c1d9dd',4);line(ex-70,ey-4,ex-82,ey-16,'#c1d9dd',4);rect(ex-42,ey-39,85,27,'#877774');rect(ex-30,ey-65,63,27,'#9cafb7');rect(ex+29,ey-36,14,14,ready?T.accent:'#586a77');glow(ex,ey-35,100,ready?'#ffcb9d25':'#8ae5ff0a');}
  text(ready?'E · 离开这里':'找到'+L.cells.length+'枚'+T.resource,ex,ey-175,13,ready?T.glow:C.muted,'center');
  for(const p of particles){g.globalAlpha=Math.max(0,p.life);if(p.text)text(p.text,p.x,p.y,14,p.color,'center');else rect(p.x,p.y,p.size,p.size,p.color);g.globalAlpha=1;}
  if(s.mode!=='dead')actor(s.player.x,s.player.y,s.player.face,Math.abs(s.player.vx)>25?t*16:0,false,(s.grace>0||s.player.invuln>0)?.55+.35*Math.sin(t*40):s.player.phase>0?.5:1,L.theme,s.player);
  if(s.player.skillFlash>0){g.strokeStyle=T.glow;g.lineWidth=3;g.globalAlpha=s.player.skillFlash*2;g.beginPath();g.ellipse(s.player.x+13,s.player.y+20,130*(1-s.player.skillFlash),50,0,0,Math.PI*2);g.stroke();g.globalAlpha=1;}
  const it=E.interactions(s)[0];if(it&&s.mode==='playing'){const w=Math.min(370,it.label.length*14+52),x=E.clamp(it.x-w/2,cam.x+15,cam.x+WIDTH-w-15);rect(x,it.y-28,w,34,'#071923eb');g.strokeStyle='#60818c';g.strokeRect(x,it.y-28,w,34);text('E  '+it.label,x+12,it.y-6,13,C.white);}
 }
 function render(s,dt=1/60,opts={}){reduced=!!opts.reduced;tick+=dt;const L=E.level(s);C.cyan=L.palette.glow;C.amber=L.palette.accent;
  const targetX=E.clamp(s.player.x-470,0,Math.max(0,E.level(s).width-WIDTH)),targetY=E.clamp(s.player.y-420,0,320);const ease=1-Math.exp(-dt*8);cam.x+=(targetX-cam.x)*(reduced?1:ease);cam.y+=(targetY-cam.y)*(reduced?1:ease);
  for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=600*dt;p.life-=dt*1.9;}particles=particles.filter(p=>p.life>0);shake=Math.max(0,shake-dt*25);
  g.save();drawBackground(s);g.translate(-cam.x+(reduced?0:Math.sin(tick*77)*shake),-cam.y+(reduced?0:Math.cos(tick*61)*shake));drawWorld(s);g.restore();
  const vg=g.createRadialGradient(640,340,200,640,360,750);vg.addColorStop(0,'transparent');vg.addColorStop(1,'#01071199');g.fillStyle=vg;g.fillRect(0,0,WIDTH,HEIGHT);
  rect(22,22,355,64,'#071622e6');rect(22,22,3,64,C.amber);text(String(s.levelIndex+1).padStart(2,'0')+' / '+L.name,39,48,17,C.white);text(L.palette.name+'  ·  '+L.palette.resource+' '+s.cells.length+'/'+L.cells.length,39,70,12,C.muted);
  rect(1030,22,228,64,'#071622e6');text('死亡 '+s.deaths+'    记录 '+s.memories.length+'/'+L.records.length,1241,48,14,C.white,'right');text('J 攻击 · K 技能 · Q 留影',1241,70,11,C.muted,'right');
  line(401,47,999,47,'#496677',2);for(const c of L.cells){const x=401+c.x/L.width*598;rect(x-4,43,8,8,s.cells.includes(c.id)?C.amber:'#6a818d');}const px=401+s.player.x/L.width*598;rect(px-3,40,6,14,C.cyan);text('入口',401,70,10,C.muted);text(L.exit.label+' →',999,70,10,C.muted,'right');
  rect(22,620,390,77,'#071622eb');text(L.role,38,643,14,C.white);text('生命 '+Math.ceil(s.player.hp)+'/100',393,643,12,s.player.hp<35?C.red:C.cyan,'right');rect(38,653,355,7,'#33424c');rect(38,653,355*s.player.hp/100,7,s.player.hp<35?C.red:C.cyan);text('J '+E.ROLES[L.theme].attack+'   K '+E.ROLES[L.theme].skill+(s.skillCD>0?' '+s.skillCD.toFixed(1)+'s':' 就绪')+'   Q 留影',38,682,12,C.muted);
  const boss=s.enemies.find(e=>e.id==='guardian'&&e.hp>0);if(boss&&Math.abs(boss.x-s.player.x)<750){rect(465,654,390,39,'#1d1d2be8');text('守门者',481,671,12,C.amber);rect(550,665,285,7,'#4d3c44');rect(550,665,285*boss.hp/boss.maxHp,7,'#d69989');}
  if(s.noticeFor>0){const alpha=Math.min(1,s.noticeFor*2);g.globalAlpha=alpha;const w=Math.min(920,s.notice.length*15+48);rect((WIDTH-w)/2,105,w,40,'#0c2530ed');text(s.notice,WIDTH/2,131,14,C.white,'center');g.globalAlpha=1;}
  if(s.mode==='dead'){rect(0,0,WIDTH,HEIGHT,'#100c192e');text('信号中断',640,294,30,'#ffe0d8','center');text('即将返回检查点 · 能源与机关状态已保留',640,327,14,C.white,'center');}
  if(s.mode==='won'){const lift=Math.min(450,tick*8);glow(640,360,400,'#78f4ed0d');}
 }
 function effect(event){if(event.type==='impact'){particles.push({x:event.x,y:event.y,vx:0,vy:-35,life:.8,size:0,color:event.shield?'#98c0d1':'#f5d19a',text:String(event.amount)});}if(event.type==='hurt'){shake=4;}if(['enemy-down','break'].includes(event.type)){for(let i=0;i<14;i++)particles.push({x:event.x,y:event.y,vx:Math.cos(i*2.4)*90,vy:-80-i*8,life:.8,size:3,color:C.amber});}if(event.type==='death'){shake=7;for(let i=0;i<24;i++)particles.push({x:event.x+13,y:event.y+20,vx:Math.cos(i*2.4)*(60+i*6),vy:-100-Math.sin(i*4)*130,life:1,size:2+i%3,color:i%2?C.cyan:C.amber});}
  if(event.type==='cell'||event.type==='checkpoint')shake=1;
  if(event.type==='teleport'){cam.x=0;cam.y=220;}
 }
 function snap(s){cam.x=E.clamp(s.player.x-470,0,Math.max(0,E.level(s).width-WIDTH));cam.y=E.clamp(s.player.y-420,0,320);}
 return {render,effect,snap,cam};
}
root.createGhostRenderer=createRenderer;
})(typeof globalThis!=='undefined'?globalThis:this);
