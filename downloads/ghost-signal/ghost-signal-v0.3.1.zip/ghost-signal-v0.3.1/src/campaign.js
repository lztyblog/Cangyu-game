(function(root){'use strict';
const E=typeof module!=='undefined'&&module.exports?require('./engine.js'):root.GhostEngine;
function normalise(raw){if(!raw||![2,3].includes(raw.version)||!raw.saves||typeof raw.saves!=='object')throw Error('不是有效的游戏存档');const c={version:3,current:0,saves:{},completed:{}};
 for(let i=0;i<E.LEVELS.length;i++){const d=raw.saves[i];if(d&&d.levelIndex===i&&[2,3].includes(d.version))c.saves[i]=E.serialize(E.restore(d));const old=raw.completed&&raw.completed[i];if(old&&Number.isFinite(old.deaths)&&Number.isFinite(old.records))c.completed[i]={deaths:Math.max(0,old.deaths),records:Math.max(0,old.records)};}
 if(Number.isInteger(raw.current)&&E.LEVELS[raw.current])c.current=raw.current;return c;
}
function fresh(){return{version:3,current:0,saves:{},completed:{}};}
function capture(c,s){c.current=s.levelIndex;c.saves[s.levelIndex]=E.serialize(s);c.version=3;return c;}
function stateFor(c,index,restart=false){if(!Number.isInteger(index)||!E.LEVELS[index])throw Error('无效关卡');const d=c.saves[index];const s=!restart&&d&&d.levelIndex===index&&!d.won?E.restore(d):E.fresh(index);if(s.levelIndex!==index)throw Error('存档关卡不一致');return s;}
const api={normalise,fresh,capture,stateFor};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.GhostCampaign=api;
})(typeof globalThis!=='undefined'?globalThis:this);
