(function(root){'use strict';
function createAudio(){let ctx=null,master=null,musicBus=null,fxBus=null,muted=false,paused=true,next=0,beat=0,available=true,theme=0;
 function tone(freq,t,d,type,vol,bus,end){if(!ctx)return;const o=ctx.createOscillator(),v=ctx.createGain();o.type=type;o.frequency.setValueAtTime(freq,t);if(end)o.frequency.exponentialRampToValueAtTime(Math.max(25,end),t+d);v.gain.setValueAtTime(.0001,t);v.gain.exponentialRampToValueAtTime(Math.max(.0002,vol),t+.012);v.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(v);v.connect(bus||fxBus);o.start(t);o.stop(t+d+.03);}
 async function unlock(){try{if(!ctx){const AC=root.AudioContext||root.webkitAudioContext;if(!AC){available=false;return false;}ctx=new AC();master=ctx.createGain();master.gain.value=muted?0:.42;master.connect(ctx.destination);musicBus=ctx.createGain();musicBus.gain.value=.32;musicBus.connect(master);fxBus=ctx.createGain();fxBus.gain.value=.7;fxBus.connect(master);next=ctx.currentTime;}
  if(ctx.state==='suspended')await ctx.resume();return true;}catch(_){available=false;return false;}}
 function schedule(){if(!ctx||ctx.state!=='running'||paused||muted){if(ctx)next=ctx.currentTime+.05;return;}
  const palettes=[[146.83,220,293.66,349.23,146.83,261.63,220,174.61,130.81,196,261.63,329.63,130.81,220,196,164.81],[130.81,155.56,196,233.08,130.81,196,155.56,116.54,123.47,146.83,185,220,123.47,185,146.83,110],[174.61,196,261.63,293.66,349.23,293.66,261.63,196,146.83,174.61,220,293.66,261.63,220,196,174.61],[196,246.94,293.66,369.99,392,293.66,246.94,196,164.81,220,261.63,329.63,293.66,261.63,220,164.81]];const notes=palettes[theme];
  while(next<ctx.currentTime+.28){const n=notes[beat%16];tone(n,next,.5,'sine',.11,musicBus);if(beat%4===0){tone(n/2,next,1.45,'triangle',.12,musicBus);tone(n*2,next,.9,'sine',.035,musicBus);}beat++;next+=(theme===1?.4:theme===2?.32:.3);}}
 function effect(type,theme){if(!ctx||muted||paused)return;const t=ctx.currentTime;
  if(type==='attack'){if(theme==='alchemy')tone(750,t,.11,'triangle',.08,null,240);else if(theme==='haunt')tone(430,t,.2,'sine',.09,null,720);else if(theme==='frost')tone(180,t,.1,'triangle',.08,null,90);else tone(340,t,.08,'square',.055,null,150);}
  if(type==='skill'){tone(130,t,.35,'triangle',.12,null,520);tone(440,t+.08,.4,'sine',.1);}
  if(type==='hurt')tone(100,t,.18,'sawtooth',.08,null,45);
  if(type==='break'||type==='enemy-down')tone(110,t,.2,'triangle',.08,null,35);
  if(type==='stomp')tone(70,t,.28,'triangle',.13,null,28);
  if(type==='heal'){tone(440,t,.2,'sine',.07);tone(659.25,t+.09,.3,'sine',.07);}
  if(type==='jump')tone(190,t,.13,'sine',.14,null,340);
  if(type==='land')tone(80,t,.075,'triangle',.15,null,45);
  if(type==='death'){tone(210,t,.32,'sawtooth',.11,null,35);tone(80,t,.45,'triangle',.19,null,25);}
  if(type==='switch'){tone(210,t,.08,'square',.06);tone(330,t+.09,.15,'sine',.11);}
  if(type==='cell'||type==='memory')for(let i=0;i<4;i++)tone([293.66,369.99,440,587.33][i],t+i*.09,.38,'sine',.14);
  if(type==='checkpoint'){tone(392,t,.22,'sine',.09);tone(523.25,t+.12,.32,'sine',.09);}
  if(type==='ghost')tone(520,t,.7,'sine',.08,null,180);
  if(type==='teleport')tone(110,t,.7,'sine',.12,null,660);
  if(type==='win')for(let i=0;i<6;i++)tone([220,293.66,349.23,440,587.33,698.46][i],t+i*.15,1.1,'sine',.15);
 }
 function setPaused(v){paused=v;if(ctx){next=ctx.currentTime+.05;musicBus.gain.setTargetAtTime(v?0:.32,ctx.currentTime,.05);}}
 function setMuted(v){muted=v;if(ctx)master.gain.setTargetAtTime(v?0:.42,ctx.currentTime,.025);}
 return {unlock,schedule,effect,setPaused,setMuted,setTheme(v){theme=Math.max(0,Math.min(3,v||0));beat=0;},get available(){return available;},get muted(){return muted;}};
}
root.createGhostAudio=createAudio;
})(typeof globalThis!=='undefined'?globalThis:this);
