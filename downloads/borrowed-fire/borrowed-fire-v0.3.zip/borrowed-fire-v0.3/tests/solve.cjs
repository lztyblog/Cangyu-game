const E=require('../src/engine.js'),assert=require('node:assert/strict');
const DT=1/120;
function step(s,input={}){E.step(s,input,DT);s.events=[];}
function aim(s,obj){const c=E.center(s.player),t=E.center(obj);return{aimX:t.x-c.x,aimY:t.y-c.y,targetX:t.x,targetY:t.y,shield:true};}
function move(s,x,jump=false){let begun=false,departed=false,landed=false;const deaths=s.deaths;
 for(let n=0;n<1500;n++){const p=s.player,d=x-p.x,brake=p.vx*p.vx/4600+2;let axis=Math.abs(d)>brake?Math.sign(d):0;if(Math.abs(d)>8&&Math.sign(p.vx)!==Math.sign(d))axis=Math.sign(d);const input={left:axis<0,right:axis>0,shield:true,aimX:1,aimY:0,targetX:p.x+900,targetY:p.y+23,jump:jump&&!begun};begun=true;step(s,input);if(!p.grounded)departed=true;if(departed&&p.grounded)landed=true;if(s.deaths!==deaths)throw Error('Died moving to '+x);if(Math.abs(d)<8&&Math.abs(p.vx)<35&&p.grounded&&(!jump||landed))return;}
 throw Error('Stuck '+x+' at '+JSON.stringify(s.player));}
function solve(index){const s=E.fresh(index);E.start(s);for(let n=0;n<60;n++)step(s);for(const a of E.level(s).route){move(s,a.x,a.jump);if(a.charge){const r=s.receivers.find(r=>r.id===a.aim),deaths=s.deaths;let n=0;while(r.charge<r.need&&n++<4800)step(s,aim(s,r));assert(r.charge>=r.need,'No charge '+r.id+' p'+s.player.x+' enemy '+JSON.stringify(s.enemies));assert.equal(s.deaths,deaths,'Died charging '+r.id);}}
 move(s,E.level(s).exit.x-15);step(s,{interact:true});assert.equal(s.mode,'won');return s;}
if(require.main===module){const results=[];for(let i=0;i<6;i++){try{const s=solve(i);results.push({level:i+1,seconds:+s.elapsed.toFixed(1),reflections:s.reflections,kills:s.kills,deaths:s.deaths});console.log('PASS',i+1,JSON.stringify(results.at(-1)));}catch(e){console.error('FAIL',i+1,e.message);process.exitCode=1;}}const fs=require('node:fs'),file=require('node:path').join(__dirname,'../validation.json'),report=fs.existsSync(file)?JSON.parse(fs.readFileSync(file)):{};fs.writeFileSync(file,JSON.stringify({...report,solutions:results,browserQA:false},null,2));}
module.exports={solve,move,step,aim};
