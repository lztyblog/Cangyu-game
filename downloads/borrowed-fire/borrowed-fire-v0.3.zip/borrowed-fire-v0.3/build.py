from pathlib import Path
ROOT=Path(__file__).resolve().parent
page=(ROOT/'src/template.html').read_text(encoding='utf-8')
for marker,name in [('LEVELS','levels'),('ENGINE','engine'),('RENDERER','renderer'),('AUDIO','audio'),('UI','ui')]:
    source=(ROOT/f'src/{name}.js').read_text(encoding='utf-8')
    assert '</script' not in source.lower()
    page=page.replace(f'/* {marker} */',source)
assert '/* UI */' not in page
(ROOT/'index.html').write_text(page,encoding='utf-8')
print(f'Built standalone game: {len(page.encode())} bytes')
