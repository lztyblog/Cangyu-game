(function(root){'use strict';
const PALETTES=[
 {name:'废电站',sky:['#12242d','#355254'],metal:'#56716e',light:'#b8f1cf',accent:'#ffbd73',dust:'#e5c7a3'},
 {name:'铸造回廊',sky:['#2a2026','#614844'],metal:'#8b6b60',light:'#ffe0a3',accent:'#f39a72',dust:'#b5a399'},
 {name:'高架温室',sky:['#172d30','#4e6a5b'],metal:'#6d8a71',light:'#c9ecb2',accent:'#e8bd7c',dust:'#a8c5b2'},
 {name:'暴雨货场',sky:['#142330','#344b61'],metal:'#617e90',light:'#b7e7f4',accent:'#eead87',dust:'#afc5d1'},
 {name:'燃料仓库',sky:['#2b232b','#684a45'],metal:'#87645c',light:'#f5d7a1',accent:'#ff9475',dust:'#dab294'},
 {name:'最后的天线',sky:['#19253a','#4d576a'],metal:'#7e8a9c',light:'#d8e1f0',accent:'#ffc88c',dust:'#b7bad0'}
];
const SPECS=[
 ['请向我开炮','举盾不用卡瞬间。瞄准高处的线圈，借炮弹替它充电。',2,[],['bolt','bolt']],
 ['让他们自己解决','炮弹也会打中其他敌人。把他们的火力，引到你想要的位置。',2,[1],['burst','heavy']],
 ['从楼上绕过去','下层有障碍，上层有路。箱子能推，也能用震荡推走。',3,[0,2],['bolt','drone','heavy']],
 ['雨里的一条斜线','反射板可以改变炮弹路线。靠近按 E 转动它，也可以自己举盾瞄准。',3,[1],['burst','heavy','drone']],
 ['连锁反应','爆炸桶能炸开薄墙，也能给附近线圈充电。离远一点再点火。',3,[0,1,2],['mortar','burst','heavy']],
 ['把出口轰开','三段供电，三处选择。借敌人的火力，把最后一扇门打开。',3,[0,2],['heavy','drone','mortar']]
];
function build(i){const [name,hint,count,walls,kinds]=SPECS[i],L={id:i,name,hint,palette:PALETTES[i],width:count*930+300,height:1080,start:{x:130,y:774},platforms:[],walls:[],gates:[],receivers:[],enemies:[],crates:[],barrels:[],mirrors:[],chips:[],supplies:[],checkpoints:[],route:[]};
 L.platforms.push({id:'floor',x:0,y:820,w:L.width,h:260,kind:'floor'});
 L.checkpoints.push({id:0,x:145,y:820,name:'入口'});
 for(let a=0;a<count;a++){
  const b=a*930,rid='r'+a;
  L.receivers.push({id:rid,x:b+440+(i>=2&&a===1?65:0),y:684-(i===2&&a===1?35:0)-(i===5?35:0),w:40,h:64,need:i===0?2:3,label:'供电 '+(a+1)});
  L.gates.push({id:'gate'+a,x:b+865,y:650,w:30,h:170,receiver:rid});
  L.enemies.push({id:'gun'+a,kind:kinds[a],x:b+690,y:kinds[a]==='drone'?610:770,w:44,h:50,hp:kinds[a]==='heavy'?150:90,range:760,period:kinds[a]==='burst'?2.3:kinds[a]==='mortar'?2.5:1.9,anchor:b+690});
  L.checkpoints.push({id:a+1,x:b+100,y:820,name:'供电区 '+(a+1)});
  L.supplies.push({id:'med'+a,x:b+755,y:793,amount:40});
  // The ground route and upper bypass coexist. Upper shelves contain optional chips.
  const high=i===2||i===3||i===5;
  L.platforms.push({id:'step'+a,x:b+205,y:734,w:120,h:20,kind:'shelf'},{id:'shelf'+a,x:b+340,y:620,w:160,h:20,kind:'shelf'});
  if(high)L.platforms.push({id:'upper'+a,x:b+530,y:570,w:220,h:22,kind:'shelf'},{id:'back'+a,x:b+760,y:660,w:110,h:20,kind:'shelf'});
  L.chips.push({id:'chip'+a,x:b+420,y:590});
  if(walls.includes(a))L.walls.push({id:'wall'+a,x:b+570,y:720,w:40,h:100,hp:60});
  if(i>=1)L.crates.push({id:'box'+a,x:b+275,y:768,w:50,h:52});
  if(i>=2||a===1)L.barrels.push({id:'barrel'+a,x:b+(i===4?500:645),y:780,w:28,h:40,hp:25});
  if(i>=1&&a%2===0)L.enemies.push({id:'crawler'+a,kind:'crawler',x:b+780,y:774,w:34,h:46,hp:80,range:45,period:2,anchor:b+780});
  if(i>=3)L.mirrors.push({id:'mirror'+a,x:b+350,y:690,angle:a%2?Math.PI/4:-Math.PI/4,len:70});
  // Recorded routes used by the verifier. They are also physically playable routes.
  L.route.push({x:b+160},{x:b+260,jump:true},{x:b+(kinds[a]==='drone'?540:365),aim:rid,charge:true},{x:b+520},{x:b+660,jump:true},{x:b+810},{x:b+985});
 }
 if(i===4)L.barrels.push({id:'chain-a',x:1425,y:780,w:28,h:40,hp:25},{id:'chain-b',x:1510,y:780,w:28,h:40,hp:25});
 L.exit={x:L.width-125,y:820,w:65,h:105};return L;
}
function authored(id,name,palette,width=3200,height=1120){return{id,name,palette:{...PALETTES[palette],name:['蓄能转运站','折光天井','重装货仓','中枢换乘站'][id-6]},hint:'先观察这一区的地形，再决定借来的火力用在哪里。',chapter:'进阶设施',width,height,start:{x:140,y:774},platforms:[{id:'floor',x:0,y:820,w:width,h:height-820,kind:'floor'}],walls:[],gates:[],receivers:[],enemies:[],crates:[],barrels:[],mirrors:[],chips:[],supplies:[],checkpoints:[{id:0,x:145,y:820,name:'入口'}],bridges:[],route:[],signs:[]};}
function shelf(L,x,y,w=140){L.platforms.push({id:'shelf-'+L.platforms.length,x,y,w,h:20,kind:'shelf',oneWay:true});}
function block(L,x,y,w,h){L.platforms.push({id:'bulk-'+L.platforms.length,x,y,w,h,kind:'bulk'});}
function receiver(L,id,x,y,need=3,ricochet=false){L.receivers.push({id,x,y,w:44,h:64,need,requiresRicochet:ricochet,label:(ricochet?'折光':'供电')+' '+(L.receivers.length+1)});}
function gun(L,id,kind,x,y=770){L.enemies.push({id,kind,x,y,w:kind==='crawler'?34:44,h:kind==='crawler'?46:50,hp:kind==='warden'?240:kind==='heavy'?150:90,range:900,period:kind==='burst'?2.3:kind==='mortar'?2.5:1.9,anchor:x,baseY:y});}
function gate(L,x,r,y=620,h=200){L.gates.push({id:'gate-'+L.gates.length,x,y,w:30,h,receiver:r});}
function cp(L,x,y=820){L.checkpoints.push({id:L.checkpoints.length,x,y,name:'中继点 '+L.checkpoints.length});}
function barrel(L,x,y=780){L.barrels.push({id:'barrel-'+L.barrels.length,x,y,w:28,h:40,hp:25});}
function crate(L,x,y=768){L.crates.push({id:'box-'+L.crates.length,x,y,w:50,h:52});}
function mirror(L,x,y,angle){L.mirrors.push({id:'mirror-'+L.mirrors.length,x,y,angle,len:88});}
function chip(L,x,y){L.chips.push({id:'chip-'+L.chips.length,x,y});}
function med(L,x,y=793){L.supplies.push({id:'med-'+L.supplies.length,x,y,amount:40});}
function finishMap(L,x=L.width-110,y=820){L.exit={x,y,w:65,h:105};return L;}
function advanced(){const maps=[];
 {
 const L=authored(6,'把火带过去',0,3100);L.hint='敌人的火力到不了每一个房间。右键 / Q 可以先存住三发炮弹。';
 gun(L,'source','burst',520);receiver(L,'entry',690,684,2);gate(L,900,'entry');block(L,900,240,30,380);shelf(L,310,730);shelf(L,650,610);chip(L,710,580);cp(L,970);
 block(L,1170,610,120,210);shelf(L,1035,730);shelf(L,1400,730,220);receiver(L,'quiet',1530,630,2);barrel(L,1495);chip(L,1500,620);gate(L,1810,'quiet');
 cp(L,1880);gun(L,'last','heavy',2240);receiver(L,'exit',2480,670,3);gate(L,2860,'exit');crate(L,2120);barrel(L,2330);med(L,2060);shelf(L,2600,720);chip(L,2660,690);
 L.signs=[{x:1000,y:680,text:'有些火力，要先带在身上。'},{x:1370,y:540,text:'同一处供电，也可以借一次爆炸。'}];maps.push(finishMap(L));
 }
 {
 const L=authored(7,'一发炮弹拐两次',3,3450);L.hint='折光线圈需要经过金属表面的炮弹。B 可以停下来观察，V 可以查看预计弹道。';
 gun(L,'source','bolt',220);shelf(L,370,730,220);mirror(L,710,707,-Math.PI/4);receiver(L,'prism-a',688,420,2,true);gate(L,1020,'prism-a');shelf(L,560,620,110);shelf(L,760,510);chip(L,835,480);cp(L,1110);med(L,1100);
 gun(L,'middle','burst',1730);receiver(L,'middle',1560,684,3);gate(L,2020,'middle');crate(L,1320);barrel(L,1650);shelf(L,1370,730);shelf(L,1520,620);chip(L,1580,590);cp(L,2130);
 gun(L,'right-source','heavy',2920);shelf(L,2630,730,330);mirror(L,2410,707,Math.PI/4);receiver(L,'prism-b',2388,420,2,true);gate(L,3210,'prism-b');shelf(L,2230,620);chip(L,2290,590);med(L,2780);
 L.signs=[{x:420,y:590,text:'直线够不到的地方，换个方向。'},{x:2480,y:580,text:'先接住，再决定这一发怎么走。'}];maps.push(finishMap(L));
 }
 {
 const L=authored(8,'仓库可以重新摆',4,3700);L.hint='箱子不是固定掩体。靠近按 E 抓住，再按 E 放下；K 可以把它推出去。';
 gun(L,'left','heavy',660);receiver(L,'first',880,684,3);gate(L,1120,'first');crate(L,430);crate(L,500);L.walls.push({id:'wall-main',x:620,y:700,w:45,h:120,hp:120});barrel(L,730);shelf(L,760,660);shelf(L,930,560);chip(L,1000,530);cp(L,1220);med(L,1170);
 block(L,1510,650,90,170);crate(L,1390);shelf(L,1340,730);receiver(L,'high',1740,610,3);gun(L,'upper','drone',1960,590);gate(L,2240,'high');shelf(L,1680,750);shelf(L,1840,650);chip(L,1890,620);cp(L,2350);med(L,2310);
 receiver(L,'last',2700,684,4);gun(L,'warden','warden',3080);gun(L,'decoy','burst',2580);barrel(L,2890);barrel(L,2990);barrel(L,3090);crate(L,2480);shelf(L,2820,720);shelf(L,2990,610);chip(L,3060,580);gate(L,3450,'last');
 L.signs=[{x:1320,y:580,text:'箱子能挡火，也能垫脚。'},{x:2820,y:500,text:'装甲护着正面，环境不只在正面。'}];maps.push(finishMap(L));
 }
 {
 const L=authored(9,'整个车站都能借火',5,4300,1460);L.hint='不同高度、不同弹道，共用同一套工具。路线由你决定。';L.platforms=[];
 block(L,0,820,2100,640);L.platforms[0].kind='floor';block(L,2700,820,1600,30);L.platforms[1].kind='shelf';L.platforms[1].oneWay=true;block(L,2050,1200,2250,260);L.platforms[2].kind='floor';
 gun(L,'left','burst',450);receiver(L,'a',720,684,3);gate(L,980,'a');crate(L,350);shelf(L,600,730);shelf(L,780,620);chip(L,840,590);cp(L,1120);med(L,1100);
 receiver(L,'bridge',1660,620,3);gun(L,'bridge-source','heavy',1900);crate(L,1430);shelf(L,1510,730);shelf(L,1680,700);barrel(L,1750);cp(L,2010);
 L.bridges.push({id:'long-bridge',x:2100,y:820,w:600,h:25,kind:'bridge',oneWay:true,receiver:'bridge'});shelf(L,2030,690,200);shelf(L,2260,590,240);shelf(L,2540,690,220);chip(L,2380,560);
 receiver(L,'right',2820,630,3);gun(L,'right-source','mortar',3180);barrel(L,2890);med(L,2800);cp(L,2760);
 shelf(L,2880,1090,170);shelf(L,3090,980,170);shelf(L,2880,870,170);shelf(L,3110,760,170);chip(L,2700,1170);med(L,2540,1173);
 shelf(L,3750,730,300);mirror(L,3550,707,Math.PI/4);receiver(L,'prism',3528,420,3,true);gun(L,'last-source','heavy',3950);gate(L,4100,'prism');cp(L,3380);med(L,3420);shelf(L,3380,620,140);chip(L,3440,590);
 L.signs=[{x:2130,y:500,text:'上层、桥面，或落到下面再回来。'},{x:3410,y:540,text:'最后一道线圈，仍然能慢慢想。'}];maps.push(finishMap(L));
 }
 return maps;
}
function circuits(){const maps=[];
 {
 const L=authored(10,'一发点亮两盏',2,3400,1240);L.palette.name='分流实验室';L.chapter='回环设施';L.hint='先给中继站接电，就能回来补弹。分流器能把借来的炮弹送向两个方向。';L.splitters=[];
 gun(L,'entry-source','burst',550);receiver(L,'relay',300,684,2);L.receivers[0].relay=true;L.receivers[0].label='入口中继';
 shelf(L,330,730,140);shelf(L,470,633,180);shelf(L,670,520,100);shelf(L,900,410,150);chip(L,960,380);
 L.splitters.push({id:'split-a',x:780,y:610,angle:0});receiver(L,'upper-a',958,378,2);receiver(L,'lower-a',926,746,2);gate(L,1190,'lower-a');cp(L,1300);med(L,1280);
 shelf(L,2010,520,150);shelf(L,2050,633,270);shelf(L,2340,730,150);chip(L,2080,490);gun(L,'right-source','heavy',2630);L.splitters.push({id:'split-b',x:2000,y:610,angle:Math.PI/2});receiver(L,'upper-b',1778,378,2);receiver(L,'lower-b',1810,746,2);gate(L,2980,'upper-b');cp(L,2780);med(L,2800);['入口中继','西翼高层','西翼地面','东翼高层','东翼地面'].forEach((n,i)=>L.receivers[i].label=n);
 L.signs=[{x:130,y:570,text:'接通中继以后，E 可以补满蓄弹。'},{x:510,y:450,text:'一发火力，可以分成两条线路。'},{x:2140,y:540,text:'靠近按 E：让分流器换个方向。'}];maps.push(finishMap(L));
 }
 {
 const L=authored(11,'先点哪盏都可以',0,4100,1460);L.palette.name='环线配电厂';L.chapter='回环设施';L.hint='这次从中间出发。西侧、上层、地下与东侧可以往返，所有供电接通后才能撤离。';L.start={x:1810,y:774};L.checkpoints=[{id:0,x:1810,y:820,name:'中央中继'}];L.splitters=[];L.platforms=[];
 block(L,0,820,2350,640);L.platforms[0].kind='floor';block(L,2920,820,1180,30);L.platforms[1].kind='shelf';L.platforms[1].oneWay=true;block(L,2300,1200,1800,260);L.platforms[2].kind='floor';
 receiver(L,'central',1730,684,2);L.receivers[0].relay=true;L.receivers[0].label='中央中继';gun(L,'central-source','heavy',1510);med(L,1850);shelf(L,1660,730,140);
 receiver(L,'west',470,610,3);gun(L,'west-source','burst',850);barrel(L,640);crate(L,1100);shelf(L,320,730);shelf(L,320,620,120);shelf(L,480,510);shelf(L,680,510);chip(L,740,480);cp(L,1030);
 shelf(L,1890,700,130);shelf(L,1720,583,180);L.splitters.push({id:'hub-split',x:2100,y:560,angle:0});receiver(L,'roof',2328,278,3);receiver(L,'bridge',2296,746,3);L.receivers[2].label='高层供电';L.receivers[3].label='环线桥';
 shelf(L,1970,660);shelf(L,2170,540);shelf(L,2330,410,180);chip(L,2410,380);
 L.bridges.push({id:'ring-bridge',x:2350,y:820,w:570,h:25,kind:'bridge',oneWay:true,receiver:'bridge'});shelf(L,2300,1090,160);shelf(L,2360,870,160);shelf(L,2720,1090,160);shelf(L,2510,980,180);shelf(L,2720,870,220);shelf(L,2880,1090,180);shelf(L,3070,980,180);shelf(L,2890,870,170);shelf(L,3090,760,200);chip(L,2740,1170);med(L,2660,1173);
 receiver(L,'east',3370,670,3);gun(L,'east-source','burst',3620);barrel(L,3450);crate(L,3230);cp(L,3130);med(L,3140);shelf(L,3440,730,180);shelf(L,3620,633,250);mirror(L,3500,610,Math.PI/4);receiver(L,'prism',3478,340,2,true);gate(L,3930,'prism');chip(L,3770,603);
 L.receivers[1].label='西侧供电';L.receivers[4].label='东侧供电';L.receivers[5].label='出口折光';
 L.signs=[{x:1640,y:510,text:'C 查看整座设施：哪一处还没有亮？'},{x:660,y:410,text:'先去西边，也可以先回中央。'},{x:2430,y:650,text:'桥面还没亮，也有地下通路。'},{x:3200,y:540,text:'所有线路接通，出口才会允许撤离。'}];maps.push(finishMap(L));
 }
 return maps;
}
const LEVELS=[...SPECS.map((_,i)=>{const L=build(i);L.chapter='基础设施';L.bridges=[];L.signs=[];L.platforms.forEach(p=>{if(p.kind==='shelf')p.oneWay=true;});return L;}),...advanced(),...circuits()];
const api={LEVELS,PALETTES};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.BorrowedLevels=api;
})(typeof globalThis!=='undefined'?globalThis:this);
