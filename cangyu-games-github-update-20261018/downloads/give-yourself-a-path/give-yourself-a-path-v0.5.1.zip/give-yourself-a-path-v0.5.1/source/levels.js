/* Twenty authored layouts. The collision grid is invisible; motion stays continuous. */
(()=>{'use strict';
const CHAPTERS=['一 · 林地初行','二 · 河岸协作','三 · 山谷远行','四 · 留给后来'];
function base(id,name,w,h,theme,limit,hint){return{id,name,w,h,theme,limit,hint,tiles:Array.from({length:h},(_,y)=>Array.from({length:w},(_,x)=>x===0||y===0||x===w-1||y===h-1?'#':'.')),start:[3,h-5],exit:[w-4,4],plates:[],gates:[],boxes:[],items:[],beacons:[],ferries:[],bridges:[],camps:[],winds:[],notes:[]};}
function fill(l,x,y,w,h,c){for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)if(l.tiles[j]?.[i]!==undefined)l.tiles[j][i]=c;}
function water(l,x,width,crossings){fill(l,x,1,width,l.h-2,'~');for(const y of crossings)fill(l,x,y,width,2,'=');}
function canal(l,y,height,crossings){fill(l,1,y,l.w-2,height,'~');for(const x of crossings)fill(l,x,y,2,height,'=');}
function wall(l,y,openings){fill(l,1,y,l.w-2,1,'#');for(const x of openings)fill(l,x,y,3,1,'.');}
function grove(l,x,y,w,h){fill(l,x,y,w,h,'#');}
function plate(l,id,x,y){l.plates.push({id,x,y});}
function gate(l,id,x,y,w,h,ps,kind='pressure'){l.gates.push({id,x,y,w,h,plates:ps,kind});}
function box(l,x,y){l.boxes.push({x,y});}
function item(l,id,x,y,type='letter'){l.items.push({id,x,y,type});}
function lamp(l,id,x,y,ps=[]){l.beacons.push({id,x,y,plates:ps});}
function camp(l,x,y){l.camps.push({x,y});}
function ferry(l,ax,ay,bx,by){l.ferries.push({a:[ax,ay],b:[bx,by]});}
function repair(l,id,x,y,w,h,cost=2){fill(l,x,y,w,h,'~');l.bridges.push({id,x,y,w,h,cost,bench:[x-1,y+1]});}
function note(l,x,y,text){l.notes.push({x,y,text});}
const L=[];let l;
l=base(1,'林间初信',32,20,'forest',1,'先随意走一走。送信之外，试试 R 留下过去的自己。');wall(l,10,[4,14,25]);grove(l,9,3,3,4);grove(l,20,13,4,3);l.start=[3,15];l.exit=[27,4];note(l,13,14,'每关的分身只留在这一关。按 R 录下当前路线，可以让过去的自己帮忙。');L.push(l);
l=base(2,'隔岸回声',32,20,'forest',1,'北边能绕行；中央踏板能开近路。试试让分身留在踏板上。');water(l,14,3,[4,10]);plate(l,'p1',11,11);gate(l,'g1',15,10,1,2,['p1']);box(l,9,14);l.exit=[27,14];note(l,8,6,'站上踏板，再留下分身。等旧分身走到这里，选“留在这里”，近路就为你打开。');L.push(l);
l=base(3,'木箱换班',34,22,'forest',1,'先给灯台供能，再送信。箱子可以替你守踏板。');wall(l,10,[4,16,27]);plate(l,'p1',13,14);lamp(l,'b1',19,14,['p1']);box(l,11,16);box(l,25,7);grove(l,7,4,4,3);l.exit=[29,5];L.push(l);
l=base(4,'先放下，再出发',34,22,'forest',1,'包裹放下也有重量。点亮灯台后，记得取回再送达。');water(l,16,2,[4,12]);plate(l,'p1',12,13);gate(l,'g1',16,12,2,2,['p1']);lamp(l,'b1',23,13,['p1']);box(l,6,5);camp(l,10,16);l.exit=[29,16];L.push(l);
l=base(5,'两岸木桥',36,24,'forest',2,'找回两封信。南桥能修，北桥也能绕。');water(l,16,3,[4]);repair(l,'r1',16,17,3,2);item(l,'w1',9,18,'wood');item(l,'w2',27,18,'wood');item(l,'m1',8,6);item(l,'m2',29,19);box(l,12,12);camp(l,12,18);note(l,25,7,'修桥的这一次可能绕得远，后来每一次都能走得近。');L.push(l);
l=base(6,'旧渡口',36,24,'marsh',2,'摆渡、绕桥、修桥，都能到对岸。点亮灯台再送信。');water(l,14,4,[3]);repair(l,'r1',14,18,4,2);ferry(l,12,12,20,12);plate(l,'p1',22,16);lamp(l,'b1',29,16,['p1']);box(l,23,19);item(l,'w1',8,18,'wood');item(l,'w2',25,5,'wood');l.exit=[30,5];L.push(l);
l=base(7,'两处重量',38,24,'marsh',2,'两处踏板一起压下才能开中央门；两边都留了绕路。');wall(l,11,[3,18,31]);plate(l,'p1',13,15);plate(l,'p2',21,15);gate(l,'g1',18,11,3,1,['p1','p2']);box(l,11,17);box(l,24,17);lamp(l,'b1',18,6,['p1']);item(l,'m1',31,18);l.exit=[31,5];L.push(l);
l=base(8,'两段旧路',38,24,'marsh',2,'两条河、两座灯台。分身可以分头留下，包裹也能暂时替班。');water(l,12,2,[3,15]);water(l,25,2,[6,18]);plate(l,'p1',8,13);plate(l,'p2',20,10);gate(l,'g1',12,15,2,2,['p1']);gate(l,'g2',25,6,2,2,['p2']);lamp(l,'b1',18,15,['p1']);lamp(l,'b2',32,10,['p2']);box(l,7,17);box(l,21,14);camp(l,20,19);L.push(l);
l=base(9,'山路绕行',40,26,'stone',2,'走过几条山路，找回三封信。营地可以成为新留影的起点。');wall(l,7,[4,19,32]);wall(l,15,[9,25,34]);grove(l,12,9,4,3);grove(l,29,18,4,4);item(l,'m1',7,4);item(l,'m2',20,11);item(l,'m3',34,21);box(l,17,18);camp(l,20,19);l.exit=[34,3];L.push(l);
l=base(10,'河岸驿站',40,26,'marsh',2,'点亮三座驿灯，送出这一章的信。');water(l,18,3,[4,12,20]);plate(l,'p1',13,15);gate(l,'g1',19,12,1,2,['p1']);lamp(l,'b1',8,5);lamp(l,'b2',28,12,['p1']);lamp(l,'b3',30,21);box(l,11,18);item(l,'m1',8,21);camp(l,14,20);l.exit=[35,5];L.push(l);
l=base(11,'水道之间',42,26,'marsh',3,'上下水道交错。摆渡和修复近路，都可以改变运输路线。');canal(l,8,2,[4,31]);canal(l,17,2,[12,35]);repair(l,'r1',20,8,2,2);l.bridges[0].bench=[19,7];repair(l,'r2',25,17,2,2);l.bridges[1].bench=[24,16];ferry(l,7,15,7,20);for(const [i,x,y]of[[1,7,5],[2,34,13],[3,18,21],[4,30,21]])item(l,'w'+i,x,y,'wood');item(l,'m1',34,4);item(l,'m2',8,13);lamp(l,'b1',33,21);camp(l,20,13);l.exit=[36,4];L.push(l);
l=base(12,'风车丘陵',42,28,'gold',3,'风只影响行走，不会把你吹落。转动风车，选择顺风或绕行。');wall(l,9,[5,20,33]);wall(l,19,[8,24,34]);l.winds=[{x:12,y:11,w:14,h:5,dir:1,lever:[11,15]}];item(l,'m1',8,5);item(l,'m2',33,23);plate(l,'p1',29,13);lamp(l,'b1',35,13,['p1']);box(l,29,16);camp(l,10,22);l.exit=[36,5];L.push(l);
l=base(13,'三座驿灯',44,28,'gold',3,'三处灯台各有踏板。可以逐个处理，也可以让过去的自己分头守住。');water(l,20,3,[4,13,22]);for(const [id,px,py,bx,by]of[['1',8,8,14,8],['2',28,11,36,11],['3',29,22,37,22]]){plate(l,'p'+id,px,py);lamp(l,'b'+id,bx,by,['p'+id]);box(l,px-2,py+3);}camp(l,16,22);camp(l,27,5);l.exit=[38,4];L.push(l);
l=base(14,'雾谷索桥',44,28,'stone',3,'峡谷有三条近路。木料有限，修哪座桥由你决定。');water(l,14,3,[3]);water(l,29,3,[22]);repair(l,'r1',14,15,3,2);repair(l,'r2',29,8,3,2);ferry(l,27,17,34,17);for(const [id,x,y]of[['w1',8,19],['w2',22,8],['w3',25,21],['w4',37,20]])item(l,id,x,y,'wood');item(l,'m1',8,6);item(l,'m2',36,6);lamp(l,'b1',24,16);camp(l,22,23);L.push(l);
l=base(15,'借道仓库',44,28,'stone',3,'钥匙、配重、绕路都能开出通道。找回仓库中的三封信。');wall(l,8,[4,20,35]);wall(l,18,[7,25,36]);grove(l,14,10,2,6);grove(l,31,20,3,4);plate(l,'p1',17,13);gate(l,'g1',20,8,3,1,['p1']);gate(l,'g2',25,18,3,1,[],'key');item(l,'key1',9,5,'key');for(const [id,x,y]of[['m1',9,13],['m2',27,5],['m3',37,23]])item(l,id,x,y);box(l,14,21);box(l,18,16);box(l,29,12);lamp(l,'b1',35,13,['p1']);camp(l,8,22);l.exit=[38,4];L.push(l);
l=base(16,'镜湖回廊',46,28,'snow',3,'岛上的灯台有三种接近方法：开门、修桥，或摆渡。');fill(l,15,7,17,15,'~');fill(l,20,11,7,7,'.');fill(l,22,7,2,4,'=');gate(l,'g1',22,8,2,1,['p1']);plate(l,'p1',19,5);box(l,15,4);repair(l,'r1',27,14,5,2);l.bridges[0].bench=[33,15];ferry(l,13,15,21,15);lamp(l,'b1',23,14);item(l,'w1',35,21,'wood');item(l,'w2',36,8,'wood');item(l,'m1',9,8);item(l,'m2',36,23);camp(l,36,18);l.exit=[40,5];L.push(l);
l=base(17,'双岸工坊',46,30,'snow',3,'让两岸工坊恢复灯火。修桥和固定闸门都会留在本关。');water(l,21,3,[4,15,25]);plate(l,'p1',16,17);plate(l,'p2',29,10);gate(l,'g1',21,15,3,2,['p1']);lamp(l,'b1',9,17,['p1']);lamp(l,'b2',38,10,['p2']);box(l,14,21);box(l,28,14);repair(l,'r1',21,25,3,2);item(l,'w1',8,6,'wood');item(l,'w2',38,23,'wood');item(l,'m1',36,26);camp(l,17,26);l.exit=[40,4];L.push(l);
l=base(18,'归途不重走',48,30,'gold',3,'先探索，再留下路。三个营地让长途合作不必总从最初出发。');water(l,22,3,[3,14,25]);wall(l,10,[4,16,34,41]);wall(l,21,[8,18,32,41]);plate(l,'p1',16,16);gate(l,'g1',22,14,3,2,['p1']);lamp(l,'b1',32,16,['p1']);lamp(l,'b2',39,25);for(const[id,x,y]of[['m1',8,5],['m2',16,25],['m3',39,6]])item(l,id,x,y);box(l,12,18);camp(l,14,23);camp(l,30,18);camp(l,39,5);l.exit=[42,4];L.push(l);
l=base(19,'群山通信',48,30,'stone',3,'把三处信号站连起来，再把两封遗失信带到出口。');water(l,14,2,[4,18,25]);water(l,31,2,[7,20]);wall(l,12,[5,22,39]);for(const[id,px,py,bx,by]of[['1',8,20,10,6],['2',23,8,24,21],['3',38,17,42,6]]){plate(l,'p'+id,px,py);lamp(l,'b'+id,bx,by,['p'+id]);box(l,px-2,py+3);}item(l,'m1',7,25);item(l,'m2',40,25);ferry(l,29,25,35,25);camp(l,23,25);l.exit=[43,4];L.push(l);
l=base(20,'留给后来的人',50,32,'forest',3,'修路、分流、摆渡和留影都派得上用场。点亮四座灯台，找回三封信。');water(l,22,3,[3,15,27]);wall(l,10,[5,16,33,43]);wall(l,22,[7,16,32,43]);repair(l,'r1',22,27,3,2);plate(l,'p1',16,17);gate(l,'g1',22,15,3,2,['p1']);plate(l,'p2',32,18);gate(l,'g2',33,10,3,1,['p2']);for(const[id,x,y,ps]of[['b1',9,5,[]],['b2',15,25,['p1']],['b3',39,17,['p2']],['b4',42,27,[]]])lamp(l,id,x,y,ps);for(const[id,x,y]of[['m1',8,26],['m2',35,5],['m3',43,25]])item(l,id,x,y);item(l,'w1',12,25,'wood');item(l,'w2',36,25,'wood');item(l,'key1',30,6,'key');box(l,14,19);box(l,29,20);box(l,37,26);ferry(l,20,24,27,24);camp(l,16,25);camp(l,29,14);camp(l,41,25);l.exit=[45,4];note(l,39,6,'你留下的路，不必是一条最短的路。只要让下一次多一种选择，就有了意义。');L.push(l);

// Strategy revision: persistent lamps now need several simultaneous sources and a signal order.
function extraPlate(l,id,x,y,kind='any'){plate(l,id,x,y);l.plates.at(-1).kind=kind;}
function changeLamp(l,id,ps,after=[]){const b=l.beacons.find(b=>b.id===id);b.plates=ps;b.after=after;return b;}
function setKind(l,id,kind){l.plates.find(p=>p.id===id).kind=kind;}
for(const stage of L)stage.revision='strategy-1';
l=L[0];extraPlate(l,'p1',6,14);extraPlate(l,'p2',11,14);lamp(l,'b1',17,14,['p1','p2']);box(l,8,17);l.hint='两处踏板必须同时供能，远处的驿灯才会响应。';
l=L[1];extraPlate(l,'p2',22,14,'load');lamp(l,'b1',26,10,['p1','p2']);l.hint='隔着河的两处供能要同时保住。木箱、分身与包裹可以各有分工。';
l=L[2];setKind(l,'p1','load');extraPlate(l,'p2',19,15,'person');changeLamp(l,'b1',['p1','p2']);l.hint='琥珀踏板只认物品，蓝色踏板只认角色。试着安排谁留下、谁去点灯。';
l=L[3];extraPlate(l,'p2',25,16,'load');changeLamp(l,'b1',['p1','p2']);l.hint='一处供能在西岸，一处在东岸；过河的途中，也要让两处维持供能。';
l=L[4];extraPlate(l,'p1',12,18);extraPlate(l,'p2',25,15);lamp(l,'b1',29,11,['p1','p2']);l.hint='先安排两岸的供能，再把遗失信送出。修桥会改变你的往返计划。';
l=L[5];setKind(l,'p1','load');extraPlate(l,'p2',29,17,'person');changeLamp(l,'b1',['p1','p2']);l.hint='渡口不能运木箱。两岸运输与灯台的角色、物品配重要一起考虑。';
l=L[6];changeLamp(l,'b1',['p1','p2']);l.hint='门与灯共用两处供能。先开哪条通路、把什么留在哪里，都会影响后面。';
l=L[7];extraPlate(l,'p3',31,15,'load');changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p2','p3'],['b1']);l.hint='两座灯台共用中间供能。第二座需要第一座先亮，分身名额只有两个。';
l=L[8];extraPlate(l,'p1',12,20);extraPlate(l,'p2',23,12);extraPlate(l,'p3',29,5);lamp(l,'b1',27,11,['p1','p2']);lamp(l,'b2',23,4,['p2','p3']);l.beacons[1].after=['b1'];l.items.find(i=>i.id==='m1').after=['b1'];l.hint='两座信号台分阶段工作，中间供能被重复使用。最后一封信的箱锁与信号相连。';
l=L[9];extraPlate(l,'p2',8,18);extraPlate(l,'p3',26,18);changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p1','p3'],['b1']);changeLamp(l,'b3',['p2','p3'],['b2']);l.hint='三座驿灯的供能组合不同，必须依次启动。考虑是否重新分配配重，而非只多留分身。';
l=L[10];extraPlate(l,'p1',12,13,'load');extraPlate(l,'p2',30,21);box(l,15,13);changeLamp(l,'b1',['p1','p2']);l.hint='水道把两处供能分开。渡口运不了木箱，修哪条近桥会改变运输成本。';
l=L[11];extraPlate(l,'p2',19,14);changeLamp(l,'b1',['p1','p2']).wind={index:0,dir:-1};lamp(l,'b2',8,14,['p2']);l.beacons[1].wind={index:0,dir:1};l.beacons[1].after=['b1'];l.hint='两座风灯需要不同风向，且必须依次点亮；改变风向时，配重仍要保住。';
l=L[12];changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p2','p3']);changeLamp(l,'b3',['p1','p2','p3'],['b1','b2']);l.boxes=l.boxes.slice(0,1);l.hint='前两座灯各用一对供能，最后一座要三处同时稳定。配重少了，要安排好交接。';
l=L[13];extraPlate(l,'p1',8,14);extraPlate(l,'p2',23,16);extraPlate(l,'p3',37,16);changeLamp(l,'b1',['p1','p3']);lamp(l,'b2',36,8,['p2','p3']);l.beacons[1].after=['b1'];l.items=l.items.filter(i=>!['w3','w4'].includes(i.id));l.hint='只有修一座桥的木料。两座灯台跨峡谷共享供能，先决定要保留哪条运输路线。';
l=L[14];extraPlate(l,'p2',35,14,'person');changeLamp(l,'b1',['p1','p2']).requiresKey=true;l.items.find(i=>i.id==='m3').after=['b1'];l.hint='灯台需要钥匙授权、物品与角色配合。部分信箱要在灯台恢复后才能打开。';
l=L[15];setKind(l,'p1','load');extraPlate(l,'p2',36,18,'load');changeLamp(l,'b1',['p1','p2']);l.hint='湖两侧都要留下真实物品。分身能帮忙赶路，但不能代替物品配重。';
l=L[16];extraPlate(l,'p3',12,24);changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p1','p2','p3'],['b1']);l.hint='西岸工坊先启动，东岸工坊才会响应。第二阶段还要补上第三处供能。';
l=L[17];extraPlate(l,'p2',12,7);extraPlate(l,'p3',37,23);changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p1','p3'],['b1']);l.items.find(i=>i.id==='m3').after=['b2'];l.hint='营地会改变留影起点。两阶段信号、三处供能与最后的信箱，要一起安排回程。';
l=L[18];setKind(l,'p2','person');changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p2','p3']);changeLamp(l,'b3',['p1','p2','p3'],['b1','b2']);l.boxes=l.boxes.slice(0,1);l.hint='中央踏板只认角色。前两站分别通电后，终端才接受三站联合供能。';
l=L[19];extraPlate(l,'p3',35,26);extraPlate(l,'p4',9,7,'load');changeLamp(l,'b1',['p1','p2']);changeLamp(l,'b2',['p2','p3']);changeLamp(l,'b3',['p1','p3'],['b1']);changeLamp(l,'b4',['p1','p2','p3','p4'],['b1','b2','b3']);l.boxes=l.boxes.slice(0,2);l.items.find(i=>i.id==='m3').after=['b3'];l.hint='前三站各需不同的供能组合，终端需要四处同时稳定。三个分身名额如何分配，由你决定。';

// Later circuits also require a branch to be disconnected, so saturating every pad is not a universal solution.
for(const [index,settings]of [[7,{b1:['p3'],b2:['p1']}],[8,{b1:['p3'],b2:['p1']}],[9,{b1:['p3'],b2:['p2'],b3:['p1']}],[12,{b1:['p3'],b2:['p1']}],[13,{b1:['p2'],b2:['p1']}],[16,{b1:['p3']}],[17,{b1:['p3'],b2:['p2']}],[18,{b1:['p3'],b2:['p1']}],[19,{b1:['p3','p4'],b2:['p1','p4'],b3:['p2','p4']}]])for(const [id,off]of Object.entries(settings))L[index].beacons.find(b=>b.id===id).off=off;
L[7].hint='先接通一组，再断开旧分支。红色虚线对应的踏板要保持空着。';
L[9].hint='三个阶段的接通与断开要求都不同。全压住不会成功，要安排配重交接。';
L[12].hint='前两站要分流，不能全压住；终端反而需要三处一起供能。';
L[18].hint='前两站先分流，终端再合流。中央踏板只认角色，配重和分身都要重新安排。';
L[19].hint='先按不同组合分流，最后四路合流。三名分身与实物配重如何交接，由你决定。';

// Authored endpoints may sit against a bank or wall: snap entities to nearest land, never carve gates away.
function land(l,x,y){return x>0&&y>0&&x<l.w-1&&y<l.h-1&&['.','='].includes(l.tiles[y][x]);}
function snap(l,p){if(land(l,p[0],p[1]))return p;for(let r=1;r<8;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++)if(Math.abs(dx)+Math.abs(dy)===r&&land(l,p[0]+dx,p[1]+dy))return[p[0]+dx,p[1]+dy];throw Error('No land '+l.id);}
for(const level of L){level.chapter=CHAPTERS[Math.floor((level.id-1)/5)];level.start=snap(level,level.start);level.exit=snap(level,level.exit);for(const arr of [level.plates,level.boxes,level.items,level.beacons,level.camps,level.notes])for(const o of arr)[o.x,o.y]=snap(level,[o.x,o.y]);for(const f of level.ferries){f.a=snap(level,f.a);f.b=snap(level,f.b);}for(const b of level.bridges)b.bench=snap(level,b.bench);for(const g of level.gates){const cx=g.x+g.w+1,cy=g.y+g.h+1;g.lever=snap(level,[cx,cy]);}level.tiles=level.tiles.map(r=>r.join(''));}
window.PATH_LEVELS=L;
})();
