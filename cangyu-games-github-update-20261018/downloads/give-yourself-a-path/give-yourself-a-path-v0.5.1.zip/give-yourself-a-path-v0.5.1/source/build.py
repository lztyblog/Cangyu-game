from pathlib import Path
root=Path(__file__).resolve().parent
html=(root/'index.template.html').read_text()
for name in ['levels.js','game.js']:
    js=(root/name).read_text()
    if '</script' in js.lower():
        raise ValueError('Unsafe closing script tag in '+name)
    token='<script src="'+name+'"></script>'
    assert token in html
    html=html.replace(token,'<script data-source="'+name+'">\n'+js+'\n</script>')
(root/'index.html').write_text(html)
print('Built standalone index.html:',len(html.encode()),'bytes')
