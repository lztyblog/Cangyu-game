(function(root){'use strict';
const {Game,dist,unit,clamp}=root.Bump||(root.Bump=require('./engine.js').Bump),P=Game.prototype;
const base={reset:P.reset,update:P.update,load:P.load,life:P.life,call:P.throwOrCall,mount:P.mount,surroundings:P.surroundings};
function init(s){s.echoes=[];s.recording=null;s.echoNext=1;}
P.enterLevel=function(id='crossroads',seed=1){
 base.reset.call(this,seed);const s=this.s;init(s);s.levelId=id;
 if(id==='lab'){this.tell('旧院子保留了，也可以在这里试分身。');return;}
 s.hero.x=1740;s.hero.y=1320;
 const place=(id,x,y)=>{const p=s.props.find(p=>p.id===id);p.x=x;p.y=y;p.home={x,y,angle:p.angle};return p;};
 for(const [id,x,y]of[['toy-ram',1710,1030],['toy-nap',2200,960],['stone-a',1800,1320],['stone-b',2070,1390],['barrel-a',1850,1240],['barrel-b',2180,1370],['resin-a',1830,1400],['coil-kit',1670,1320],['panel-a',1920,1310],['panel-b',2110,1240]])place(id,x,y);
 for(const [id,x,y,hx,hy]of[['ram',1740,1110,1710,1030],['nap',2170,1020,2200,960]]){const m=s.monsters.find(m=>m.id===id);Object.assign(m,{x,y,home:{x:hx,y:hy},mode:'sleep',cool:2,intent:'自己的窝里有动静才出来'});}
 place('helmet-kit',2160,560).dormant=false;place('big-ball',2040,560).dormant=false;s.bells[2].x=2230;s.bells[2].y=560;
 place('barrel-d',930,1210);place('panel-c',780,1150);place('resin-c',1100,1350);
 Object.assign(s.pads[0],{x:1080,y:1280,angle:0});Object.assign(s.bells[1],{x:820,y:1280});
 s.fan={x:1960,y:1400,r:30,angle:Math.PI,on:true};s.turbine={x:1960,y:1220,r:25,charge:0,open:false,powered:false};
 s.cabinet={x:1590,y:1300,r:24};s.beacon={x:2400,y:1330,r:22};
 s.walls.push(
  {id:'workshop-north',x:620,y:1020,w:640,h:22,hp:-1},
  {id:'workshop-west',x:620,y:1042,w:22,h:180,hp:-1},
  {id:'workshop-shortcut',x:620,y:1222,w:22,h:110,hp:3,max:3},
  {id:'workshop-east-a',x:1240,y:1042,w:22,h:150,hp:-1},
  {id:'workshop-east-b',x:1240,y:1360,w:22,h:100,hp:-1},
  {id:'east-garden-top',x:1830,y:410,w:540,h:22,hp:-1},
  {id:'east-garden-left',x:1830,y:432,w:22,h:180,hp:-1},
  {id:'east-garden-shortcut',x:1830,y:612,w:22,h:110,hp:3,max:3},
  {id:'east-garden-base',x:1830,y:722,w:180,h:22,hp:-1},
  {id:'east-garden-right',x:2350,y:432,w:22,h:310,hp:-1},
  {id:'cross-divider',x:1840,y:980,w:180,h:22,hp:-1},
  {id:'cross-upper',x:2010,y:1002,w:22,h:118,hp:-1},
  {id:'cross-shortcut',x:2010,y:1120,w:22,h:100,hp:3,max:3},
  {id:'exit-top-a',x:2260,y:1190,w:110,h:22,hp:-1},
  {id:'exit-wind',x:2370,y:1190,w:110,h:22,hp:-1,gate:true},
  {id:'exit-top-b',x:2480,y:1190,w:40,h:22,hp:-1},
  {id:'exit-left-a',x:2260,y:1212,w:22,h:48,hp:-1},
  {id:'exit-breach',x:2260,y:1260,w:22,h:110,hp:6,max:6},
  {id:'exit-left-b',x:2260,y:1370,w:22,h:90,hp:-1},
  {id:'exit-right',x:2500,y:1212,w:20,h:248,hp:-1},
  {id:'exit-bottom',x:2282,y:1440,w:218,h:20,hp:3,max:3,low:true}
 );
 s.notice='先试 C：录下走动和空手呼喊，再按 C 让分身替你招惹它。目标是右侧回音庭的风铃。';s.noticeUntil=18;this.tickWind();
};
P.reset=function(seed=1){this.enterLevel(this.s.levelId||'crossroads',seed);};
P.echoActor=function(id){if(id==='hero')return this.s.hero;return(this.s.echoes||[]).find(e=>e.id===id&&!e.paused);};
P.noise=function(actor){const s=this.s;actor.callAt=s.time;this.sound('whistle');let n=0;
 for(const m of s.monsters){if(s.hero.riding===m.id||dist(m,actor)>(s.levelId==='crossroads'?620:900))continue;
  m.attention=actor.id||'hero';m.attentionUntil=s.time+12;if(m.mode!=='windup')m.target={x:actor.x,y:actor.y};n++;
  if(m.kind){m.alert=true;if(!['windup','stun'].includes(m.mode)){m.mode='idle';m.cool=0;}continue;}
  if(m.mode==='sleep')m.mode='idle';
  if(!['charge','windup','stun'].includes(m.mode)){m.cool=0;if(this.visible(m,actor))this.windup(m,actor);}
 }
 if(actor.id&&n){s.cloneLures=(s.cloneLures||0)+1;this.discover('echo-lure','它追错人了！你现在可以去做另一件事。');}
};
P.throwOrCall=function(){const s=this.s,h=s.hero;if(s.paused)return;
 if(h.held||h.riding)return base.call.call(this);
 if(s.time-s.whistle<.65)return;s.whistle=s.time;this.noise(h);
 if(s.recording)s.recording.calls.push({t:s.time-s.recording.start,x:h.x,y:h.y});
 this.tell('它记住了喊声的位置。红线出现后，你可以换地方。');
};
P.recordEcho=function(){const s=this.s;if(s.paused)return false;if(!s.echoes)init(s);
 if(s.recording){const r=s.recording;this.sampleEcho(true);s.recording=null;
  if(r.points.length<2){this.tell('先走几步，再按 C 完成。');return false;}
  const first=r.points[0],e={id:'echo-'+s.echoNext++,tint:s.echoes.some(e=>e.tint==='violet')?'sky':'violet',x:first.x,y:first.y,r:15,dx:first.dx,dy:first.dy,points:r.points,calls:r.calls,duration:Math.max(.1,s.time-r.start),play:0,event:0,paused:false,ended:false,repeat:true,callAt:-10,lastCall:-10};
  s.echoes.push(e);this.tell('分身开始重演，你留在现在的位置。它不会复制物品，走完后会留在终点。');return true;
 }
 if(s.echoes.length>=2){this.tell('最多留两个分身；先在右侧删掉一个，就能重新录。');return false;}
 if(s.hero.riding||s.hero.held){this.tell('先空手下地，再录走动和呼喊。');return false;}
 s.recording={start:s.time,points:[],calls:[],sampleAt:-10};this.sampleEcho(true);this.tell('正在录：自由走动，空格呼喊；再按 C 完成。世界会继续发生变化。');return true;
};
P.sampleEcho=function(force=false){const s=this.s,r=s.recording;if(!r)return;if(!force&&s.time-r.sampleAt<.1)return;const h=s.hero,t=s.time-r.start;
 const p={t,x:h.x,y:h.y,dx:h.dx,dy:h.dy};if(r.points.length&&r.points.at(-1).t===t)r.points[r.points.length-1]=p;else r.points.push(p);r.sampleAt=s.time;
 if(t>=90&&!force)this.recordEcho();
};
P.echoControl=function(id,action){if(this.s.paused)return;const s=this.s,e=s.echoes?.find(e=>e.id===id);if(!e)return;
 if(action==='delete'){s.echoes=s.echoes.filter(e=>e.id!==id);for(const m of s.monsters)if(m.attention===id){m.attention=null;if(!['windup','charge'].includes(m.mode))m.target=null;}return;}
 if(action==='pause')e.paused=!e.paused;
 if(action==='repeat')e.repeat=!e.repeat;
 if(action==='restart'){const p=e.points[0];Object.assign(e,{x:p.x,y:p.y,dx:p.dx,dy:p.dy,point:0,play:0,event:0,paused:false,ended:false,callAt:-10,lastCall:-10});}
};
P.echoStep=function(dt){const s=this.s;for(const e of s.echoes||[]){if(e.paused)continue;e.play=Math.min(e.duration,e.play+dt);
  let i=e.point||0;while(i<e.points.length-2&&e.points[i+1].t<e.play)i++;e.point=i;const a=e.points[i],b=e.points[Math.min(i+1,e.points.length-1)],f=clamp((e.play-a.t)/(b.t-a.t||1),0,1),x=a.x+(b.x-a.x)*f,y=a.y+(b.y-a.y)*f;
  const dx=x-e.x,dy=y-e.y,n=Math.max(1,Math.ceil(Math.hypot(dx,dy)/10));for(let k=0;k<n;k++)this.moveCircle(e,dx/n,dy/n);e.dx=b.dx;e.dy=b.dy;
  while(e.event<e.calls.length&&e.calls[e.event].t<=e.play){const call=e.calls[e.event++];if(dist(e,call)<45){this.noise(e);e.lastCall=s.time;}}
  e.ended=e.play>=e.duration;if(e.ended&&e.repeat&&e.calls.length&&s.time-e.lastCall>4){this.noise(e);e.lastCall=s.time;}
 }};
P.mount=function(){if(this.s.recording&&!this.s.hero.riding){this.tell('先按 C 完成录制，再去骑它。');return false;}return base.mount.call(this);};
const baseAct=P.act;P.act=function(){if(this.s.recording){this.tell('这一段只录移动和呼喊；按 C 完成后就可以搬东西。');return;}return baseAct.call(this);};
P.life=function(m,dt,grip){const a=this.echoActor(m.attention);
 if(a&&this.s.time<(m.attentionUntil||0)){m.focus=null;m.intent=a.id?'追着分身的喊声':'记着你的喊声';
  if(dist(m,a)>75&&dist(m,a)<650&&this.visible(m,a)&&m.cool<=0){this.windup(m,a);return true;}
  if(dist(m,a)>75)this.mindWalk(m,a,85*grip,dt);return true;
 }return base.life.call(this,m,dt,grip);
};
P.surroundings=function(dt){const s=this.s,wall=s.walls.find(w=>w.id==='exit-breach'),rams=s.monsters.filter(m=>!m.kind);
 if(wall&&wall.hp>0&&rams.length>=2&&dist(rams[0],rams[1])<rams[0].r+rams[1].r+2&&(rams[0].mode==='charge'||rams[1].mode==='charge')){
  const p={x:(rams[0].x+rams[1].x)/2,y:(rams[0].y+rams[1].y)/2};if(dist(p,{x:wall.x,y:wall.y+wall.h/2})<150){this.damage(wall,6,'ram');this.discover('double-breach','两只在门边撞成一团，整面薄墙塌了！');}
 }return base.surroundings.call(this,dt);
};
P.update=function(dt,input={}){if(this.s.paused)return;this.echoStep(Math.min(.025,Math.max(0,dt)));base.update.call(this,dt,input);this.sampleEcho();};
P.load=function(text){let raw;try{raw=JSON.parse(text);}catch{return false;}
 if(raw.echoes!==undefined){if(!Array.isArray(raw.echoes)||raw.echoes.length>2)return false;
  const point=p=>p&&[p.x,p.y,p.t,p.dx,p.dy].every(Number.isFinite)&&p.t>=0&&p.t<=91&&p.x>=30&&p.x<=2570&&p.y>=30&&p.y<=1530;
  for(const e of raw.echoes)if(!e||!/^echo-\d+$/.test(e.id)||!Array.isArray(e.points)||e.points.length<2||e.points.length>1000||!e.points.every(point)||!Array.isArray(e.calls)||e.calls.length>150||!e.calls.every(p=>[p.t,p.x,p.y].every(Number.isFinite))||![e.x,e.y,e.play,e.duration].every(Number.isFinite)||e.duration<.1||e.duration>91)return false;
  if(new Set(raw.echoes.map(e=>e.id)).size!==raw.echoes.length)return false;
  if(raw.recording&&(!Array.isArray(raw.recording.points)||raw.recording.points.length>1000||!raw.recording.points.every(point)||!Array.isArray(raw.recording.calls)||raw.recording.calls.length>150||!Number.isFinite(raw.recording.start)))return false;
 }
 if(!base.load.call(this,text))return false;if(!this.s.echoes)init(this.s);this.s.levelId=this.s.levelId==='crossroads'?'crossroads':'lab';if(!Number.isFinite(this.s.echoNext))this.s.echoNext=3;return true;
};
root.Bump.chapterVersion='0.5';
})(typeof module!=='undefined'?module.exports:window);
