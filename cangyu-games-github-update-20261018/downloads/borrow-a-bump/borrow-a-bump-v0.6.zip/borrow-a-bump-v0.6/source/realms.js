(function(root){'use strict';
const B=root.Bump||(root.Bump=require('./chapter.js').Bump),{Game,dist,unit,clamp}=B,P=Game.prototype;
const old={enter:P.enterLevel,update:P.update,act:P.act,load:P.load,monster:P.monster,explode:P.explode,rewind:P.rewind};
const MAPS=[
 {id:'crossroads',name:'它们追错人了',theme:'回音院子',tip:'分身引怪、骑乘和借力开路。'},
 {id:'night',name:'雾灯旧院',theme:'轻恐怖',tip:'光会赶走影兽，亮灯也会暴露你。声音可以把它们引到别处。'},
 {id:'alchemy',name:'借火丹谷',theme:'修仙',tip:'给丹炉借入两种不同的力量，再收丹。风、飞石、爆炸和冲撞都可以。'},
 {id:'frost',name:'霜风渡口',theme:'冰雪',tip:'冰面会滑，球会长大；点燃火盆能融开附近冰墙。X 切换防滑靴。'},
 {id:'lab',name:'旧院子',theme:'自由实验',tip:'保留原来的放水、争球、改造怪兽和观景台。'}
];
B.MAPS=MAPS;
const realmId=id=>['night','alchemy','frost'].includes(id);
function vitals(s){const h=s.hero;h.maxHp=100;if(!Number.isFinite(h.hp))h.hp=100;h.hp=clamp(h.hp,0,100);h.invulnerableUntil=Number.isFinite(h.invulnerableUntil)?h.invulnerableUntil:0;s.vitals={enabled:true,...s.vitals};s.fallen=h.hp<=0;}
function supplies(s,spawn,points,camps=[]){s.healthPacks=points.map(([x,y],i)=>({id:'med-'+i,x,y,r:16,used:false}));s.camps=[{id:'camp-start',x:spawn.x,y:spawn.y,r:28,active:true},...camps.map(([x,y],i)=>({id:'camp-'+i,x,y,r:28,active:false}))];s.checkpoint={...spawn};}
P.enterLevel=function(id='crossroads',seed=1){
 const journal=this.s?.journal||{completed:[]};old.enter.call(this,realmId(id)?'lab':id,seed);const s=this.s;vitals(s);s.journal=journal;s.fallen=false;
 if(!realmId(id)){supplies(s,id==='lab'?{x:185,y:690}:{x:1740,y:1450},id==='lab'?[[350,805],[790,755],[1220,840],[1300,180]]:[[1640,1410],[2130,1340],[2070,860],[1080,1450]],id==='lab'?[[1220,840]]:[[1900,850]]);return;}
 s.levelId=id;s.realm={kind:id,lantern:true,grip:{active:true},energy:[],brew:false,burstAt:-10,hitNodeAt:-10};
 s.hero.x=280;s.hero.y=1230;s.hero.dx=1;s.hero.dy=0;s.won=true;s.adventureWon=false;s.flood={open:false,level:0};s.episode={stolen:false,warehouse:false,ballSwaps:0};
 const coords={night:[[750,890],[1720,680],[1450,370],[1980,1050]],alchemy:[[880,750],[1730,1030],[1960,390],[1950,1130]],frost:[[780,750],[1640,880],[1770,350],[1900,1180]]}[id];
 s.monsters.forEach((m,i)=>{const[x,y]=coords[i];Object.assign(m,{x,y,home:{x,y:y-75},mode:i<2?'sleep':'idle',timer:0,cool:2,path:[],pathAt:-1,attention:null,attentionUntil:0,alert:false,target:null,intent:i<2?'守着这一片地方':'留意亮处和路过的家伙'});});
 const spots={night:[[620,1130],[960,420],[1230,1110],[1630,930],[580,510],[1840,380],[460,1190],[1100,980],[1900,1180],[930,1180],[1580,1020],[2090,360],[450,430],[1790,1140],[1210,720],[750,815],[1720,605],[1080,1050],[540,1220],[1200,1180],[1930,420]],
 alchemy:[[1130,930],[1510,630],[680,1160],[1650,1130],[1770,560],[1250,590],[1240,930],[760,460],[1670,1290],[600,780],[1680,430],[2050,910],[1040,420],[810,1190],[1780,1230],[880,675],[1730,955],[1100,1250],[1790,820],[550,1200],[1870,440]],
 frost:[[660,1120],[1330,350],[1050,1180],[1620,620],[1900,1180],[1780,320],[720,1060],[1310,980],[1770,1130],[900,460],[1570,1250],[2050,1090],[600,350],[1880,600],[1210,400],[780,675],[1640,805],[1310,730],[530,1230],[1120,1250],[1900,410]]}[id];
 s.props.forEach((p,i)=>{const[x,y]=spots[i];Object.assign(p,{x,y,home:{x,y,angle:p.angle},dormant:false,vx:0,vy:0,held:false,dead:false});});
 s.props.find(p=>p.id==='big-ball').dormant=id!=='frost';
 s.pads=[{id:'spring-a',x:650,y:1250,r:27,angle:-Math.PI/4,on:true,pulse:-10},{id:'spring-b',x:1870,y:1280,r:27,angle:-Math.PI/2,on:true,pulse:-10}];
 s.bells=[[700,360],[1450,1270],[2050,320]].map(([x,y],i)=>({id:'bell-'+i,x,y,r:19,rung:false,at:-10,wind:0}));
 s.cabinet={x:390,y:1260,r:24};s.button={x:220,y:1320,r:23};
 s.fan={x:1040,y:780,r:30,angle:Math.PI/2,on:id==='alchemy'};s.turbine={x:1660,y:370,r:25,charge:0,open:false,powered:false};
 // Keep engine landmarks inert in realms; each realm supplies its own geometry.
 s.walls=[{id:'dam',x:40,y:40,w:20,h:20,hp:-1},{id:'shed-breach',x:70,y:40,w:20,h:20,hp:-1}];
 const wall=(id,x,y,w,h,hp=-1,extra={})=>s.walls.push({id,x,y,w,h,hp,...(hp>0?{max:hp}:{}),...extra});
 if(id==='night'){
  for(const m of s.monsters.filter(m=>!m.kind))m.mode='idle';
  wall('lodge-north',450,550,580,24);wall('lodge-west',450,574,24,240);wall('lodge-window',450,814,24,110,3);wall('lodge-east',1006,574,24,350);wall('lodge-south',474,900,270,24);
  wall('crypt-north',1330,380,470,24);wall('crypt-wall',1330,404,24,240);wall('crypt-gap',1330,644,24,110,3);wall('crypt-east',1780,404,20,180);
  wall('tower-top',2130,420,380,24);wall('tower-left-a',2130,444,24,106);wall('night-seal',2130,550,24,150,6);wall('tower-left-b',2130,700,24,140);wall('tower-bottom',2154,840,356,24,3,{low:true});wall('tower-right',2490,444,20,420);
  s.beacon={x:2340,y:640,r:22};s.realm.nodes=[[740,1120],[1410,850],[1910,470]].map(([x,y],i)=>({id:'ward-'+i,kind:'ward',x,y,r:24,lit:false}));
  [[570,1110],[1120,760],[1790,1050]].forEach(([x,y],i)=>s.props.push({id:'lantern-'+i,kind:'lantern',x,y,r:17,mass:1.3,vx:0,vy:0,angle:0,held:false,dead:false,fuse:-1,impact:-10,home:{x,y,angle:0}}));
  s.realm.zones=[{x:470,y:574,w:535,h:326},{x:1355,y:405,w:420,h:330}];
  supplies(s,{x:280,y:1230},[[610,1310],[1150,1020],[1830,900],[1970,450]],[[1490,1170]]);
 }else if(id==='alchemy'){
  wall('cliff-west',500,270,24,650);wall('cliff-north',524,270,1150,24);wall('rock-middle',1030,400,24,220);wall('rock-shortcut',1030,620,24,100,3);wall('rock-south',1030,1010,450,24);
  wall('ridge-a',1660,450,24,180);wall('ridge-b',1660,870,24,200);
  wall('palace-north',2150,540,360,24);wall('palace-left-a',2150,564,24,146);wall('spirit-seal',2150,710,24,150,-1);wall('palace-left-b',2150,860,24,180);wall('palace-bottom',2174,1016,336,24);wall('palace-right',2490,564,20,476);
  s.beacon={x:2340,y:790,r:22};s.realm.nodes=[{id:'furnace',kind:'furnace',x:1360,y:780,r:40}];s.realm.zones=[{x:1120,y:540,w:460,h:440},{x:1740,y:560,w:300,h:380}];
  supplies(s,{x:280,y:1230},[[600,1160],[1450,1150],[1850,700],[2000,390]],[[1470,1260]]);
 }else{
  wall('snow-ridge-n',480,300,1450,24);wall('snow-ridge-w',480,324,24,600);wall('ice-island',920,480,190,90);wall('ice-barrier',1130,640,24,280,6,{ice:true});wall('ice-ridge',1510,510,24,250);
  wall('station-top',2150,450,360,24);wall('station-west-a',2150,474,24,76);wall('frost-seal',2150,550,24,280,6,{ice:true});wall('station-west-b',2150,830,24,220);wall('station-bottom',2174,1026,336,24,3,{low:true});wall('station-right',2490,474,20,576);
  s.beacon={x:2340,y:730,r:22};s.realm.nodes=[[660,1000],[1040,790],[2050,730]].map(([x,y],i)=>({id:'heat-'+i,kind:'brazier',x,y,r:25,lit:false}));s.realm.zones=[{x:510,y:350,w:1560,h:860}];
  supplies(s,{x:280,y:1230},[[750,1280],[1280,1190],[1810,420],[2050,1130]],[[1620,1310]]);
 }
 s.notice=MAPS.find(m=>m.id===id).tip;s.noticeUntil=16;this.tickWind();
};
P.hurt=function(amount,cause='碰撞'){const s=this.s,h=s.hero;if(!s.vitals?.enabled||s.paused||s.fallen||s.time<h.invulnerableUntil)return false;
 if(s.realm?.potion==='护体丹')amount=Math.ceil(amount*.6);if(s.time<(h.shieldUntil||0))amount=Math.ceil(amount*.5);
 h.hp=Math.max(0,h.hp-amount);h.invulnerableUntil=s.time+1.2;h.hurtAt=s.time;h.lastDamage=amount;h.hurtCause=cause;s.shake=7;this.sound('hurt');this.tell(`${cause} -${amount}。靠近血包恢复，或到营火按 E 疗伤。`);
 if(h.hp===0){s.fallen=true;s.recording=null;this.tell('先缓一缓。可以倒回五秒，或在营火恢复后继续。');}return true;
};
P.recover=function(){const s=this.s;if(!s.fallen)return false;const h=s.hero;if(h.held){const p=s.props.find(p=>p.id===h.held);if(p)p.held=false;h.held=null;}if(h.riding){const m=s.monsters.find(m=>m.id===h.riding);if(m){m.mode='idle';m.cool=3;}h.riding=null;}
 Object.assign(h,{x:s.checkpoint.x,y:s.checkpoint.y,vx:0,vy:0,hp:100,stun:0,invulnerableUntil:s.time+3});s.fallen=false;s.paused=false;this.tell('在营火缓过来了。墙、机关、分身和探索进展都保留。');return true;
};
P.lightAt=function(o){const s=this.s;if(s.realm?.kind!=='night')return false;
 if(s.realm.lantern&&dist(o,s.hero)<135)return true;
 return s.props.some(p=>p.kind==='lantern'&&!p.dead&&dist(p,o)<185)||s.realm.nodes.some(n=>n.lit&&dist(n,o)<230)||s.camps.some(n=>n.active&&dist(n,o)<155);
};
P.onIce=function(o){const r=this.s.realm;if(r?.kind!=='frost')return false;const z=r.zones[0];return o.x>z.x&&o.x<z.x+z.w&&o.y>z.y&&o.y<z.y+z.h&&!r.nodes.some(n=>n.lit&&dist(n,o)<180);};
P.speedFactor=function(h){const r=this.s.realm;return(r?.potion==='云行丹'?1.18:1)*(this.onIce(h)?(r.grip.active ? 0.78 : 0.35):1);};
P.energy=function(kind){const r=this.s.realm;if(r?.kind!=='alchemy'||r.brew||r.energy.includes(kind))return;r.energy.push(kind);this.discover('energy-'+kind,`丹炉借到了${{wind:'风',stone:'岩',fire:'炎',ram:'雷'}[kind]}之力。${r.energy.length>=2?'可以靠近按 E 收丹了。':'再试一种不同的力。'}`);this.sound('bell');};
P.explode=function(p){const node=this.s.realm?.nodes.find(n=>n.kind==='furnace');if(node&&dist(p,node)<210)this.energy('fire');return old.explode.call(this,p);};
P.skill=function(){const s=this.s,r=s.realm,h=s.hero;if(s.paused||s.fallen||!r)return false;
 if(r.kind==='night'){r.lantern=!r.lantern;this.tell(r.lantern?'提灯亮了，近处影兽会避让；远处的守望者也更容易发现你。':'提灯熄了，放轻脚步。空格或分身的声音仍会引来它们。');return true;}
 if(r.kind==='frost'){r.grip.active=!r.grip.active;if(r.grip.active)h.vx=h.vy=0;this.tell(r.grip.active?'穿上防滑靴：走得慢一点，停得稳。':'收起防滑靴：冰面会继续带着你滑。');return true;}
 if(!r.brew){this.tell('先让丹炉借入两种不同的力，收丹后就能御气。');return false;}
 if(s.time-r.burstAt<6){this.tell('御气正在恢复，稍等几秒。');return false;}r.burstAt=s.time;h.shieldUntil=s.time+3;
 for(const p of s.props)if(!p.dead&&!p.dormant&&!p.held&&dist(p,h)<240){const u=unit(p.x-h.x,p.y-h.y);p.vx+=u.x*400;p.vy+=u.y*400;}
 for(const m of s.monsters)if(dist(m,h)<230&&h.riding!==m.id){m.mode='stun';m.timer=2;this.speak(m,'灵气太足了！');}this.burst(h.x,h.y,30,'#8de6cf');this.tell('御气散开了：推物、镇住附近灵兽，短暂护身。');this.sound('spring');return true;
};
P.act=function(){const s=this.s,h=s.hero;if(s.paused||s.fallen)return;if(s.recording)return old.act.call(this);
 const camp=s.camps?.filter(c=>dist(c,h)<76&&this.visible(h,c)).sort((a,b)=>dist(h,a)-dist(h,b))[0];
 if(camp&&!h.held&&!h.riding){camp.active=true;s.checkpoint={x:camp.x,y:camp.y};h.hp=100;h.invulnerableUntil=s.time+2;this.tell('营火记住了这里，血量已恢复。');this.sound('heal');return;}
 const node=s.realm?.nodes.filter(n=>dist(n,h)<75+n.r*.3&&this.visible(h,n)).sort((a,b)=>dist(h,a)-dist(h,b))[0];
 if(node&&!h.held){if(node.kind==='furnace'){
   const r=s.realm;if(r.energy.length<2){this.tell('丹炉需要两种不同的力量：试试风、飞石、爆炸或怪兽冲撞。');return;}
   if(!r.brew){r.brew=true;r.potion=r.energy.includes('fire')?'护体丹':r.energy.includes('wind')?'云行丹':'驭兽丹';h.hp=100;s.walls.find(w=>w.id==='spirit-seal').hp=0;this.discover('brew','丹成了：'+r.potion+'！宫门解封，X 可以御气。');this.sound('win');}else this.tell(r.potion+' 已生效。X 可以御气。');return;
  }if(!node.lit){node.lit=true;this.discover(node.id,node.kind==='ward'?'灯塔亮起，附近成为一片亮地。':'火盆点燃了，附近冰面会融开。');this.sound('fuse');}else this.tell(node.kind==='ward'?'灯塔持续照亮这里。':'这里暖和些，冰墙正在融化。');return;
 }
 if(s.realm?.kind==='alchemy'&&dist(h,s.beacon)<65&&!s.realm.brew){this.tell('先让丹炉借入两种力，收丹后再来叩仙门。');return;}
 const before=s.adventureWon;old.act.call(this);if(!before&&s.adventureWon&&!s.journal.completed.includes(s.levelId))s.journal.completed.push(s.levelId);
};
P.monster=function(m,dt){const s=this.s,r=s.realm;
 if(s.hero.riding!==m.id&&!['charge','windup','stun','sleep'].includes(m.mode)){
  const camp=s.camps?.find(c=>c.active&&dist(c,m)<140);if(camp&&!m.kind){const u=unit(m.x-camp.x,m.y-camp.y);this.moveCircle(m,u.x*65*dt,u.y*65*dt);m.cool=Math.max(1,m.cool-dt);m.intent='避开营火，守在外面';return;}
  if(r?.kind==='night'){
   if(!m.kind&&this.lightAt(m)){const source=[...(r.lantern?[s.hero]:[]),...s.props.filter(p=>p.kind==='lantern'&&!p.dead),...r.nodes.filter(n=>n.lit)].sort((a,b)=>dist(a,m)-dist(b,m))[0]||s.hero,u=unit(m.x-source.x,m.y-source.y);this.moveCircle(m,u.x*58*dt,u.y*58*dt);m.cool=Math.max(.5,m.cool-dt);m.intent='影兽正在避光';return;}
   if(!r.lantern&&dist(m,s.hero)>190&&s.time>(m.attentionUntil||0)){m.cool=Math.max(0,m.cool-dt);m.intent='影子在听四周的声音';return;}
  }
 }
 old.monster.call(this,m,dt);
};
P.realmStep=function(dt){const s=this.s,h=s.hero,r=s.realm;
 for(const p of s.healthPacks||[])if(!p.used&&h.hp<100&&dist(p,h)<p.r+h.r+3){p.used=true;h.hp=Math.min(100,h.hp+35);h.healAt=s.time;this.burst(p.x,p.y,14,'#b0e9ad');this.tell('血包 +35。');this.sound('heal');}
 if(!r)return;
 if(r.kind==='night'&&r.nodes.filter(n=>n.lit).length>=2){const w=s.walls.find(w=>w.id==='night-seal');if(w.hp!==0){w.hp=0;this.discover('night-open','两座灯塔回应了，钟楼帘门散开。也可以继续移动提灯，自己布置亮路。');}}
 if(r.kind==='alchemy'){
  const node=r.nodes[0];if(this.inWind(node))this.energy('wind');
  if(s.monsters.some(m=>!m.kind&&m.mode==='charge'&&dist(m,node)<m.r+node.r+12))this.energy('ram');
  if(s.props.some(p=>p.kind==='stone'&&!p.dead&&!p.held&&Math.hypot(p.vx,p.vy)>130&&dist(p,node)<node.r+p.r+12))this.energy('stone');
  if(s.patches.some(p=>p.burn>0&&dist(p,node)<p.r+node.r))this.energy('fire');
  if(r.potion==='驭兽丹')for(const m of s.monsters)if(!m.kind&&dist(m,h)<130&&!['charge','windup'].includes(m.mode)){m.cool=Math.max(3,m.cool);m.intent='灵兽认得你的丹香';}
 }
 if(r.kind==='frost'){
  for(const w of s.walls.filter(w=>w.ice&&w.hp>0))if(r.nodes.some(n=>n.lit&&dist(n,{x:w.x+w.w/2,y:w.y+w.h/2})<220)){w.melt=(w.melt||0)+dt;if(w.melt>3){w.hp=0;this.discover('melt-'+w.id,'火盆的暖意融开了一道冰墙。');}}
  const ball=s.props.find(p=>p.kind==='ball');if(ball&&!ball.dormant&&this.onIce(ball)&&Math.hypot(ball.vx,ball.vy)>70){ball.snow=Math.min(1,(ball.snow||0)+dt*.08);ball.r=30+ball.snow*16;ball.mass=3+ball.snow;}
 }
};
P.update=function(dt,input={}){const s=this.s;if(s.paused||s.fallen)return;dt=clamp(dt,0,.025);
 if(this.onIce(s.hero)&&!s.realm.grip.active&&!s.hero.riding){s.hero.vx=clamp(s.hero.vx+(input.x||0)*420*dt+12*dt,-180,180);s.hero.vy=clamp(s.hero.vy+(input.y||0)*420*dt,-180,180);}
 old.update.call(this,dt,input);if(!s.fallen)this.realmStep(dt);
 // Refresh the latest whole-world snapshot after realm and health changes.
 if(this.history.length&&Math.abs(this.history.at(-1).time-s.time)<.0001)this.history[this.history.length-1]=JSON.parse(JSON.stringify(s));
};
P.load=function(text){let raw;try{raw=JSON.parse(text);}catch{return false;}const finitePoint=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=30&&p.x<=2570&&p.y>=30&&p.y<=1530;
 if(raw.vitals){if(!Number.isFinite(raw.hero?.hp)||raw.hero.hp<0||raw.hero.hp>100||!Array.isArray(raw.healthPacks)||raw.healthPacks.length>12||!raw.healthPacks.every(finitePoint)||!Array.isArray(raw.camps)||raw.camps.length>6||!raw.camps.every(finitePoint)||!finitePoint(raw.checkpoint))return false;}
 if(raw.realm){const r=raw.realm;if(!realmId(raw.levelId)||r.kind!==raw.levelId||!Array.isArray(r.nodes)||r.nodes.length>5||!r.nodes.every(finitePoint)||!Array.isArray(r.energy)||r.energy.length>4||!r.energy.every(e=>['wind','stone','fire','ram'].includes(e))||!Array.isArray(r.zones)||r.zones.length>5||!r.zones.every(z=>[z.x,z.y,z.w,z.h].every(Number.isFinite))||r.kind==='frost'&&!r.grip)return false;}
 if(!old.load.call(this,text))return false;const s=this.s;if(raw.realm)s.levelId=raw.levelId;vitals(s);if(!s.healthPacks)supplies(s,s.levelId==='crossroads'?{x:1740,y:1450}:{x:185,y:690},[[350,805],[790,755],[1220,840],[1300,180]]);s.journal=raw.journal&&Array.isArray(raw.journal.completed)?{completed:raw.journal.completed.filter(id=>MAPS.some(m=>m.id===id))}:{completed:[]};return true;
};
B.release='0.6';
})(typeof module!=='undefined'?module.exports:window);
