(function(root){
'use strict';
const W=2600,H=1560,TAU=Math.PI*2;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const unit=(x,y)=>{const d=Math.hypot(x,y)||1;return{x:x/d,y:y/d};};
const clone=o=>JSON.parse(JSON.stringify(o));
function seeded(n){return()=>{n|=0;n=n+0x6D2B79F5|0;let t=Math.imul(n^n>>>15,1|n);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;};}
function segment(p,a,b){const dx=b.x-a.x,dy=b.y-a.y,t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1),0,1);return{x:a.x+t*dx,y:a.y+t*dy};}
function ends(p){return[{x:p.x-Math.cos(p.angle)*p.length/2,y:p.y-Math.sin(p.angle)*p.length/2},{x:p.x+Math.cos(p.angle)*p.length/2,y:p.y+Math.sin(p.angle)*p.length/2}];}
function rayRect(x,y,dx,dy,r,max){let near=0,far=max;for(const [p,d,a,b]of[[x,dx,r.x,r.x+r.w],[y,dy,r.y,r.y+r.h]]){if(Math.abs(d)<1e-7){if(p<a||p>b)return null;}else{let t1=(a-p)/d,t2=(b-p)/d;if(t1>t2)[t1,t2]=[t2,t1];near=Math.max(near,t1);far=Math.min(far,t2);if(near>far)return null;}}return near>1?near:null;}
function rayPanel(x,y,dx,dy,p,max){const[a,b]=ends(p),sx=b.x-a.x,sy=b.y-a.y,det=dx*sy-dy*sx;if(Math.abs(det)<1e-7)return null;const qx=a.x-x,qy=a.y-y,t=(qx*sy-qy*sx)/det,u=(qx*dy-qy*dx)/det;return t>2&&t<max&&u>=0&&u<=1?t:null;}
function make(seed=1){
 const rand=seeded(seed),j=()=>seed===1?0:(rand()-.5)*100;
 const props=[];const add=(id,kind,x,y,angle=0)=>props.push({id,kind,x,y,angle,r:kind==='panel'?12:kind==='barrel'?18:15,mass:kind==='stone'?2.5:kind==='panel'?2:1,vx:0,vy:0,length:110,held:false,fuse:-1,dead:false,impact:-10});
 add('panel-a','panel',610+j(),650+j(),Math.PI/4);add('panel-b','panel',700+j(),295+j(),0);add('panel-c','panel',440+j(),540+j(),Math.PI/2);
 add('barrel-a','barrel',640+j(),440+j());add('barrel-b','barrel',725+j(),405+j());add('barrel-c','barrel',780+j(),505+j());add('barrel-d','barrel',1170+j()*.3,720+j());
 add('stone-a','stone',300+j(),705+j());add('stone-b','stone',515+j(),775+j());add('stone-c','stone',1200+j()*.2,290+j());
 add('resin-a','resin',380+j(),655+j());add('resin-b','resin',725+j(),650+j());add('resin-c','resin',1180+j()*.3,170+j()*.3);
 add('barrel-e','barrel',230+j()*.3,190+j()*.3);add('barrel-f','barrel',880+j(),175+j()*.3);add('panel-d','panel',930+j(),210+j()*.3,Math.PI/2);
 add('toy-ram','toy',450,350);add('toy-nap','toy',1090,230);add('big-ball','ball',200,220);
 props.find(p=>p.id==='toy-ram').owner='ram';props.find(p=>p.id==='toy-nap').owner='nap';const ball=props.find(p=>p.id==='big-ball');ball.r=30;ball.mass=3;ball.dormant=true;
 add('coil-kit','coil',760,755);add('helmet-kit','helmet',1485,205);props.find(p=>p.id==='helmet-kit').dormant=true;
 for(const p of props)p.home={x:p.x,y:p.y,angle:p.angle};
 return{version:4,seed,time:0,hero:{x:185,y:690,r:15,vx:0,vy:0,dx:1,dy:0,held:null,stun:0,riding:null},
 monsters:[{id:'ram',x:405,y:420,r:29,vx:0,vy:0,dx:1,dy:0,mode:'idle',timer:1.7,cool:1.2,target:null,path:[],pathAt:-1,home:{x:450,y:350},intent:'看着自己的彩桶'},
 {id:'nap',x:1060,y:180,r:26,vx:0,vy:0,dx:0,dy:1,mode:'sleep',timer:0,cool:1.2,target:null,path:[],pathAt:-1,home:{x:1090,y:230},intent:'睡觉也要守着彩桶'},
 {id:'slinger',kind:'thrower',x:1520,y:455,r:26,dx:-1,dy:0,mode:'sleep',timer:0,cool:0,home:{x:1520,y:455},intent:'水池旁边的投石手'},
 {id:'spitter',kind:'spitter',x:1570,y:690,r:24,dx:-1,dy:0,mode:'sleep',timer:0,cool:0,home:{x:1570,y:690},intent:'守着坡道的黏液怪'}],
 props,walls:[
 {id:'north',x:850,y:340,w:300,h:22,hp:-1},{id:'south-left',x:850,y:558,w:140,h:22,hp:-1},{id:'south-right',x:1074,y:558,w:76,h:22,hp:-1},
 {id:'west-top',x:850,y:362,w:22,h:48,hp:-1},{id:'west-breach',x:850,y:410,w:22,h:100,hp:3,max:3}, {id:'west-bottom',x:850,y:510,w:22,h:48,hp:-1},
 {id:'east-top',x:1128,y:362,w:22,h:48,hp:-1},{id:'east-breach',x:1128,y:410,w:22,h:100,hp:3,max:3},{id:'east-bottom',x:1128,y:510,w:22,h:48,hp:-1},
 {id:'gate',x:990,y:558,w:84,h:22,hp:-1,gate:true},
 {id:'bench-a',x:335,y:235,w:170,h:35,hp:-1},{id:'bench-b',x:225,y:490,w:70,h:32,hp:-1},{id:'bench-c',x:570,y:120,w:40,h:135,hp:-1},
 {id:'shed-top',x:100,y:100,w:200,h:18,hp:-1},{id:'shed-side',x:100,y:118,w:18,h:180,hp:-1},
 {id:'shed-front-a',x:100,y:280,w:55,h:18,hp:-1},{id:'shed-front-b',x:245,y:280,w:55,h:18,hp:-1},
 {id:'shed-breach',x:155,y:280,w:90,h:18,hp:2,max:2},{id:'shed-right',x:282,y:118,w:18,h:162,hp:-1},
 {id:'pool-top',x:1350,y:90,w:310,h:20,hp:-1},{id:'pool-right',x:1640,y:110,w:20,h:230,hp:-1},
 {id:'pool-left-a',x:1350,y:110,w:20,h:70,hp:-1},{id:'dam',x:1350,y:180,w:20,h:110,hp:3,max:3},
 {id:'pool-left-b',x:1350,y:290,w:20,h:50,hp:-1},{id:'pool-bottom',x:1350,y:320,w:290,h:20,hp:-1},
 {id:'lookout-left-a',x:1450,y:820,w:20,h:75,hp:-1,low:true},{id:'lookout-side',x:1450,y:895,w:20,h:80,hp:3,max:3,low:true},
 {id:'lookout-left-b',x:1450,y:975,w:20,h:35,hp:-1,low:true},{id:'lookout-right',x:1670,y:820,w:20,h:190,hp:-1,low:true},
 {id:'lookout-bottom',x:1470,y:990,w:200,h:20,hp:-1,low:true},{id:'hard-gate',x:1470,y:820,w:200,h:22,hp:3,max:3,tough:true}
 ],fan:{x:1032,y:794,angle:Math.PI,on:true,r:30},turbine:{x:1032,y:636,r:25,charge:0,open:false,powered:false},button:{x:1000,y:450,r:23},
 pads:[{id:'spring-a',x:570,y:725,r:27,angle:-Math.PI/4,on:true,pulse:-10},{id:'spring-b',x:1230,y:570,r:27,angle:-Math.PI/2,on:true,pulse:-10}],
 bells:[{id:'bell-a',x:190,y:159,r:19,rung:false,at:-10,wind:0},{id:'bell-b',x:760,y:172,r:19,rung:false,at:-10,wind:0},{id:'bell-c',x:1255,y:802,r:19,rung:false,at:-10,wind:0}],
 cabinet:{x:160,y:350,r:24},patches:[],episode:{stolen:false,warehouse:false,ballSwaps:0},
 flood:{open:false,level:0},shots:[],beacon:{x:1570,y:935,r:22},adventureWon:false,
 won:false,paused:false,stats:{throws:0,ramHits:0,blasts:0,reflects:0,bumps:0,bounces:0,spills:0,fires:0,bells:0,returns:0,steals:0,method:null},discoveries:[],logs:[],notice:'撞撞有自己的彩桶，仓库里也藏着东西。看看你能惹出什么事。',noticeUntil:8,effects:[],shake:0,whistle:-10,gateHold:false};
}
class Game{
 constructor(seed=1){this.s=make(seed);this.history=[];this.snapAt=0;this.sound=()=>{};this.onWin=()=>{};this.particles=[];this.beams=[];this.flashes=[];this.tickWind();}
 reset(seed=1){this.s=make(seed);this.history=[];this.snapAt=0;this.particles=[];this.flashes=[];this.tickWind();}
 tell(msg){this.s.notice=msg;this.s.noticeUntil=this.s.time+5;}
 discover(id,text){if(!this.s.discoveries.includes(id)){this.s.discoveries.push(id);this.s.logs.unshift(text);this.s.logs=this.s.logs.slice(0,6);this.tell(text);}}
 activeWalls(){return this.s.walls.filter(w=>w.hp!==0&&!(w.gate&&this.s.turbine.open));}
 blocked(x,y,r=14){if(x<r+30||y<r+30||x>W-r-30||y>H-r-30)return true;return this.activeWalls().some(w=>x+r>w.x&&x-r<w.x+w.w&&y+r>w.y&&y-r<w.y+w.h);}
 visible(a,b){const d=dist(a,b),u=unit(b.x-a.x,b.y-a.y);return!this.activeWalls().some(w=>rayRect(a.x,a.y,u.x,u.y,w,d)!==null);}
 path(a,b,r=30){
 const cell=r>24?20:40,cols=Math.ceil(W/cell),rows=Math.ceil(H/cell),key=(x,y)=>y*cols+x;
 const sx=clamp(Math.floor(a.x/cell),0,cols-1),sy=clamp(Math.floor(a.y/cell),0,rows-1),tx=clamp(Math.floor(b.x/cell),0,cols-1),ty=clamp(Math.floor(b.y/cell),0,rows-1),q=[[sx,sy]],seen=new Map([[key(sx,sy),null]]);let end=null;
 for(let i=0;i<q.length;i++){const[x,y]=q[i];if(x===tx&&y===ty){end=key(x,y);break;}for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=key(nx,ny);if(nx<0||ny<0||nx>=cols||ny>=rows||seen.has(k)||this.blocked(nx*cell+cell/2,ny*cell+cell/2,r))continue;seen.set(k,key(x,y));q.push([nx,ny]);}}
 if(end===null)return[];const out=[{x:b.x,y:b.y}];for(let k=end;k!==null;k=seen.get(k))out.unshift({x:(k%cols)*cell+cell/2,y:Math.floor(k/cols)*cell+cell/2});out.shift();return out;
 }
 moveCircle(o,dx,dy,damage=false){
  let hit=false;o.x+=dx;o.y+=dy;
  for(const w of this.activeWalls()){
   if(w.low&&((o.air||0)>0||(o.launch||0)>.15||o.gear==='coil'&&o.mode==='charge'))continue;
   const px=clamp(o.x,w.x,w.x+w.w),py=clamp(o.y,w.y,w.y+w.h),v=unit(o.x-px,o.y-py),d=Math.hypot(o.x-px,o.y-py);
   if(d>=o.r)continue;
   if(damage&&this.s.time-(o.hitAt||-10)>.18){this.damage(w,w.tough?(o.gear==='helmet'?3:0):3,'ram');o.hitAt=this.s.time;if(w.hp===0)continue;}
   hit=true;
   if(d>0){o.x=px+v.x*o.r;o.y=py+v.y*o.r;}else{const choices=[{d:Math.abs(o.x-w.x),x:w.x-o.r,y:o.y},{d:Math.abs(o.x-w.x-w.w),x:w.x+w.w+o.r,y:o.y},{d:Math.abs(o.y-w.y),x:o.x,y:w.y-o.r},{d:Math.abs(o.y-w.y-w.h),x:o.x,y:w.y+w.h+o.r}];choices.sort((a,b)=>a.d-b.d);o.x=choices[0].x;o.y=choices[0].y;}
  }
  const nx=clamp(o.x,30+o.r,W-30-o.r),ny=clamp(o.y,30+o.r,H-30-o.r);if(nx!==o.x||ny!==o.y)hit=true;o.x=nx;o.y=ny;return hit;
 }
 damage(w,n,cause){if(w.hp<=0)return;if(w.tough&&cause!=='ram'){this.tell('这块加固门很硬，可以借桶盔，或换条路。');return;}if(n===0){this.tell('太硬了，给撞撞套上桶盔再试试。');this.sound('hit');return;}w.hp=Math.max(0,w.hp-n);this.burst(w.x+w.w/2,w.y+w.h/2,18,'#ddd2b5');this.sound('hit');this.s.shake=7;if(w.hp===0){this.s.stats.method=this.s.stats.method||cause;this.discover('breach-'+cause,cause==='ram'?'借力成功：它替你拆了墙。':cause==='blast'?'连锁反应：爆炸打开了入口。':cause==='ball'?'圆球砸开了墙，滚动也是一种力量。':cause==='enemy'?'借来的石头，替你拆了墙。':'石头也能拆墙，多砸几下就行。');}else this.tell('墙松动了，还能继续砸。');}
 burst(x,y,n,color){for(let i=0;i<n;i++){const a=Math.random()*TAU,sp=40+Math.random()*170;this.particles.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:.3+Math.random()*.5,max:.8,color,r:2+Math.random()*3});}if(this.particles.length>400)this.particles.splice(0,this.particles.length-400);}
 closest(){const s=this.s,h=s.hero,candidates=s.props.filter(p=>!p.dead&&!p.dormant&&!p.held).map(p=>({type:'prop',o:p,d:dist(h,p)+40*(1-((p.x-h.x)*h.dx+(p.y-h.y)*h.dy)/(dist(h,p)||1))}));candidates.push({type:'fan',o:s.fan,d:dist(h,s.fan)-12},{type:'cabinet',o:s.cabinet,d:dist(h,s.cabinet)-5});for(const p of s.pads)candidates.push({type:'pad',o:p,d:dist(h,p)+4});if(!s.adventureWon)candidates.push({type:'beacon',o:s.beacon,d:dist(h,s.beacon)});if(!s.won)candidates.push({type:'button',o:s.button,d:dist(h,s.button)});return candidates.filter(c=>c.d<62&&this.visible(h,c.o)).sort((a,b)=>a.d-b.d)[0]||null;}
 act(){if(this.s.paused)return;const s=this.s,h=s.hero;if(h.riding){this.mount();return;}if(h.held){if(this.useKit())return;this.drop(false);return;}const c=this.closest();if(!c){this.tell('靠近物品按 E 拿起；空手按空格可以招惹它。');return;}if(c.type==='fan'){s.fan.on=!s.fan.on;this.sound('click');this.tell(s.fan.on?'风机启动。靠近按 Q 转动。':'风机停止。');return;}if(c.type==='button'){s.won=true;s.stats.method=s.stats.method||(s.turbine.open?'wind':'stone');this.discover('win','开罐成功！院子归你了，继续折腾也可以。');this.sound('win');this.onWin(clone(s.stats));return;}
 if(c.type==='beacon'){s.adventureWon=true;this.discover('adventure-win','到达观景台！这一院子的麻烦，真让你借上力了。');this.sound('win');if(this.onAdventureWin)this.onAdventureWin();return;}
 if(c.type==='pad'){c.o.on=!c.o.on;this.tell(c.o.on?'弹簧垫开启。Q 改变弹射方向。':'弹簧垫关闭。');this.sound('click');return;}
 if(c.type==='cabinet'){this.restock();return;}
 const p=c.o;if(p.kind==='ball'){const u=unit(p.x-h.x,p.y-h.y);p.vx=u.x*440;p.vy=u.y*440;p.lastBy='you';p.throwAt=s.time;this.sound('throw');this.tell('球滚了。看看谁会先过来。');return;}
 p.held=true;p.vx=p.vy=0;h.held=p.id;if(p.owner){s.stats.steals++;s.episode.stolen=true;this.discover('steal','彩桶有主人。它发现你拿走了！');this.tell('拿走了它的宝贝……');}else if(p.fuse>=0)this.tell('这桶已经冒火了，快扔！');else this.tell(p.kind==='panel'?'拿起隔板。Q 转向，空格扔出。':p.kind==='barrel'?'拿起爆桶。撞击会点燃引信。':p.kind==='resin'?'拿起树脂罐。扔出去会留下黏地；遇火会烧。':['coil','helmet'].includes(p.kind)?'拿着靠近撞撞，再按 E 装上；也可以扔到它身上。':'拿起石头。可以砸、挡、推。');this.sound('pick');}
 drop(thrown){const s=this.s,h=s.hero,p=s.props.find(p=>p.id===h.held);if(!p)return;const reach=p.kind==='panel'?h.r+22:h.r+p.r+9;let x=h.x+h.dx*reach,y=h.y+h.dy*reach;if(this.blocked(x,y,p.r)){x=h.x;y=h.y;}p.x=x;p.y=y;p.held=false;h.held=null;const speed=thrown?510:28;p.vx=h.dx*speed;p.vy=h.dy*speed;p.throwAt=thrown?s.time:-10;if(thrown){s.stats.throws++;this.sound('throw');this.burst(p.x,p.y,4,'#f8e6ba');}return p;}
 throwOrCall(){if(this.s.paused)return;const s=this.s,h=s.hero;if(h.riding){const m=s.monsters.find(m=>m.id===h.riding);if(m&&m.mode!=='charge'&&m.mode!=='stun'){m.dx=h.dx;m.dy=h.dy;m.mode='charge';m.timer=1.25;this.sound('ram');}else if(m&&m.mode==='stun')this.tell('它还在缓一缓，恢复后就能再冲。');return;}if(h.held){this.drop(true);return;}if(s.time-s.whistle<.65)return;s.whistle=s.time;this.sound('whistle');for(const m of s.monsters){if(m.kind){if(dist(m,h)<650){m.alert=true;m.mode='idle';m.cool=0;}continue;}if(dist(m,h)>900||m.mode==='charge')continue;m.target={x:h.x,y:h.y};m.cool=0;if(m.mode!=='stun')this.windup(m,h);}this.tell('喂，往这儿看！它会朝红线方向冲。');}
 rotate(sign=1){if(this.s.paused)return;const h=this.s.hero,p=this.s.props.find(p=>p.id===h.held);if(p&&p.kind==='panel'){p.angle+=sign*Math.PI/4;this.sound('click');return;}const machines=[{o:this.s.fan,type:'fan'},...this.s.pads.map(o=>({o,type:'pad'}))].filter(t=>dist(h,t.o)<90).sort((a,b)=>dist(h,a.o)-dist(h,b.o));if(machines.length){const target=machines[0];target.o.angle+=sign*Math.PI/4;this.sound('click');this.tell(target.type==='fan'?'风向变了。风遇到隔板会折返。':'弹簧垫转向了，人、怪物和东西都能被弹开。');return;}const panel=this.s.props.filter(p=>p.kind==='panel'&&!p.dead&&!p.dormant&&!p.held&&dist(h,p)<75).sort((a,b)=>dist(h,a)-dist(h,b))[0];if(panel){panel.angle+=sign*Math.PI/4;this.sound('click');}else this.tell('靠近风机、弹簧垫，或拿着隔板，再按 Q 转向。');}
 restock(){let n=0;for(const p of this.s.props){if(!p.dead)continue;const h=p.home;p.x=h.x;p.y=h.y;p.angle=h.angle;p.dead=false;p.held=false;p.vx=p.vy=0;p.fuse=-1;p.throwAt=-10;p.springAt=-10;n++;}this.tell(n?`补回了 ${n} 件消耗掉的物品，继续试。`:'消耗掉的桶和树脂罐，可以在这里补回来。');this.sound('pick');}
 spill(p,burning=false){if(p.dead)return null;p.dead=true;p.held=false;if(this.s.hero.held===p.id)this.s.hero.held=null;const patch={id:p.id+'-'+this.s.time,x:p.x,y:p.y,r:65,burn:0,spent:false};this.s.patches.push(patch);if(this.s.patches.length>30)this.s.patches.shift();this.s.stats.spills++;this.burst(p.x,p.y,16,'#a8b94d');this.sound('spill');this.discover('resin','树脂洒出来了。能拖慢脚步，也能拖慢冲撞。');if(burning)this.light(patch);return patch;}
 light(p){if(p.spent||p.burn>0)return;if(this.water(p)){p.burn=0;p.spent=true;return;}p.burn=7;this.s.stats.fires++;this.discover('fire','黏地烧起来了，火还能点燃旁边的桶。');this.sound('fuse');}
 sticky(o){return this.s.patches.some(p=>!p.spent&&dist(p,o)<p.r+o.r*.4);}
 ring(b,cause){if(this.s.time-b.at<.7)return;b.at=this.s.time;this.sound('bell');this.burst(b.x,b.y,10,'#f5d464');if(!b.rung){b.rung=true;this.s.stats.bells++;this.discover('bell-'+b.id,`第 ${this.s.stats.bells} 口铃响了。${cause==='wind'?'风也能敲铃。':cause==='ram'?'它也能帮你敲铃。':'扔东西、弹射、爆炸，都能敲响它。'}`);if(this.s.stats.bells===3)this.discover('all-bells','三口铃都响了！院子里的实验还可以继续。');}}
 springs(){const s=this.s;for(const pad of s.pads){if(!pad.on)continue;const candidates=[...(s.hero.riding?[]:[{o:s.hero,type:'hero'}]),...s.monsters.map(o=>({o,type:'monster'})),...s.props.filter(p=>!p.dead&&!p.dormant&&!p.held).map(o=>({o,type:'prop'}))];for(const {o,type}of candidates){if(dist(o,pad)>pad.r+o.r*.45||s.time-(o.springAt??-10)<1.1)continue;o.springAt=s.time;pad.pulse=s.time;const u={x:Math.cos(pad.angle),y:Math.sin(pad.angle)};
 if(type==='monster'){o.dx=u.x;o.dy=u.y;o.mode='charge';o.timer=1.25;this.discover('spring-monster','撞撞被弹偏了！弹簧垫能改它的冲撞方向。');}else{o.vx=u.x*(type==='hero'?670:730/Math.pow(o.mass,.2));o.vy=u.y*(type==='hero'?670:730/Math.pow(o.mass,.2));if(type==='hero'){o.launch=.7;this.discover('spring-you','弹起来了！按方向还能修正落点。');}else{ o.throwAt=s.time;this.discover('spring-prop','物品也能被弹射，换个角度会飞向哪里？');}}
 s.stats.bounces++;this.sound('spring');this.burst(pad.x,pad.y,15,'#edbd6a');}}
 }
 surroundings(dt){const s=this.s;
  for(const p of s.patches){if(p.burn<=0||p.spent)continue;if(this.water(p)){p.burn=0;p.spent=true;continue;}p.burn=Math.max(0,p.burn-dt);const wind=this.inWind(p),heat=wind?120:83;this.burst(p.x+(Math.random()-.5)*90,p.y+(Math.random()-.5)*65,1,'#ed914a');
   for(const q of s.patches)if(q!==p&&!q.spent&&q.burn<=0&&dist(p,q)<p.r+q.r+(wind?60:0))this.light(q);
   for(const q of s.props){if(q.dead||q.held||dist(p,q)>heat+q.r)continue;if(q.kind==='barrel')this.ignite(q,.65);if(q.kind==='resin')this.spill(q,true);}
   for(const m of s.monsters)if(dist(m,p)<p.r+m.r){const u=unit(m.x-p.x,m.y-p.y);m.mode='stun';m.timer=Math.max(m.timer,.5);this.moveCircle(m,u.x*48*dt,u.y*48*dt);}
   const h=s.hero;if(dist(p,h)<p.r+h.r&&s.time-(h.fireAt??-10)>1){h.fireAt=s.time;const u=unit(h.x-p.x,h.y-p.y);h.vx+=u.x*100;h.vy+=u.y*100;this.hurt?.(7,'燃烧地面');this.tell(this.hurt?'地面在烧，离远一点；血包和营火能恢复。':'有点烫！只会推开你，不扣血。');}
   if(p.burn===0)p.spent=true;
  }
  for(const b of s.bells){const wind=this.inWind(b);b.wind=wind?b.wind+dt:0;if(b.wind>.8)this.ring(b,'wind');for(const p of s.props)if(!p.dead&&!p.dormant&&!p.held&&Math.hypot(p.vx,p.vy)>130&&dist(b,p)<b.r+p.r){this.ring(b,'prop');const u=unit(p.x-b.x,p.y-b.y),speed=Math.hypot(p.vx,p.vy)*.7;p.vx=u.x*speed;p.vy=u.y*speed;}for(const m of s.monsters)if(m.mode==='charge'&&dist(m,b)<m.r+b.r)this.ring(b,'ram');}
  for(let i=0;i<s.monsters.length;i++)for(let j=i+1;j<s.monsters.length;j++){const a=s.monsters[i],b=s.monsters[j],d=dist(a,b);if(d>=a.r+b.r)continue;const u=unit(b.x-a.x,b.y-a.y);this.moveCircle(a,-u.x*(a.r+b.r-d)/2,-u.y*(a.r+b.r-d)/2);this.moveCircle(b,u.x*(a.r+b.r-d)/2,u.y*(a.r+b.r-d)/2);if(a.mode==='charge'||b.mode==='charge'){if(s.hero.riding===a.id||s.hero.riding===b.id)this.hurt?.(12,'骑乘碰撞');a.mode=b.mode='stun';a.timer=b.timer=3;this.discover('monster-bump','撞撞撞撞撞了！它们也会互相拦路。');this.sound('hit');s.shake=8;}}
 }
 useKit(){const p=this.s.props.find(p=>p.id===this.s.hero.held);if(!p||!['coil','helmet'].includes(p.kind))return false;const m=this.s.monsters.filter(m=>!m.kind&&dist(m,this.s.hero)<86&&this.visible(m,this.s.hero)).sort((a,b)=>dist(a,this.s.hero)-dist(b,this.s.hero))[0];if(!m)return false;this.applyKit(m,p);return true;}
 applyKit(m,p){if(p.dead)return;p.dead=true;p.held=false;if(this.s.hero.held===p.id)this.s.hero.held=null;m.gear=p.kind;this.discover('gear-'+p.kind,p.kind==='coil'?'弹簧装上了：它冲起来会连跳，撞硬物还会弹回来。':'桶盔套上了：看不远了，撞硬门和挡石头却更厉害。');this.speak(m,p.kind==='coil'?'怎么停不下来？':'天怎么黑了？');this.sound('spring');}
 mount(){const s=this.s,h=s.hero;if(s.paused)return false;if(h.riding){const m=s.monsters.find(m=>m.id===h.riding);for(let i=0;i<8;i++){const a=Math.atan2(h.dy,h.dx)+i*Math.PI/4,p={x:m.x+Math.cos(a)*(m.r+h.r+13),y:m.y+Math.sin(a)*(m.r+h.r+13)};if(!this.blocked(p.x,p.y,h.r)&&this.visible(m,p)){h.x=p.x;h.y=p.y;h.riding=null;m.mode='idle';m.cool=1.8;m.air=0;this.tell('下来了，它又要忙自己的事情了。');return true;}}this.tell('这里挤了点，挪到空地再下来。');return false;}
 if(h.held){this.tell('先按 E 放下手里的东西，再骑上去。');return false;}const m=s.monsters.filter(m=>!m.kind&&!['charge','windup','sleep'].includes(m.mode)&&dist(m,h)<80&&this.visible(m,h)).sort((a,b)=>dist(a,h)-dist(b,h))[0];if(!m){this.tell('靠近平静或撞晕的撞撞，按 F 骑上去。');return false;}h.riding=m.id;m.mode='ridden';m.timer=0;h.x=m.x;h.y=m.y;h.vx=h.vy=0;this.discover('ride','骑上去了！方向键带路，空格冲撞，F 下来。');return true;
 }
 rideStep(m,dt){const s=this.s,h=s.hero;m.timer-=dt;m.air=m.gear==='coil'&&m.mode==='charge'&&(Math.sin(s.time*13)>-.25)?20:0;
 if(m.mode==='stun'){m.intent='撞懵了，骑着缓一缓';if(m.timer<=0)m.mode='ridden';return;}
 if(m.mode==='charge'){const hit=this.moveCircle(m,m.dx*(m.gear==='coil'?520:445)*dt,m.dy*(m.gear==='coil'?520:445)*dt,true);this.ramContact(m);if(hit&&m.gear==='coil'&&m.timer>.2){m.dx=-m.dx;m.dy=-m.dy;m.timer-=.15;this.sound('spring');}else if(hit||m.timer<=0){m.mode='stun';m.timer=.85;this.sound('hit');}m.intent='带着你冲撞';return;}
 m.mode='ridden';const input=this.rideInput||{x:0,y:0},ball=s.props.find(p=>p.kind==='ball'&&!p.dormant),toy=s.props.find(p=>p.owner===m.id);let dx=input.x,dy=input.y;const instinct=ball&&dist(m,ball)<280?ball:toy&&dist(m,toy)>100?toy:null;if(instinct){const u=unit(instinct.x-m.x,instinct.y-m.y);dx=dx*.85+u.x*.15;dy=dy*.85+u.y*.15;}const moving=Math.hypot(dx,dy)>.01;if(moving){const u=unit(dx,dy);m.dx=u.x;m.dy=u.y;const speed=Math.hypot(input.x,input.y)>.01?(this.water(m)?90:132):42;this.moveCircle(m,u.x*speed*dt,u.y*speed*dt);}m.intent=instinct?'驮着你，还惦记着宝贝':'驮着你，等你带路';if(!input.aim){h.dx=m.dx;h.dy=m.dy;}
 }
 ramContact(m){for(const p of this.s.props){if(p.dead||p.dormant||p.held)continue;const near=p.kind==='panel'?dist(m,segment(m,...ends(p)))<m.r+8:dist(m,p)<m.r+p.r;if(!near)continue;if(['coil','helmet'].includes(p.kind)){this.applyKit(m,p);continue;}const power=p.kind==='ball'?620:520/p.mass;p.vx=m.dx*power;p.vy=m.dy*power;this.moveCircle(p,m.dx*12,m.dy*12);if(p.kind==='barrel')this.ignite(p,.65);if(p.kind==='resin')this.spill(p);}}
 water(o){if(!this.s.flood.open||this.s.flood.level<.06)return null;if(o.x>1480&&o.x<1650&&o.y>600&&o.y<735)return null;const zones=[{x:1370,y:110,w:270,h:210,dx:-1,dy:0},{x:1190,y:205,w:180,h:175,dx:-.5,dy:.7},{x:1190,y:380,w:460,h:150,dx:.35,dy:.8},{x:1280,y:530,w:370,h:250,dx:0,dy:1}];return zones.find(z=>o.x>z.x&&o.x<z.x+z.w&&o.y>z.y&&o.y<z.y+z.h)||null;}
 addGlue(x,y,r=43,id='glob'){const p={id:id+'-'+this.s.time,x,y,r,burn:0,spent:false};this.s.patches.push(p);if(this.s.patches.length>30)this.s.patches.shift();return p;}
 adventure(dt){const s=this.s,dam=s.walls.find(w=>w.id==='dam');if(dam.hp===0&&!s.flood.open){s.flood.open=true;const kit=s.props.find(p=>p.id==='helmet-kit');if(kit.dormant){kit.dormant=false;kit.x=1310;kit.y=250;kit.vx=-90;kit.vy=65;}this.discover('water-open','水放出来了！桶盔也被冲了出来，右边的家伙醒了。');this.sound('gate');}if(s.flood.open)s.flood.level=Math.min(1,s.flood.level+dt/4);
 for(const p of s.patches)if(this.water(p)&&!p.spent){p.burn=0;p.spent=true;this.discover('water-wash','水冲掉了树脂，也能把火浇灭。');}
 for(const p of s.props){if(p.dead||p.dormant||p.held)continue;const w=this.water(p);if(w){const force=['helmet','barrel','toy','coil','panel'].includes(p.kind)?90:25;p.vx+=w.dx*force*dt;p.vy+=w.dy*force*dt;}}
 for(const m of s.monsters){const w=this.water(m);if(w){m.coated=0;if(!m.kind&&s.hero.riding!==m.id&&s.time-(m.waterAt??-10)>3){m.waterAt=s.time;if(m.mode==='charge'){m.mode='stun';m.timer=1.2;this.moveCircle(m,-m.dx*18,-m.dy*18);}this.speak(m,'水！我慢点走。');}}
 else{m.coated=Math.max(0,(m.coated||0)-dt);if(s.patches.some(p=>!p.spent&&p.burn<=0&&!p.id.startsWith('trail')&&dist(p,m)<p.r+m.r))m.coated=12;}
 if(m.coated>0&&s.time-(m.trailAt??-10)>.85){m.trailAt=s.time;this.addGlue(m.x-m.dx*27,m.y-m.dy*27,25,'trail');this.discover('coated','它身上粘满了树脂，走到哪儿，黏地就留到哪儿。');}}
 const h=s.hero,w=this.water(h);if(w&&!h.riding)this.moveCircle(h,w.dx*18*dt,w.dy*18*dt);this.projectiles(dt);
 }
 sentry(m,dt){const s=this.s,h=s.hero;m.timer-=dt;m.cool-=dt;if(m.mode==='stun'){m.alert=true;if(m.timer<=0){m.mode='idle';m.cool=1.6;}return;}const active=s.flood.open||h.x>1330||m.alert;if(!active){m.mode='sleep';return;}if(m.mode==='sleep')m.mode='idle';
 if(m.mode==='windup'&&!m.target){m.mode='idle';m.cool=.5;return;}
 if(m.mode==='windup'){if(m.timer<=0){const u=unit(m.target.x-m.x,m.target.y-m.y);s.shots.push({kind:m.kind==='thrower'?'rock':'glob',owner:m.id,x:m.x+u.x*(m.r+14),y:m.y+u.y*(m.r+14),vx:u.x*(m.kind==='thrower'?350:260),vy:u.y*(m.kind==='thrower'?350:260),r:10,life:3.2,age:0});if(s.shots.length>18)s.shots.shift();m.mode='idle';m.cool=m.kind==='thrower'?2.3:2.7;this.sound('throw');}return;}
 const intruder=s.monsters.filter(q=>q!==m&&!q.kind&&dist(q,m)<360&&q.mode!=='sleep').sort((a,b)=>dist(a,m)-dist(b,m))[0],target=this.echoActor&&s.time<(m.attentionUntil||0)&&this.echoActor(m.attention)||((intruder&&dist(intruder,m)<dist(h,m)+50)?intruder:h);
 if(dist(m,target)<520&&this.visible(m,target)&&m.cool<=0){m.target={x:target.x,y:target.y};const u=unit(target.x-m.x,target.y-m.y);m.dx=u.x;m.dy=u.y;m.mode='windup';m.timer=1.25;m.intent=m.kind==='thrower'?'锁定位置，准备扔石头':'准备向那边喷黏液';this.sound('warning');}else m.intent='看着路过的家伙';
 }
 projectiles(dt){const s=this.s;for(const q of s.shots){q.life-=dt;q.age+=dt;if(q.life<=0)continue;q.x+=q.vx*dt;q.y+=q.vy*dt;let hit=false;
 for(const w of this.activeWalls())if(q.x+q.r>w.x&&q.x-q.r<w.x+w.w&&q.y+q.r>w.y&&q.y-q.r<w.y+w.h){if(q.kind==='rock')this.damage(w,1,'enemy');hit=true;break;}
 for(const p of s.props){if(hit||p.dead||p.dormant||p.held)continue;const pt=p.kind==='panel'?segment(q,...ends(p)):p;if(dist(q,pt)>q.r+(p.kind==='panel'?7:p.r))continue;if(p.kind==='panel'&&s.time-(q.bounceAt??-10)>.18){const nx=-Math.sin(p.angle),ny=Math.cos(p.angle),dot=q.vx*nx+q.vy*ny;q.vx-=2*dot*nx;q.vy-=2*dot*ny;q.bounceAt=s.time;q.x+=q.vx*dt*2;q.y+=q.vy*dt*2;q.owner='reflected';this.discover('reflect-shot','隔板把攻击弹回去了。');}else if(p.kind!=='panel'){const u=unit(p.x-q.x,p.y-q.y);p.vx+=u.x*170;p.vy+=u.y*170;if(q.kind==='rock'&&p.kind==='barrel')this.ignite(p,.65);hit=true;}}
 for(const m of s.monsters){if(hit||m.id===q.owner||dist(m,q)>m.r+q.r)continue;if(q.kind==='rock'&&m.gear==='helmet'){const u=unit(q.x-m.x,q.y-m.y);q.vx=u.x*340;q.vy=u.y*340;q.x=m.x+u.x*(m.r+q.r+4);q.y=m.y+u.y*(m.r+q.r+4);q.owner=m.id;this.discover('helmet-block','桶盔挡住了石头，还把它弹回去了！');}else{if(s.hero.riding===m.id)this.hurt?.(q.kind==='rock'?10:6,q.kind==='rock'?'骑乘时被飞石击中':'骑乘时沾上黏液');if(q.kind==='rock'){m.mode='stun';m.timer=3;this.discover('enemy-hit','借来的石头砸中了怪兽，现在能靠近骑上去。');}else{m.coated=12;this.addGlue(q.x,q.y);this.discover('glue-hit','黏液喷到别的怪兽身上了。');}m.alert=true;hit=true;}}
 const h=s.hero;if(!hit&&!h.riding&&dist(h,q)<h.r+q.r){const u=unit(h.x-q.x,h.y-q.y);h.vx+=u.x*140;h.vy+=u.y*140;this.hurt?.(q.kind==='rock'?14:9,q.kind==='rock'?'飞石':'黏液');hit=true;this.tell(q.kind==='rock'?'被石头顶了一下。可以借怪兽或隔板挡住它。':'沾上黏液了，浅水能冲掉。');}
 if(q.kind==='glob'&&q.age>1.25)hit=true;if(q.x<30||q.x>W-30||q.y<30||q.y>H-30)hit=true;if(hit){if(q.kind==='glob'){const p=this.addGlue(q.x,q.y);if(this.water(p))p.spent=true;}this.burst(q.x,q.y,8,q.kind==='rock'?'#a1afa2':'#9eae55');q.life=0;}}
 s.shots=s.shots.filter(q=>q.life>0);
 }
 speak(m,text){if(m.say===text&&this.s.time<(m.sayUntil||0)+3)return;m.say=text;m.sayUntil=this.s.time+2.5;}
 mindWalk(m,target,speed,dt){let t=target;if(!this.visible(m,target)){if(this.s.time-m.pathAt>.6||!m.mindGoal||dist(m.mindGoal,target)>45){m.path=this.path(m,target,m.r+1);m.pathAt=this.s.time;m.mindGoal={x:target.x,y:target.y};}while(m.path.length&&dist(m,m.path[0])<16)m.path.shift();if(m.path.length)t=m.path[0];else{m.intent='路堵了，绕不过去……';return false;}}const u=unit(t.x-m.x,t.y-m.y);m.dx=u.x;m.dy=u.y;this.moveCircle(m,u.x*speed*dt,u.y*speed*dt);
 for(const q of this.s.props){if(q.kind!=='panel'||q.dead||q.held)continue;const pt=segment(m,...ends(q)),d=dist(m,pt),reach=m.r+7;if(d>=reach)continue;const v=d>.01?unit(m.x-pt.x,m.y-pt.y):{x:-u.x,y:-u.y},over=reach-d;this.moveCircle(m,v.x*over*.8,v.y*over*.8);this.moveCircle(q,-v.x*over*.2,-v.y*over*.2);q.vx-=v.x*15*dt;q.vy-=v.y*15*dt;}
 return true;}
 life(m,dt,grip){const s=this.s,h=s.hero,toy=s.props.find(p=>p.owner===m.id&&!p.dead),ball=s.props.find(p=>p.kind==='ball'&&!p.dormant&&!p.dead);
  if(toy&&toy.held){m.focus=toy.id;m.intent='谁拿了我的彩桶？';this.speak(m,'那是我的！');if(this.visible(m,h)&&m.cool<=0&&dist(m,h)<700)this.windup(m,h);else this.mindWalk(m,h,88*grip,dt);return true;}
  const foreign=s.props.find(q=>q.owner&&q.owner!==m.id&&!q.dead&&!q.held&&dist(q,m.home)<90&&dist(m,q)<220);
  if(foreign){m.focus=foreign.id;m.intent='别人的桶放到我窝里了';this.mindWalk(m,foreign,75*grip,dt);if(dist(m,foreign)<m.r+foreign.r+14&&s.time-(m.shoveAt??-10)>1.7){const u=dist(foreign,m)>1?unit(foreign.x-m.x,foreign.y-m.y):{x:m.id==='ram'?-1:1,y:0};foreign.vx=u.x*270;foreign.vy=u.y*270;m.shoveAt=s.time;this.speak(m,'放错地方啦！');this.discover('foreign-toy','桶放到另一只的窝里，它会把桶顶出去。');}return true;}
  let p=null,isBall=false;
  if(ball&&(dist(m,ball)<650||m.curious)){p=ball;isBall=true;m.curious=false;}
  else if(toy&&(dist(toy,m.home)>65||['return','guard'].includes(m.job)))p=toy;
  if(!p){m.focus=null;m.intent='看着自己的彩桶';return false;}
  m.focus=p.id;const home=m.home,d=dist(p,home);
  if(d<55&&Math.hypot(p.vx,p.vy)<65){if(m.job==='return'&&!isBall){s.stats.returns++;this.discover('return-toy','它真把彩桶顶回窝了。你还可以再拿走。');this.speak(m,'放回来了，别再拿啦。');}m.job=isBall?'guard-ball':'guard';m.intent=isBall?'把大球留在自己的窝里':'守住找回来的彩桶';this.mindWalk(m,{x:p.x-55,y:p.y+42},45*grip,dt);return true;}
  m.job=isBall?'play':'return';m.intent=isBall?'想把大球顶回自己的窝':'把彩桶顶回窝';
  let goal=home;if(!this.visible(p,home)){const route=this.path(p,home,p.r+3);goal=route.find(t=>dist(p,t)>26)||home;}
  const u=unit(goal.x-p.x,goal.y-p.y),behind={x:p.x-u.x*(m.r+p.r+2),y:p.y-u.y*(m.r+p.r+2)};
  const rx=m.x-p.x,ry=m.y-p.y,along=rx*u.x+ry*u.y,side=rx*(-u.y)+ry*u.x;
  if(along>5){const sign=Math.abs(side)>2?Math.sign(side):m.id==='ram'?1:-1,reach=m.r+p.r+30;this.mindWalk(m,{x:p.x-u.y*reach*sign,y:p.y+u.x*reach*sign},(isBall?105:82)*grip,dt);}
  else if(dist(m,behind)>15){this.mindWalk(m,behind,(isBall?105:82)*grip,dt);}else{this.mindWalk(m,{x:p.x-u.x*(m.r+p.r-8),y:p.y-u.y*(m.r+p.r-8)},(isBall?110:78)*grip,dt);}
  const dot=(p.x-m.x)*u.x+(p.y-m.y)*u.y;
  if(dist(m,p)<m.r+p.r+10&&dot>0){this.moveCircle(p,u.x*(isBall?92:73)*grip*dt,u.y*(isBall?92:73)*grip*dt);p.vx+=u.x*110*dt;p.vy+=u.y*110*dt;
   if(isBall&&p.lastBy!==m.id){p.lastBy=m.id;s.episode.ballSwaps++;this.speak(m,m.id==='ram'?'这球归我！':'让我顶一下！');if(s.episode.ballSwaps>=2)this.discover('ball-contest','两只都看上了球。你可以插手，也可以看它们较劲。');}
  }
  for(const q of s.props){if(q===p||q.dead||q.dormant||q.held)continue;const pt=q.kind==='panel'?segment(m,...ends(q)):q,reach=m.r+(q.kind==='panel'?7:q.r),d=dist(m,pt);if(d<reach){const v=unit(q.x-m.x,q.y-m.y);this.moveCircle(q,v.x*35*dt,v.y*35*dt);q.vx+=v.x*25*dt;q.vy+=v.y*25*dt;}}
  return true;
 }
 evolve(){const s=this.s,wall=s.walls.find(w=>w.id==='shed-breach');if(wall.hp===0&&!s.episode.warehouse){s.episode.warehouse=true;const ball=s.props.find(p=>p.kind==='ball');if(ball.dormant){ball.dormant=false;ball.x=200;ball.y=238;ball.vx=0;ball.vy=330;ball.throwAt=s.time;}const nap=s.monsters.find(m=>m.id==='nap');if(nap.mode==='sleep'){nap.mode='idle';nap.cool=1;}nap.curious=true;this.speak(nap,'什么滚出来了？');this.discover('warehouse-open','仓库开了！大球滚了出来，远处那只也醒了。');this.sound('gate');}}
 windup(m,target){const u=unit(target.x-m.x,target.y-m.y);m.mode='windup';m.intent='准备冲撞';m.timer=1.35;m.dx=u.x;m.dy=u.y;m.vx=m.vy=0;m.target={x:target.x,y:target.y};this.sound('warning');}
 monster(m,dt){const s=this.s,h=s.hero;if(h.riding===m.id){this.rideStep(m,dt);return;}if(m.kind){this.sentry(m,dt);return;}m.air=m.gear==='coil'&&m.mode==='charge'?(Math.sin(s.time*13)>-.25?20:0):0;if(m.mode==='sleep'){const d=dist(m,h);if(d<m.r+h.r){const u=unit(h.x-m.x,h.y-m.y);this.moveCircle(h,u.x*(m.r+h.r-d),u.y*(m.r+h.r-d));}return;}m.timer-=dt;m.cool-=dt;const grip=this.sticky(m)?.4:this.water(m)?.55:1;
  if(m.mode==='stun'){if(m.timer<=0){m.mode='idle';m.cool=1.4;}return;}
  if(m.mode==='windup'){if(m.timer<=0){m.mode='charge';m.timer=1.4;this.sound('ram');}return;}
  if(m.mode==='charge'){
   const hit=this.moveCircle(m,m.dx*(m.gear==='coil'?520:445)*grip*dt,m.dy*(m.gear==='coil'?520:445)*grip*dt,true);this.burst(m.x-m.dx*25,m.y-m.dy*25,1,'#aa9d83');
   for(const p of s.props){if(p.dead||p.dormant||p.held)continue;const d=dist(m,p),near=p.kind==='panel'?dist(m,segment(m,...ends(p)))<m.r+8:d<m.r+p.r;if(!near)continue;if(['coil','helmet'].includes(p.kind)){this.applyKit(m,p);continue;}const power=p.kind==='ball'?620:520/p.mass;p.vx=m.dx*power;p.vy=m.dy*power;this.moveCircle(p,m.dx*12,m.dy*12);if(p.kind==='barrel'){this.ignite(p,.65);this.discover('ram-barrel','它连桶都撞：麻烦可以一起利用。');}if(p.kind==='resin')this.spill(p);}
   if(hit&&m.gear==='coil'&&m.timer>.2){m.dx=-m.dx;m.dy=-m.dy;m.timer-=.15;this.sound('spring');}else if(hit||m.timer<=0){m.mode='stun';m.timer=3;s.stats.ramHits+=hit?1:0;if(hit){s.shake=8;this.sound('hit');this.burst(m.x,m.y,20,'#ecb167');}}
  }else if(!this.life(m,dt,grip)){
   if(m.target&&dist(m,m.target)<55)m.target=null;const target=m.target||h;
   if(dist(m,h)<(m.gear==='helmet'?140:480)&&dist(m,h)>85&&this.visible(m,h)&&m.cool<=0){this.windup(m,h);return;}
   let t=target;if(!this.visible(m,target)){if(s.time-m.pathAt>.8){m.path=this.path(m,target,m.r+2);m.pathAt=s.time;}while(m.path.length&&dist(m,m.path[0])<18)m.path.shift();if(m.path.length)t=m.path[0];}
   const u=unit(t.x-m.x,t.y-m.y);m.dx=u.x;m.dy=u.y;this.moveCircle(m,u.x*56*grip*dt,u.y*56*grip*dt);m.mode='idle';
  }
  if(dist(m,h)<m.r+h.r){const u=unit(h.x-m.x,h.y-m.y);this.moveCircle(h,u.x*230*dt,u.y*230*dt);if(m.mode==='charge'&&h.stun<=0){h.vx=u.x*320;h.vy=u.y*320;h.stun=.42;this.hurt?.(18,'怪兽冲撞');s.stats.bumps++;this.sound('bump');this.tell('被顶了一下，没关系。R 可以倒回五秒。');}}
 }
 ignite(p,delay=.8){if(p.kind!=='barrel'||p.dead)return;if(p.fuse<0||p.fuse>delay){p.fuse=delay;this.sound('fuse');}}
 explode(p){const s=this.s;p.dead=true;p.held=false;if(s.hero.held===p.id)s.hero.held=null;s.stats.blasts++;s.shake=13;this.sound('blast');this.flashes.push({x:p.x,y:p.y,r:155,life:.45});this.burst(p.x,p.y,55,'#ffbd66');
  for(const q of s.props){if(q.dead||q.dormant||q.held)continue;const d=dist(p,q);if(d>178)continue;const u=unit(q.x-p.x,q.y-p.y);q.vx+=u.x*(540-d*1.3)/Math.sqrt(q.mass);q.vy+=u.y*(540-d*1.3)/Math.sqrt(q.mass);if(q.kind==='barrel'){this.ignite(q,.22);this.discover('chain','连着炸了。桶之间的距离，也是一种机关。');}}
  for(const q of s.props)if(!q.dead&&q.kind==='resin'&&dist(p,q)<178)this.spill(q,true);
  for(const q of s.patches)if(dist(p,q)<155+q.r)this.light(q);
  for(const b of s.bells)if(dist(p,b)<175)this.ring(b,'blast');
  for(const w of this.activeWalls()){const pt={x:clamp(p.x,w.x,w.x+w.w),y:clamp(p.y,w.y,w.y+w.h)};if(dist(p,pt)<155)this.damage(w,dist(p,pt)<95?3:2,'blast');}
  for(const m of s.monsters)if(dist(p,m)<190){const u=unit(m.x-p.x,m.y-p.y);this.moveCircle(m,u.x*40,u.y*40);m.mode='stun';m.timer=4;this.discover('blast-stun','爆炸把它震晕了，趁现在做点别的。');}
  const h=s.hero;if(dist(p,h)<130){const u=unit(h.x-p.x,h.y-p.y);h.vx+=u.x*260;h.vy+=u.y*260;h.stun=.28;this.hurt?.(22,'爆炸');}
 }
 tickWind(){
 const s=this.s,f=s.fan;this.beams=[];s.turbine.powered=false;if(!f.on)return;
 let x=f.x,y=f.y,dx=Math.cos(f.angle),dy=Math.sin(f.angle),power=620,last=null;
 for(let bounce=0;bounce<4&&power>20;bounce++){
  let len=power,hit=null;
  for(const w of this.activeWalls()){const d=rayRect(x,y,dx,dy,w,len);if(d!==null&&d<len){len=d;hit={type:'wall',o:w};}}
  for(const p of s.props.filter(p=>p.kind==='panel'&&!p.dead&&!p.dormant&&!p.held&&p!==last)){const d=rayPanel(x,y,dx,dy,p,len);if(d!==null&&d<len){len=d;hit={type:'panel',o:p};}}
  this.beams.push({x,y,dx,dy,len,power:1-bounce*.18});
  const pt=segment(s.turbine,{x,y},{x:x+dx*len,y:y+dy*len});if(dist(pt,s.turbine)<s.turbine.r+12)s.turbine.powered=true;
  if(hit&&hit.type==='panel'){const p=hit.o,nx=-Math.sin(p.angle),ny=Math.cos(p.angle),dot=dx*nx+dy*ny;const ex=x+dx*len,ey=y+dy*len;dx-=2*dot*nx;dy-=2*dot*ny;x=ex+dx*5;y=ey+dy*5;power=(power-len)*.8;last=p;}else break;
 }
 }
 inWind(p){for(const b of this.beams){const along=(p.x-b.x)*b.dx+(p.y-b.y)*b.dy,side=Math.abs((p.x-b.x)*b.dy-(p.y-b.y)*b.dx);if(along>0&&along<b.len&&side<40+p.r)return b;}return null;}
 propsStep(dt){const s=this.s;
  for(const p of s.props){if(p.dead||p.dormant)continue;if(p.fuse>=0){p.fuse-=dt;if(p.fuse<=0){this.explode(p);continue;}}
   if(p.held){p.x=s.hero.x+s.hero.dx*38;p.y=s.hero.y+s.hero.dy*38;continue;}
   const wind=this.inWind(p);if(wind){const force=p.kind==='panel'?6:270/Math.sqrt(p.mass);p.vx+=wind.dx*force*dt;p.vy+=wind.dy*force*dt;}
   const speed=Math.hypot(p.vx,p.vy),px=p.x,py=p.y;
   if(p.kind==='panel'){this.moveCircle(p,p.vx*dt,p.vy*dt);}else{
    p.x+=p.vx*dt;p.y+=p.vy*dt;
    for(const w of this.activeWalls()){if(p.x+p.r<=w.x||p.x-p.r>=w.x+w.w||p.y+p.r<=w.y||p.y-p.r>=w.y+w.h)continue;
     if(speed>230&&s.time-p.impact>.3){p.impact=s.time;if(p.kind==='barrel')this.ignite(p,.8);if(p.kind==='stone')this.damage(w,1,'stone');if(p.kind==='ball')this.damage(w,2,'ball');if(p.kind==='resin'){this.spill(p);break;}}
     if(w.hp===0)continue;const bx=p.x,by=p.y;this.moveCircle(p,0,0);if(Math.abs(p.x-bx)>1)p.vx*=p.kind==='ball'?-.78:-.48;if(Math.abs(p.y-by)>1)p.vy*=p.kind==='ball'?-.78:-.48;
    }
    if(p.x<30+p.r||p.x>W-30-p.r)p.vx*=-.55;if(p.y<30+p.r||p.y>H-30-p.r)p.vy*=-.55;p.x=clamp(p.x,30+p.r,W-30-p.r);p.y=clamp(p.y,30+p.r,H-30-p.r);
   }
   if(p.dead)continue;if(p.kind==='ball')p.angle+=Math.hypot(p.vx,p.vy)*dt/p.r*(p.vx>=0?1:-1);if(p.kind==='resin'&&s.time-(p.throwAt??-10)>.65&&s.time-(p.throwAt??-10)<3){this.spill(p);continue;}
   if(speed>210&&dist(p,s.hero)>50&&s.time-(p.throwAt||-10)<2.2)this.burst(px,py,1,p.kind==='barrel'?'#efaa73':'#d2d6d1');
   const drag=Math.exp(-((p.kind==='ball'?.35:wind?.55:1.85)+(this.sticky(p)?5:0))*dt);p.vx*=drag;p.vy*=drag;
   for(const m of s.monsters){if(m.mode==='charge'||dist(p,m)>p.r+m.r)continue;if(speed>210&&s.time-p.impact>.3){p.impact=s.time;m.mode='stun';m.timer=p.kind==='stone'?2.7:1.5;this.discover('prop-stun','砸中了。手里的东西也能争取时间。');if(p.kind==='barrel')this.ignite(p,.7);if(p.kind==='resin'){this.spill(p);break;}}if(['coil','helmet'].includes(p.kind)&&speed>100){this.applyKit(m,p);break;}const u=unit(p.x-m.x,p.y-m.y);this.moveCircle(p,u.x*7,u.y*7);p.vx+=u.x*25;p.vy+=u.y*25;}
  }
  const list=s.props.filter(p=>!p.dead&&!p.dormant&&!p.held);
  for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length;j++){
   const a=list[i],b=list[j];if(a.dead||b.dead)continue;let v,d,reach;
   if(a.kind==='panel'&&b.kind==='panel')continue;
   if(a.kind==='panel'||b.kind==='panel'){const panel=a.kind==='panel'?a:b,other=panel===a?b:a,pt=segment(other,...ends(panel));d=dist(other,pt);reach=other.r+7;const u=unit(other.x-pt.x,other.y-pt.y);v=panel===a?u:{x:-u.x,y:-u.y};}else{d=dist(a,b);reach=a.r+b.r;v=unit(b.x-a.x,b.y-a.y);}
   if(d>=reach)continue;const inva=1/a.mass,invb=1/b.mass,sum=inva+invb,over=reach-d;this.moveCircle(a,-v.x*over*inva/sum,-v.y*over*inva/sum);this.moveCircle(b,v.x*over*invb/sum,v.y*over*invb/sum);
   const closing=(a.vx-b.vx)*v.x+(a.vy-b.vy)*v.y;if(closing>0){const impulse=closing*1.48/sum;a.vx-=impulse*v.x*inva;a.vy-=impulse*v.y*inva;b.vx+=impulse*v.x*invb;b.vy+=impulse*v.y*invb;if(closing>200){this.ignite(a,.85);this.ignite(b,.85);if(a.kind==='resin')this.spill(a);if(b.kind==='resin')this.spill(b);this.sound('clink');}}
  }
 }
 heroProps(dt){const s=this.s,h=s.hero;for(const p of s.props){if(p.dead||p.dormant||p.held)continue;let pt=p,reach=h.r+p.r;if(p.kind==='panel'){pt=segment(h,...ends(p));reach=h.r+7;}const d=dist(h,pt);if(d>=reach)continue;const u=unit(h.x-pt.x,h.y-pt.y),o=reach-d;this.moveCircle(h,u.x*o*.4,u.y*o*.4);this.moveCircle(p,-u.x*o*.6,-u.y*o*.6);p.vx-=u.x*75*dt/p.mass;p.vy-=u.y*75*dt/p.mass;}}
 update(dt,input={}){dt=clamp(dt,0,.025);const s=this.s;if(s.paused)return;s.time+=dt;s.shake*=Math.exp(-dt*10);const h=s.hero;
  let dx=input.x||0,dy=input.y||0;if(dx||dy){const u=unit(dx,dy);dx=u.x;dy=u.y;if(!input.aim){h.dx=dx;h.dy=dy;}}
  if(input.aim){const u=unit(input.aim.x-h.x,input.aim.y-h.y);h.dx=u.x;h.dy=u.y;}
  h.stun=Math.max(0,h.stun-dt);h.launch=Math.max(0,(h.launch||0)-dt);const speed=(h.held?155:195)*(this.speedFactor?this.speedFactor(h):1)*(this.sticky(h)?.6:this.water(h)?.75:1),scale=h.stun>0?.35:1;this.rideInput={x:dx,y:dy,aim:input.aim};if(!h.riding)this.moveCircle(h,(dx*speed*scale+h.vx)*dt,(dy*speed*scale+h.vy)*dt);h.vx*=Math.exp(-(h.launch>0?1.5:(this.onIce?.(h)&&!s.realm?.grip?.active) ? 0.45 : 6)*dt);h.vy*=Math.exp(-(h.launch>0?1.5:(this.onIce?.(h)&&!s.realm?.grip?.active) ? 0.45 : 6)*dt);
  this.tickWind();const wind=this.inWind(h);if(wind&&!h.held&&!h.riding)this.moveCircle(h,wind.dx*28*dt,wind.dy*28*dt);
  for(const m of s.monsters)this.monster(m,dt);
  this.propsStep(dt);if(!h.riding)this.heroProps(dt);this.springs();this.surroundings(dt);this.evolve();this.adventure(dt);if(h.riding){const m=s.monsters.find(m=>m.id===h.riding);h.x=m.x;h.y=m.y;h.vx=h.vy=0;}
  const t=s.turbine;if(t.powered){t.charge=Math.min(4,t.charge+dt);if(this.beams.length>1)this.discover('reflect','风真的转弯了：隔板可以改变风路。');}else t.charge=Math.max(0,t.charge-dt*.3);
  if(t.charge>=4&&!t.open){t.open=true;this.discover('wind-open','风轮转够了，南门已经锁定开启。');this.sound('gate');}
  for(const p of this.particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.exp(-3*dt);p.vy*=Math.exp(-3*dt);p.life-=dt;}this.particles=this.particles.filter(p=>p.life>0);for(const f of this.flashes)f.life-=dt;this.flashes=this.flashes.filter(f=>f.life>0);
  if(s.time-this.snapAt>=.2){this.history.push(clone(s));if(this.history.length>100)this.history.shift();this.snapAt=s.time;}
 }
 rewind(){if(!this.history.length){this.tell('还没有可以倒回的片段。');return false;}const goal=this.s.time-5;let i=this.history.length-1;while(i>0&&this.history[i].time>goal)i--;this.s=clone(this.history[i]);this.history=this.history.slice(0,i);this.snapAt=this.s.time;this.s.paused=false;this.particles=[];this.flashes=[];this.tickWind();this.tell('倒回来了。换个办法试试。');return true;}
 save(){return JSON.stringify(this.s);}
 load(text){try{const s=JSON.parse(text);if(![1,2,3,4].includes(s.version)||!Number.isFinite(s.time)||!s.hero||!Array.isArray(s.props)||s.props.length<10||s.props.length>24||!Array.isArray(s.walls)||!s.fan||!s.turbine||!s.monsters?.length)return false;
 const defaults=make(s.seed);if(s.version===1){for(const p of defaults.props)if(!s.props.some(q=>p.id===q.id))s.props.push(p);for(const w of defaults.walls)if(!s.walls.some(q=>w.id===q.id))s.walls.push(w);s.monsters.push(defaults.monsters[1]);s.pads=defaults.pads;s.bells=defaults.bells;s.cabinet=defaults.cabinet;s.patches=[];s.stats={...defaults.stats,...s.stats};s.version=2;}
 if(s.version===2){for(const p of defaults.props)if(!s.props.some(q=>p.id===q.id))s.props.push(p);for(const w of defaults.walls){const old=s.walls.find(q=>q.id===w.id);if(!old)s.walls.push(w);else if(w.id.startsWith('shed-')){old.x=w.x;old.y=w.y;old.w=w.w;old.h=w.h;}}for(const m of s.monsters){const old=defaults.monsters.find(q=>q.id===m.id);if(old){m.home=old.home;m.intent=old.intent;}}s.stats={...defaults.stats,...s.stats};s.episode=defaults.episode;s.version=3;}
 if(s.version===3){for(const p of defaults.props)if(!s.props.some(q=>p.id===q.id))s.props.push(p);for(const w of defaults.walls)if(!s.walls.some(q=>w.id===q.id))s.walls.push(w);for(const m of defaults.monsters)if(!s.monsters.some(q=>m.id===q.id))s.monsters.push(m);s.flood=defaults.flood;s.shots=[];s.beacon=defaults.beacon;s.adventureWon=false;s.hero.riding=null;s.version=4;}
 if(!Array.isArray(s.pads)||s.pads.length!==2||!Array.isArray(s.bells)||s.bells.length!==3||!Array.isArray(s.patches)||s.patches.length>30||!s.cabinet||!s.stats||!s.episode||!s.props.some(p=>p.id==='big-ball')||!Array.isArray(s.logs)||!Array.isArray(s.discoveries))return false;
 for(const p of s.props)if(!p.home)p.home=defaults.props.find(q=>q.id===p.id)?.home||{x:p.x,y:p.y,angle:p.angle};
 if(!s.flood||!Number.isFinite(s.flood.level)||!Array.isArray(s.shots)||s.shots.length>18||!s.beacon||s.hero.riding&&!s.monsters.some(m=>m.id===s.hero.riding&&!m.kind))return false;
 const coords=[s.hero,s.fan,s.turbine,s.cabinet,s.beacon,...s.props,...s.monsters,...s.pads,...s.bells,...s.patches,...s.shots];if(!coords.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)))return false;this.s=s;this.s.paused=false;this.history=[];this.snapAt=s.time;this.particles=[];this.flashes=[];this.tickWind();return true;}catch{return false;}}
}
root.Bump={Game,W,H,dist,unit,ends,segment,clamp};
})(typeof module!=='undefined'?module.exports:window);
