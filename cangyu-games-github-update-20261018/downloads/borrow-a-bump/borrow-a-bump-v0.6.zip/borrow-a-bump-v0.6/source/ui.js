(()=>{'use strict';
const $=id=>document.getElementById(id),game=new Bump.Game(),view=new Bump.Renderer($('game'),game),keys=new Set(),SAVE='cangyu-borrow-a-bump-06';
let aim=null,touch={x:0,y:0},last=0,saveAt=0,uiAt=0,modalAction=null,audioCtx=null,muted=true,saveAvailable=true;
const intro=$('modal-body').innerHTML;game.enterLevel('crossroads');
try{const saved=localStorage.getItem(SAVE)||localStorage.getItem('cangyu-borrow-a-bump-05');if(saved)game.load(saved);$('audio').checked=localStorage.getItem(SAVE+'-audio')==='1';$('reduce').checked=localStorage.getItem(SAVE+'-reduce')==='1';}catch{saveAvailable=false;}
muted=!$('audio').checked;view.reduced=$('reduce').checked;
function save(){try{localStorage.setItem(SAVE,game.save());$('save-state').textContent='进度已保存在本机';saveAvailable=true;}catch{saveAvailable=false;$('save-state').textContent='浏览器未允许存档，本次仍可玩';}}
function sound(type){if(muted)return;try{if(!audioCtx)audioCtx=new(window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const tones={click:[350,.035],pick:[540,.06],throw:[220,.08],whistle:[990,.18],warning:[115,.13],ram:[90,.1],hit:[72,.15],clink:[470,.03],fuse:[570,.025],blast:[45,.3],bump:[130,.1],gate:[740,.24],spring:[400,.16],bell:[1200,.35],spill:[160,.13],win:[880,.4]};const[f,d]=tones[type]||[320,.06],o=audioCtx.createOscillator(),g=audioCtx.createGain(),t=audioCtx.currentTime;o.type=type==='blast'||type==='hit'?'triangle':'sine';o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(type==='win'?1320:Math.max(30,f*.5),t+d);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(.07,t+.008);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(audioCtx.destination);o.start(t);o.stop(t+d+.02);}catch{muted=true;$('audio').checked=false;}}
game.sound=sound;
function clear(){keys.clear();touch={x:0,y:0};aim=null;}
function show(title,body,button='继续玩',action=null,extra=false){clear();game.s.paused=true;$('modal-title').textContent=title;$('modal-body').innerHTML=body;$('modal-main').textContent=button;$('modal-extra').hidden=!extra;$('modal-rewind').hidden=true;$('overlay').hidden=false;modalAction=action;$('modal-main').focus();}
function close(){if(modalAction){const f=modalAction;modalAction=null;f();}clear();$('overlay').hidden=true;game.s.paused=false;last=0;$('game').focus();}
$('modal-main').onclick=close;
function restart(remix=false){const seed=remix?Math.floor(Math.random()*1000000)+2:game.s.seed;game.reset(seed);save();refresh();}
$('modal-extra').onclick=()=>{modalAction=null;restart(true);close();};
game.onWin=stats=>{save();const descriptions={ram:'你借它的力打开了墙。',blast:'爆炸替你打开了入口。',stone:'石头在你手里成了拆墙工具。',wind:'你让风轮打开了南门。',ball:'大圆球替你打开了入口。'};show('开罐成功。',`<p>${descriptions[stats.method]||'你的办法奏效了。'}</p><p>这一局发生了 ${stats.blasts} 次爆炸，撞撞撞停了 ${stats.ramHits} 次。</p><div class="hint">开门目标完成了。彩桶、仓库里的大球和怪兽自己的事情都还在，继续插手捣乱也可以。</div>`,'继续折腾',null,true);};
game.onAdventureWin=()=>{const s=game.s;if(!s.journal.completed.includes(s.levelId))s.journal.completed.push(s.levelId);save();const names={crossroads:'它们又追错人了。',night:'钟声穿过了雾。',alchemy:'丹成，仙门开。',frost:'抵达暖亭了。',lab:'闯到观景台了。'};show(names[s.levelId]||'这次借上力了。','<p>场景和分身都还在，可以继续试别的组合。</p><div class="hint">右侧可以选择其他地图：回音院子、雾灯旧院、借火丹谷、霜风渡口和旧院子。</div>','继续探索');};
$('modal-rewind').onclick=()=>{game.s.paused=false;if(game.rewind()&&!game.s.fallen){modalAction=null;close();save();refresh();}else{game.s.paused=true;$('modal-body').innerHTML='<p>还没有能救回来的片段，先回营火恢复。</p>';}};

function help(){if(!$('overlay').hidden)return;show('先试一下，再想办法。',intro,'回到院子');}
$('help').onclick=help;
$('pause').onclick=()=>{if(!$('overlay').hidden){if($('modal-title').textContent==='歇一会儿。')close();return;}save();show('歇一会儿。','<p>院子暂停了，回来接着玩。</p>','继续玩');};
$('new-yard').onclick=()=>{if(!$('overlay').hidden)return;show('重新开一局？','<p>当前院子会重置。可以保留原来的物品布置，也可以换个布置，重新尝试。</p>','按当前布置重来',()=>restart(false),true);};
$('rewind').onclick=()=>{if(!$('overlay').hidden)return;clear();game.rewind();save();refresh();};
function overview(){view.overview=!view.overview;$('overview').textContent=view.overview?'跟随视角':'全场视角';}
$('overview').onclick=overview;
$('audio').onchange=()=>{muted=!$('audio').checked;try{localStorage.setItem(SAVE+'-audio',muted?'0':'1');}catch{}if(!muted)sound('click');};
$('reduce').onchange=()=>{view.reduced=$('reduce').checked;try{localStorage.setItem(SAVE+'-reduce',view.reduced?'1':'0');}catch{}};
function action(a){if(!$('overlay').hidden)return;if(a==='act')game.act();if(a==='throw')game.throwOrCall();if(a==='rotate')game.rotate();if(a==='ride')game.mount();if(a==='record')game.recordEcho();if(a==='skill')game.skill();refresh();}
window.addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;const k=e.key.toLowerCase(),moves=['w','a','s','d','arrowup','arrowleft','arrowdown','arrowright'];if(['INPUT','SELECT','TEXTAREA'].includes(e.target?.tagName))return;if(k==='escape'){e.preventDefault();if(game.s.fallen)return;if($('overlay').hidden){save();show('歇一会儿。','<p>院子暂停了，回来接着玩。</p>');}else if($('modal-title').textContent!=='麻烦，也能帮忙。'){modalAction=null;close();}return;}if(!$('overlay').hidden)return;
 if(moves.includes(k)){e.preventDefault();keys.add(k);aim=null;return;}if([' ','e','q','r','f','c','x','tab'].includes(k))e.preventDefault();if(e.repeat)return;
 if(k==='x')game.skill();if(k==='c')game.recordEcho();if(k==='e')game.act();if(k==='f')game.mount();if(k===' ')game.throwOrCall();if(k==='q')game.rotate(e.shiftKey?-1:1);if(k==='r'){clear();game.rewind();save();}if(k==='tab')overview();refresh();});
window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
function lostFocus(){clear();if($('overlay').hidden){save();show('歇一会儿。','<p>切换窗口时已自动暂停。</p>');}}
window.addEventListener('blur',lostFocus);document.addEventListener('visibilitychange',()=>{if(document.hidden)lostFocus();});window.addEventListener('pagehide',save);
$('game').addEventListener('pointermove',e=>{if(e.pointerType==='touch'||!$('overlay').hidden)return;const r=$('game').getBoundingClientRect();aim=view.world((e.clientX-r.left)*1000/r.width,(e.clientY-r.top)*680/r.height);});
$('game').addEventListener('pointerleave',()=>{aim=null;});
$('game').addEventListener('pointerdown',()=>{$('game').focus();});
document.querySelectorAll('[data-dir]').forEach(b=>{b.addEventListener('pointerdown',e=>{e.preventDefault();if(!$('overlay').hidden)return;const[x,y]=b.dataset.dir.split(',').map(Number);touch={x,y};aim=null;b.setPointerCapture(e.pointerId);});for(const event of['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,()=>{touch={x:0,y:0};});});
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('pointerdown',e=>{e.preventDefault();action(b.dataset.action);}));

$('record-echo').onclick=()=>action('record');
$('level-switch').onclick=()=>{if(!$('overlay').hidden)return;const id=$('map-select').value||'night',map=Bump.MAPS.find(m=>m.id===id);if(!map)return;show('前往'+map.name+'？','<p>'+map.tip+'</p><p>进入后从该地图起点开始，当前场景和分身会清空；已完成地图的记录保留。</p>','进入地图',()=>{game.enterLevel(id);save();refresh();});};
let shownLevel=null;
function refreshThemeHelp(){const r=game.s.realm,kind=r?.kind;const names=kind==='night'?['听声影兽','钟楼影兽','投石守望者','苔影守望者']:kind==='alchemy'?['西谷山灵','东谷山灵','投石傀儡','青苔灵']:kind==='frost'?['西侧雪角兽','东侧雪角兽','冰石投手','寒地黏液怪']:['撞撞','瞌睡鬼','投石手','黏液怪'];['ram','nap','slinger','spitter'].forEach((id,i)=>$('name-'+id).textContent=names[i]);
const tips=kind==='night'?[['可搬提灯','E 拿放，空格投掷。重新布置亮处。'],['灯塔','空手靠近 E 点亮，任意两座打开帘门。'],['分身的声音','关掉自己的灯，让过去的你在另一边喊。'],['X 提灯','亮处影兽避让，远处守望者更容易发现你。']]:kind==='alchemy'?[['借力丹炉','任意两种力会留在丹炉，不用同时触发。'],['风与飞石','改风、转隔板，或把灵石投向丹炉。'],['炎与雷','借爆炸、燃烧或怪兽冲撞炼丹。'],['X 御气','收丹后推物、短暂镇兽与护身。']]:kind==='frost'?[['X 防滑靴','慢而稳 / 滑行，自由切换。'],['滚大的雪球','冰上滚动会长大，E 推球或借怪兽撞。'],['E 点火','火盆让附近冰面好走，逐渐融开冰墙。'],['骑乘与弹簧','也可以借冲撞、弹射开另一条路。']]:[['弹簧 / 桶盔','拿着靠近撞撞，再按 E 装上；扔中也行。'],['风与隔板','改变方向，让风做你想做的事。'],['分身与骑乘','过去的你招惹一只，现在的你骑另一只。'],['血包与营火','血包自动 +35；营火旁 E 补满并记录位置。']];
$('force-list').innerHTML=tips.map(([title,tip])=>'<div class="object"><span class="object-mark">◇</span><div><strong>'+title+'</strong><small>'+tip+'</small></div></div>').join('');}
function refreshSurvival(){const s=game.s,h=s.hero,r=s.realm,map=Bump.MAPS.find(m=>m.id===s.levelId);$('hp-value').textContent=`生命 ${Math.ceil(h.hp)} / 100`;$('hp-fill').style.width=h.hp+'%';$('hp-fill').setAttribute?.('aria-valuenow',Math.ceil(h.hp));$('hp-fill').style.background=h.hp<=30?'#c77874':'#72b394';$('map-skill').textContent=r?.kind==='night'?(r.lantern?'X 提灯：亮':'X 提灯：暗'):r?.kind==='frost'?(r.grip.active?'X 防滑靴：开':'X 防滑靴：关'):r?.kind==='alchemy'?(r.brew?'X 御气 · '+r.potion:'丹炉借力 '+r.energy.length+' / 2'):'血包 +35 · 营火 E 疗伤';
 if(shownLevel!==s.levelId){shownLevel=s.levelId;$('map-select').value=s.levelId;$('stage-name').textContent=(map?.theme||'自由实验')+' / '+(map?.name||'院子');document.body?.setAttribute?.('data-theme',s.levelId);refreshThemeHelp();}
 if(s.fallen&&$('overlay').hidden){save();show('先在营火缓一缓。','<p>这次倒下了。可以倒回五秒，或在营火恢复全部生命。</p><div class="hint">恢复后已拆的墙、机关、血包使用情况与分身都会保留。</div>','在营火恢复',()=>game.recover());$('modal-rewind').hidden=false;}
}

let echoSignature='';
function refreshEchoes(){const s=game.s;$('record-echo').textContent=s.recording?'● C 完成录制':'C 开始录制';$('record-state').textContent=s.recording?'录制中 '+Math.floor(s.time-s.recording.start)+' 秒 · 随时 C 完成':`${(s.echoes||[]).length} / 2 位分身 · 空手下地后开始录`;
 const sig=JSON.stringify((s.echoes||[]).map(e=>[e.id,e.paused,e.ended,e.repeat]));if(sig===echoSignature)return;echoSignature=sig;
 const rows=(s.echoes||[]).map(e=>{const row=document.createElement('div');row.style.cssText='padding:10px 0;border-top:1px solid #d9dfce';const label=document.createElement('p');label.textContent=`分身 ${e.id.split('-')[1]} · ${e.paused?'暂停':e.ended?'留在终点':'重演中'}`;row.appendChild(label);for(const [a,t]of[['pause',e.paused?'继续':'暂停'],['restart','重演'],['repeat',e.repeat?'终点喊声：开':'终点喊声：关'],['delete','删除']]){const b=document.createElement('button');b.textContent=t;b.style.cssText='padding:4px 6px;font-size:11px;margin:2px';b.onclick=()=>{if(!$('overlay').hidden)return;game.echoControl(e.id,a);save();refresh();};row.appendChild(b);}return row;});$('echo-list').replaceChildren(...rows);
}

function refresh(){const s=game.s;refreshEchoes();refreshSurvival();$('objective').textContent=s.levelId==='crossroads'?(s.adventureWon?'回音庭到了！换一种组合，再闹点事。':s.recording?'录制中 · C 完成，然后你就能分头行动':'到右侧回音庭敲铃 · 分身替你招惹怪兽'):s.adventureWon?'观景台到了！还可以继续在院子里闯祸。':s.hero.riding?'方向带路 · 空格冲撞 · F 下来':s.flood.open?'水流出来了，试着闯到右下观景台。':'借怪兽的力，闯到右下观景台。';const intents={sleep:s.realm?.kind==='night'?'守在阴影里':s.realm?.kind==='alchemy'?'山灵正在休息':s.realm?.kind==='frost'?'在雪里打盹':'正抱着宝贝做梦',stun:'撞懵了，缓一缓',windup:'锁定方向，准备冲撞',charge:'正在冲撞！'};for(const m of s.monsters)$('mind-'+m.id).textContent=(m.kind&&!['stun'].includes(m.mode)?m.intent:intents[m.mode])||m.intent||'四处看看';$('episode').textContent=s.levelId==='crossroads'?'西墙可拆，北门借风，南边矮栏可骑弹簧撞撞越过。':s.flood.open?'蓄水池已放水：漂流、冲洗和新攻击都加入了。':s.episode.warehouse?'仓库打开了。右上还有一座蓄水池。':'左上有仓库，右上有蓄水池。';if(s.realm){const r=s.realm;$('objective').textContent=s.adventureWon?'目标达成 · 换一种组合继续探索':r.kind==='night'?'点亮两座灯塔，或拆开帘门 · 去钟楼敲钟':r.kind==='alchemy'?(r.brew?'丹成了 · 去东面叩仙门':'丹炉借入两种不同的力 · E 收丹'): '去东面暖亭 · 可点火融冰，也可借力拆墙';$('episode').textContent=(r.kind==='alchemy'?'已借力：'+(r.energy.map(e=>({wind:'风',stone:'岩',fire:'炎',ram:'雷'})[e]).join('、')||'暂无')+'。':r.kind==='night'?'灯塔 '+r.nodes.filter(n=>n.lit).length+' / 2。':'')+Bump.MAPS.find(m=>m.id===s.levelId).tip;}
 $('status').textContent=s.fallen?'在营火恢复后继续':s.adventureWon?'目标已完成':'自由探索 · 无倒计时';$('bells').textContent=s.bells.map(b=>b.rung?'●':'○').join(' ');$('notice').textContent=s.notice;$('notice').style.opacity=s.time<s.noticeUntil?'1':'0';const items=s.logs.map(t=>{const li=document.createElement('li');li.textContent=t;return li;});$('observations').replaceChildren(...items);if(!saveAvailable)$('save-state').textContent='浏览器未允许存档，本次仍可玩';}
function frame(t){let elapsed=last?Math.min((t-last)/1000,.08):0;last=t;const input={x:touch.x+(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0),y:touch.y+(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0),aim};while(elapsed>0){const dt=Math.min(.02,elapsed);game.update(dt,input);elapsed-=dt;}view.draw();if(t-uiAt>100){view.minimap($('minimap'));refresh();uiAt=t;}if(t-saveAt>4000&&!game.s.paused){save();saveAt=t;}requestAnimationFrame(frame);}
show(game.s.time>1?'接着探索？':'借你一撞 · 诸境借力。',game.s.time>1?'<p>上次的地图和分身已经留好了。进去接着试，也可以在右侧重新开局。</p>'+intro:intro,game.s.time>1?'继续上次':'进去试试');
view.draw();view.minimap($('minimap'));refresh();requestAnimationFrame(frame);
window.__bump={game,view,refresh,close,save};
})();
