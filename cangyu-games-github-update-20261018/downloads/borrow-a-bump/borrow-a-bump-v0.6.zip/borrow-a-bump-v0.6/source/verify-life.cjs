const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),{createCanvas}=require('@napi-rs/canvas'),{Bump}=require('./engine.js');let g=new Bump.Game();const checks=[];
function run(sec,input={}){for(let t=0;t<sec;t+=.02)g.update(Math.min(.02,sec-t),input);}
function aim(o){g.update(.02,{aim:o});}
function walk(x,y,stop=7){const to={x,y};for(let i=0;i<2500;i++){const h=g.s.hero;if(Bump.dist(h,to)<stop)return;let target=to;if(!g.visible(h,to)){const route=g.path(h,to,18);assert.ok(route.length,'reachable path');target=route.find(p=>Bump.dist(h,p)>12)||to;}g.update(.02,{x:Math.abs(target.x-h.x)>2?Math.sign(target.x-h.x):0,y:Math.abs(target.y-h.y)>2?Math.sign(target.y-h.y):0});}throw Error('walk stuck: '+JSON.stringify({to,h:g.s.hero}));}
function p(id){return g.s.props.find(p=>p.id===id);}
function pick(id){const o=p(id);walk(o.x,o.y,35);aim(o);g.act();assert.equal(g.s.hero.held,id);}

// A real theft and return, through player movement and E; NPC movement is not injected.
walk(185,842);walk(620,842);walk(620,510);pick('toy-ram');assert.ok(g.s.episode.stolen);walk(640,320);aim({x:760,y:320});g.act();const initial=Bump.dist(p('toy-ram'),g.s.monsters[0].home);assert.ok(initial>180);run(23);const after=Bump.dist(p('toy-ram'),g.s.monsters[0].home);assert.ok(after<65,'monster physically returns its toy, distance '+after);assert.ok(g.s.stats.returns>0);checks.push('normal movement, theft and drop make owner find and physically return the toy');

// Demolish the warehouse by actually collecting and throwing a stone twice.
g=new Bump.Game();pick('stone-a');walk(200,375);aim({x:200,y:200});g.throwOrCall();run(.5);assert.ok(g.s.walls.find(w=>w.id==='shed-breach').hp<=1);pick('stone-a');walk(200,375);aim({x:200,y:200});g.throwOrCall();run(5);assert.ok(g.s.episode.warehouse);assert.equal(p('big-ball').dormant,false);assert.ok(p('big-ball').y>300,'ball physically rolls out through broken door');assert.notEqual(g.s.monsters[1].mode,'sleep');checks.push('two actual rock throws break warehouse, release rolling ball and wake the second monster');

// Player can push the ball with E, without being able to pick it up.
walk(p('big-ball').x,p('big-ball').y,40);aim(p('big-ball'));g.act();assert.equal(g.s.hero.held,null);assert.ok(Math.hypot(p('big-ball').vx,p('big-ball').vy)>300);run(45);assert.ok(g.s.episode.ballSwaps>=2,'both monsters really contact and claim the ball');assert.ok(g.s.discoveries.includes('ball-contest'));checks.push('player kick and autonomous pursuit produce physical ball claims by both monsters');

// Evolving world and NPC intentions survive save/resume; rewinding closes the warehouse again.
const save=g.save(),loaded=new Bump.Game();assert.ok(loaded.load(save));assert.equal(loaded.save(),save);assert.ok(loaded.s.episode.warehouse);assert.ok(loaded.s.episode.ballSwaps>=2);checks.push('save/resume retains open warehouse, moving ball, owners and intentions');
// A foreign toy dropped into the other nest is expelled, rather than treated as another pickup.
g=new Bump.Game();g.s.hero.x=100;g.s.hero.y=800;const blue=g.s.monsters[1],redToy=p('toy-ram');blue.mode='idle';blue.x=1120;blue.y=230;redToy.x=1090;redToy.y=230;g.s.monsters[0].mode='sleep';run(1);assert.ok(g.s.discoveries.includes('foreign-toy'));assert.ok(Bump.dist(redToy,blue.home)>75);checks.push('other monster pushes an intruding toy out of its nest');
g=new Bump.Game();run(6);g.damage(g.s.walls.find(w=>w.id==='shed-breach'),2,'stone');run(.5);assert.ok(g.s.episode.warehouse);g.rewind();assert.equal(g.s.episode.warehouse,false);assert.equal(p('big-ball').dormant,true);assert.equal(g.s.monsters[1].mode,'sleep');checks.push('whole-state rewind reverses warehouse release and the second monster waking');

// Scene 0.2 migration keeps player progress while adding new behaviour and dormant ball.
g=new Bump.Game();assert.ok(g.load(fs.readFileSync(__dirname+'/v02-save-fixture.json','utf8')));assert.equal(g.s.version,4);assert.equal(g.s.time,27);assert.equal(g.s.hero.x,750);assert.equal(g.s.props.length,21);assert.ok(g.s.monsters[0].home);assert.ok(g.s.episode);checks.push('0.2 save upgrades into 0.3 without resetting existing progress');

// Long-running lifecycle and destruction remain bounded and finite across varied inputs.
for(const seed of[1,20,193]){g=new Bump.Game(seed);g.damage(g.s.walls.find(w=>w.id==='shed-breach'),2,'stone');for(let i=0;i<9000;i++){if(i%190===0)g.throwOrCall();if(i%270===0)g.act();if(i%350===0)g.rotate();if(i%2000===0)g.restock();g.update(.02,{x:Math.sin(i/37)>0?1:-1,y:Math.cos(i/53)>0?1:-1});}for(const o of[g.s.hero,...g.s.props,...g.s.monsters])assert.ok(Number.isFinite(o.x)&&Number.isFinite(o.y)&&o.x>=0&&o.x<=Bump.W&&o.y>=0&&o.y<=Bump.H);assert.ok(g.s.patches.length<=30);assert.ok(g.history.length<=100);}checks.push('three open-warehouse layouts survive nine minutes of simulated interaction');

// Real Canvas render of the living scene.
const context={window:{Bump},console};vm.createContext(context);vm.runInContext(fs.readFileSync(__dirname+'/renderer.js','utf8'),context);g=new Bump.Game();g.damage(g.s.walls.find(w=>w.id==='shed-breach'),2,'stone');run(15);const canvas=createCanvas(1000,680),r=new Bump.Renderer(canvas,g);r.overview=true;r.draw();fs.writeFileSync(__dirname+'/qa-life.png',canvas.toBuffer('image/png'));
const path=__dirname+'/validation.json',v=fs.existsSync(path)?JSON.parse(fs.readFileSync(path,'utf8')):{};v.lifeChecks=checks;fs.writeFileSync(path,JSON.stringify(v,null,2));console.log('PASS: '+checks.join('; '));
