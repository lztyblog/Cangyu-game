from pathlib import Path
p=Path(__file__).parent
html=(p/'index.template.html').read_text()
for name in ('engine.js','chapter.js','realms.js','renderer.js','realm-renderer.js','ui.js'):
    code=(p/name).read_text()
    assert '</script' not in code.lower()
    html=html.replace(f'<script src="{name}"></script>',f'<script>\n{code}\n</script>')
(p/'index.html').write_text(html)
print(f'Built offline index.html: {len(html.encode()):,} bytes')
