const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),{createCanvas}=require('@napi-rs/canvas');
const {Bump}=require('./engine.js');let g=new Bump.Game();
const report=[];
function run(sec,input={}){for(let t=0;t<sec;t+=.02)g.update(Math.min(.02,sec-t),input);}
function walk(x,y,stop=7){const goal={x,y};let attempts=0;while(Bump.dist(g.s.hero,goal)>stop&&attempts++<2000){const h=g.s.hero;let target=goal;if(!g.visible(h,goal)){const p=g.path(h,goal,18);assert.ok(p.length,'reachable '+JSON.stringify(goal));target=p.find(t=>Bump.dist(h,t)>10)||goal;}const dx=target.x-h.x,dy=target.y-h.y;g.update(.02,{x:Math.abs(dx)>2?Math.sign(dx):0,y:Math.abs(dy)>2?Math.sign(dy):0});}assert.ok(attempts<2000,'stuck walking '+JSON.stringify(goal)+' at '+JSON.stringify(g.s.hero));}
function aim(x,y){g.update(.02,{aim:{x,y}});}
function prop(id){return g.s.props.find(p=>p.id===id);}
function wall(id){return g.s.walls.find(w=>w.id===id);}
function pick(id){const p=prop(id);walk(p.x,p.y,38);aim(p.x,p.y);g.act();assert.equal(g.s.hero.held,id,'picked '+id);}
function winVia(x,y){walk(x,y,7);walk(1000,468,30);g.act();assert.ok(g.s.won,'pressed physical goal button');}

// Complete the power route using movement and the same rotation/interaction commands as the UI.
walk(185,842);walk(1032,850);g.rotate();g.rotate();run(4.4);assert.ok(g.s.turbine.open,'aimed wind really unlocks the gate');winVia(1032,525);report.push({route:'wind',complete:true,method:g.s.stats.method,time:g.s.time});

// Independent demolition route. Retrieve and throw the same physical rock three times.
g=new Bump.Game();walk(185,842);walk(1270,842);walk(1270,290);pick('stone-c');
for(let i=0;i<3;i++){walk(1207,460,6);aim(1050,460);g.throwOrCall();run(.7);assert.ok(wall('east-breach').hp<=2-i,'rock impact '+(i+1));if(i<2)pick('stone-c');}
assert.equal(wall('east-breach').hp,0);winVia(1090,460);assert.equal(g.s.stats.method,'stone');report.push({route:'stone',complete:true,throws:g.s.stats.throws});

// Borrow a live monster's charge: physically move the barrel out of its path, call and sidestep.
g=new Bump.Game();walk(185,842);walk(800,760);pick('barrel-c');walk(810,650);aim(810,740);g.act();walk(805,470);
for(let i=0;i<1200;i++){const m=g.s.monsters[0];if(Bump.dist(m,g.s.hero)<560&&m.mode==='idle')break;run(.02);}
assert.equal(wall('west-breach').hp,3,'wall intact before lure');g.throwOrCall();run(.9,{y:1});run(2.6);assert.ok(g.s.discoveries.includes('breach-ram'),'live monster, normal navigation and call break wall');winVia(920,460);report.push({route:'borrowed monster charge',complete:true,method:g.s.stats.method});

// Live barrel physics, delayed impact fuse and propagated explosions open another entrance.
g=new Bump.Game();walk(185,842);walk(800,760);pick('barrel-c');walk(810,460,8);aim(950,460);g.throwOrCall();run(3);assert.ok(g.s.stats.blasts>=2,'chain ignition');assert.equal(wall('west-breach').hp,0,'chain breaks western wall');winVia(920,460);report.push({route:'barrel chain',complete:true,blasts:g.s.stats.blasts});

// Isolated mechanic fixtures below are deliberately distinct from the real completion witnesses.
g=new Bump.Game();g.s.hero.x=790;g.s.hero.y=460;const m=g.s.monsters[0];m.x=400;m.y=460;m.mode='idle';for(const p of g.s.props)if(p.kind==='barrel')p.y=140;g.throwOrCall();assert.equal(m.mode,'windup');run(.9,{y:1});run(2);assert.equal(wall('west-breach').hp,0,'real charge damages breakable wall');assert.ok(g.s.discoveries.includes('breach-ram'));report.push({mechanic:'telegraphed ram breaks wall',passed:true});
// Reflection: fan at bottom points left; a diagonal board turns its ray upward into the windwheel.
g=new Bump.Game();const p=prop('panel-a');p.x=800;p.y=794;p.angle=Math.PI/4;g.s.turbine.x=800;g.s.turbine.y=630;g.tickWind();assert.ok(g.beams.length>=2);assert.ok(g.s.turbine.powered);run(4.2);assert.ok(g.s.turbine.open);assert.ok(g.s.discoveries.includes('reflect'));report.push({mechanic:'board reflects wind and unlocks gate',passed:true});
// Prop motion inside wind, fuse recovery and rewind restore the whole world, including the gate.
g=new Bump.Game();g.s.hero.x=1100;g.s.hero.y=840;g.s.monsters[0].mode='stun';g.s.monsters[0].timer=100;const stone=prop('stone-b');stone.x=900;stone.y=794;const before=stone.x;run(1.4);assert.ok(stone.x<before-20,'wind pushes stone');run(5);const beforeBlast=g.s.stats.blasts;g.ignite(prop('barrel-a'),.1);run(.7);assert.ok(g.s.stats.blasts>beforeBlast);g.rewind();assert.equal(g.s.stats.blasts,beforeBlast,'rewind restores exploded objects and counters');assert.ok(!prop('barrel-a').dead);
const saved=g.save(),loaded=new Bump.Game();assert.ok(loaded.load(saved));assert.equal(loaded.save(),saved);assert.equal(loaded.load('{bad'),false);assert.equal(loaded.load('{"version":1}'),false);g.s.paused=true;const frozen=g.save();run(1,{x:1});assert.equal(g.save(),frozen);report.push({mechanic:'wind, explosion, whole-state rewind, save validation and pause',passed:true});
// Stress original and remixed worlds without forcing goal flags.
for(const seed of[1,2,12,70,121]){g=new Bump.Game(seed);const random=(n)=>Math.sin(n*456.17+seed)*.5+.5;for(let i=0;i<4000;i++){if(i%150===0)g.throwOrCall();if(i%200===0)g.rotate();if(i%170===0)g.act();g.update(.02,{x:random(i)>0.5?1:-1,y:random(i+1)>0.5?1:-1});}for(const o of[g.s.hero,...g.s.props,...g.s.monsters]){assert.ok(Number.isFinite(o.x)&&Number.isFinite(o.y));assert.ok(o.x>=0&&o.x<=Bump.W&&o.y>=0&&o.y<=Bump.H);}assert.ok(g.history.length<=100);}
report.push({mechanic:'five layouts, 400 seconds of simulated interactions',passed:true});

// Render representative game states into real Canvas for visual inspection.
const context={window:{Bump},console};vm.createContext(context);vm.runInContext(fs.readFileSync(__dirname+'/renderer.js','utf8'),context);g=new Bump.Game();let canvas=createCanvas(1000,680),r=new Bump.Renderer(canvas,g);r.overview=true;r.draw();fs.writeFileSync(__dirname+'/qa-overview.png',canvas.toBuffer('image/png'));r.overview=false;r.draw();fs.writeFileSync(__dirname+'/qa-play.png',canvas.toBuffer('image/png'));const mini=createCanvas(272,184);r.minimap(mini);fs.writeFileSync(__dirname+'/qa-minimap.png',mini.toBuffer('image/png'));
g.s.hero.x=790;g.s.hero.y=460;g.throwOrCall();run(.9,{y:1});run(1.5);r.overview=true;r.draw();fs.writeFileSync(__dirname+'/qa-action.png',canvas.toBuffer('image/png'));
fs.writeFileSync(__dirname+'/validation.json',JSON.stringify({report,verification:'Pure engine movement and real actions for wind, stone, borrowed monster charge and barrel-chain completion; fixtures for isolated ram/reflection; real Canvas render. Compiled offline HTML also tested through mocked DOM keyboard/control events (verify-ui.cjs).',limitation:'No complete real-browser, Windows, touch or audio-device QA in this environment.'},null,2));console.log(JSON.stringify(report,null,2));
