const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),{createCanvas}=require('@napi-rs/canvas'),{Bump}=require('./engine.js');
let g=new Bump.Game();const checks=[];
function run(sec,input={}){for(let t=0;t<sec;t+=.02)g.update(Math.min(.02,sec-t),input);}
function aim(p){g.update(.02,{aim:p});}
function walk(x,y,stop=7){const to={x,y};for(let i=0;i<2000;i++){const h=g.s.hero;if(Bump.dist(h,to)<stop)return;let target=to;if(!g.visible(h,to)){const p=g.path(h,to,18);assert.ok(p.length,'reachable waypoint');target=p.find(t=>Bump.dist(h,t)>10)||to;}g.update(.02,{x:Math.abs(target.x-h.x)>2?Math.sign(target.x-h.x):0,y:Math.abs(target.y-h.y)>2?Math.sign(target.y-h.y):0});}throw Error('walk stuck: '+JSON.stringify({x,y,h:g.s.hero}));}
function p(id){return g.s.props.find(p=>p.id===id);}
function pick(id){const o=p(id);walk(o.x,o.y,35);aim(o);g.act();assert.equal(g.s.hero.held,id);}
function quiet(){for(const m of g.s.monsters)m.mode='sleep';}

// Real player controls launch and rotate a spring without changing simulation coordinates.
walk(530,725);g.rotate();assert.ok(Math.abs(g.s.pads[0].angle)<.001);run(.6,{x:1});assert.ok(g.s.hero.x>660,'spring adds useful travel');assert.ok(g.s.stats.bounces>=1);walk(570,778);aim(g.s.pads[0]);g.act();assert.equal(g.s.pads[0].on,false,'nearby E disables spring');checks.push('movement onto a rotated spring launches the player; E switches it off');

// Physically pick and throw a resin can; a patch appears only after the action.
g=new Bump.Game();pick('resin-a');aim({x:620,y:700});g.throwOrCall();run(1);assert.equal(p('resin-a').dead,true);assert.ok(g.s.patches.length);assert.ok(g.s.stats.spills>=1);const patchPosition={...g.s.patches[0]};checks.push('real pickup and throw create a persistent resin patch');

// Walk to the actual supply cabinet after consuming a can; replenish through E.
walk(160,400);aim(g.s.cabinet);g.act();assert.equal(p('resin-a').dead,false);assert.equal(p('resin-a').fuse,-1);assert.ok(g.s.patches.length,'restock keeps the consequences in the world');checks.push('normal navigation and E at cabinet replenish consumed supplies');

// Comparison fixtures verify slowing, independent of the live monsters and level route.
function displacement(sticky){g=new Bump.Game();quiet();g.s.hero.x=500;g.s.hero.y=380;if(sticky)g.s.patches.push({id:'test',x:550,y:380,r:150,burn:0,spent:false});const start=g.s.hero.x;run(.5,{x:1});return g.s.hero.x-start;}
assert.ok(displacement(true)<displacement(false)*.7,'sticky floor slows movement');
function chargeDistance(sticky){g=new Bump.Game();quiet();g.s.hero.x=1200;g.s.hero.y=800;const m=g.s.monsters[0];Object.assign(m,{x:470,y:350,dx:1,dy:0,mode:'charge',timer:1.2});if(sticky)g.s.patches.push({id:'test',x:500,y:350,r:150,burn:0,spent:false});run(.3);return m.x-470;}
assert.ok(chargeDistance(true)<chargeDistance(false)*.6);checks.push('resin slows both player movement and a charging monster');

// Spring changes an actual projectile into a bell-ringing shot; no ring() or completion flag calls.
g=new Bump.Game();quiet();const pad=g.s.pads[0],stone=p('stone-a'),bell=g.s.bells[1];Object.assign(stone,{x:pad.x,y:pad.y,vx:0,vy:0});pad.angle=0;bell.x=750;bell.y=pad.y;run(.9);assert.ok(bell.rung,'spring-launched rock rings bell through collision');assert.ok(g.s.stats.bounces>0);checks.push('spring-launched physical rock rings an optional bell');

// A spring redirects a moving monster, which can then knock into its partner.
g=new Bump.Game();quiet();const a=g.s.monsters[0],b=g.s.monsters[1],pad2=g.s.pads[0];pad2.angle=0;Object.assign(a,{x:pad2.x-35,y:pad2.y,dx:0,dy:1,mode:'charge',timer:1.2});Object.assign(b,{x:780,y:pad2.y,mode:'sleep'});run(.9);assert.ok(g.s.discoveries.includes('spring-monster'));assert.ok(g.s.discoveries.includes('monster-bump'));assert.equal(b.mode,'stun');checks.push('spring redirects a live charging monster into another monster');

// Fire propagates through resin into another barrel; burning eventually consumes the patch.
g=new Bump.Game();quiet();g.s.hero.x=1200;g.s.hero.y=850;const can=p('resin-a');can.x=500;can.y=380;const patch=g.spill(can);g.s.patches.push({id:'bridge',x:610,y:380,r:65,burn:0,spent:false});const starter=p('barrel-a'),next=p('barrel-b');starter.x=500;starter.y=300;next.x=700;next.y=380;for(const q of g.s.props)if(q.kind==='barrel'&&!['barrel-a','barrel-b'].includes(q.id)){q.x=1250;q.y=70;}g.ignite(starter,.01);run(2);assert.ok(g.s.stats.fires>=2);assert.ok(next.dead,'resin fire ignites another barrel');assert.ok(g.s.stats.blasts>=2);const fireSave=g.save();const restored=new Bump.Game();assert.ok(restored.load(fireSave));assert.equal(restored.s.stats.fires,g.s.stats.fires);run(7.5);assert.ok(patch.spent,'spent resin stops burning');checks.push('explosion lights resin, fire spreads and ignites a second barrel; save retains fire');

// Rewind all of the new entities and discoveries as one state.
g=new Bump.Game();quiet();g.s.hero.x=1200;g.s.hero.y=850;run(6);const original=JSON.parse(g.save());g.spill(p('resin-a'),true);g.s.pads[0].angle+=Math.PI/4;g.s.bells[0].x=500;g.s.bells[0].y=380;const shot=p('stone-a');Object.assign(shot,{x:480,y:380,vx:500,vy:0});run(.4);assert.ok(g.s.stats.spills>0);g.rewind();assert.equal(g.s.patches.length,0);assert.equal(g.s.pads[0].angle,original.pads[0].angle);assert.equal(g.s.stats.bells,0);assert.equal(p('resin-a').dead,false);checks.push('rewind restores resin, fire, spring orientation, bells and consumed objects');

// Old release saves are upgraded in memory without losing the original world progress.
g=new Bump.Game();assert.ok(g.load(fs.readFileSync(__dirname+'/v01-save-fixture.json','utf8')));assert.equal(g.s.version,4);assert.equal(g.s.time,21);assert.equal(g.s.hero.x,800);assert.equal(g.s.walls.find(w=>w.id==='west-breach').hp,0);assert.equal(g.s.pads.length,2);assert.equal(g.s.monsters.length,4);assert.equal(g.s.props.length,21);checks.push('v0.1 saves migrate with original positions and broken walls intact');

// Get real bell contacts via three different physical systems.
g=new Bump.Game();quiet();g.s.hero.x=1200;g.s.hero.y=850;const bell1=g.s.bells[0],bell2=g.s.bells[1],bell3=g.s.bells[2];const rock=p('stone-c');Object.assign(rock,{x:bell1.x+43,y:bell1.y,vx:-400,vy:0});run(.2);assert.ok(bell1.rung);const barrel=p('barrel-f');barrel.x=bell2.x;barrel.y=bell2.y+50;g.ignite(barrel,.01);run(.1);assert.ok(bell2.rung);g.s.fan.angle=0;run(1);assert.ok(bell3.rung,'wind rings third bell');assert.equal(g.s.stats.bells,3);assert.ok(g.s.discoveries.includes('all-bells'));checks.push('projectiles, explosion and wind can all ring bells');

// Visual states include the added effects and machines, not just the idle board.
const ctx={window:{Bump},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync(__dirname+'/renderer.js','utf8'),ctx);const canvas=createCanvas(1000,680),view=new Bump.Renderer(canvas,g);view.overview=true;const resin=p('resin-b');g.spill(resin,true);g.s.pads[0].pulse=g.s.time;view.draw();fs.writeFileSync(__dirname+'/qa-rich-effects.png',canvas.toBuffer('image/png'));
const validationPath=__dirname+'/validation.json',validation=fs.existsSync(validationPath)?JSON.parse(fs.readFileSync(validationPath,'utf8')):{};validation.richChecks=checks;validation.limitation='Engine, real Canvas and mocked DOM tested. Full real-browser, Windows, touch and audio-device QA not available.';fs.writeFileSync(validationPath,JSON.stringify(validation,null,2));console.log('PASS: '+checks.join('; '));
